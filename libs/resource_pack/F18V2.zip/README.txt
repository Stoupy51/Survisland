F18V2 - Resource pack Minecraft Java 26.2

Ce pack remplace l'overlay visuel de la citrouille sculptee par
pumpkinblurV2.png.

Installation :
1. Copier F18V2.zip dans le dossier .minecraft/resourcepacks.
2. Activer F18V2 dans les packs de ressources.
3. Equiper une citrouille sculptee.

Format de resource pack : 88.0 (Minecraft Java 26.2).
