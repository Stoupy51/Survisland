
#> cache_cache_s32:equipment/force_team_player
#
# @within	cache_cache_s32:admin/hunter_to_hunted
#			cache_cache_s32:game/transition/after_round1 [ as @a[tag=ChasseurMap1] ]
#			cache_cache_s32:game/transition/after_round2 [ as @a[tag=ChasseurMap2] ]
#

execute if entity @s[team=RTT] run item replace entity @s armor.chest with minecraft:leather_chestplate[minecraft:dyed_color=16383998, minecraft:trim={material: "minecraft:emerald", pattern: "minecraft:dune"}, minecraft:unbreakable={}, minecraft:enchantments={"minecraft:binding_curse": 1}, minecraft:custom_data={cache_cache_s32: {uniform: 1b, role: "rtt"}}]
execute if entity @s[team=Albertos] run item replace entity @s armor.chest with minecraft:leather_chestplate[minecraft:dyed_color=16383998, minecraft:trim={material: "minecraft:diamond", pattern: "minecraft:dune"}, minecraft:unbreakable={}, minecraft:enchantments={"minecraft:binding_curse": 1}, minecraft:custom_data={cache_cache_s32: {uniform: 1b, role: "albertos"}}]
execute if items entity @s armor.head *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.head with air
clear @s minecraft:netherite_sword[minecraft:custom_data~{cache_cache_s32: {hunter_weapon: 1b}}]

