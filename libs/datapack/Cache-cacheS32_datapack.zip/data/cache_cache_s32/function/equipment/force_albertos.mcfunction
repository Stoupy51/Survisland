
#> cache_cache_s32:equipment/force_albertos
#
# @within	cache_cache_s32:admin/force_albertos_chestplates
#			cache_cache_s32:admin/force_all_equipment
#			cache_cache_s32:admin/force_team_chestplates
#			cache_cache_s32:equipment/team_colors
#

item replace entity @a[team=Albertos] armor.chest with minecraft:leather_chestplate[minecraft:dyed_color=16383998, minecraft:trim={material: "minecraft:diamond", pattern: "minecraft:dune"}, minecraft:unbreakable={}, minecraft:enchantments={"minecraft:binding_curse": 1}, minecraft:custom_data={cache_cache_s32: {uniform: 1b, role: "albertos"}}]

