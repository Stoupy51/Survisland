
#> cache_cache_s32:equipment/force_specs
#
# @within	cache_cache_s32:admin/force_all_equipment
#			cache_cache_s32:admin/force_spec_chestplates
#			cache_cache_s32:admin/force_team_chestplates
#			cache_cache_s32:admin/register_specs_from_zone
#			cache_cache_s32:equipment/team_colors
#

item replace entity @a[tag=SpecChasses] armor.chest with minecraft:leather_chestplate[minecraft:dyed_color=16383998, minecraft:trim={material: "minecraft:iron", pattern: "minecraft:dune"}, minecraft:unbreakable={}, minecraft:enchantments={"minecraft:binding_curse": 1}, minecraft:custom_data={cache_cache_s32: {uniform: 1b, role: "spec"}}]

