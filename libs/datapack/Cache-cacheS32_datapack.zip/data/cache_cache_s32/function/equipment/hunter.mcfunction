
#> cache_cache_s32:equipment/hunter
#
# @executed	as @a[tag=ChasseurMap1]
#
# @within	cache_cache_s32:equipment/apply_round [ as @a[tag=ChasseurMap1] ]
#			cache_cache_s32:equipment/apply_round [ as @a[tag=ChasseurMap2] ]
#			cache_cache_s32:equipment/apply_round [ as @a[tag=ChasseurMap3] ]
#			cache_cache_s32:game/start_hunt_release [ as @a[tag=survisland.seeker] ]
#

# Replace a team uniform, but never overwrite personal equipment.
execute if items entity @s armor.chest *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.chest with air
execute if items entity @s armor.head *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.head with air
execute unless items entity @s armor.chest * run item replace entity @s armor.chest with minecraft:leather_chestplate[minecraft:dyed_color=1908001, minecraft:trim={material: "minecraft:iron", pattern: "minecraft:dune"}, minecraft:unbreakable={}, minecraft:enchantments={"minecraft:binding_curse": 1}, minecraft:custom_data={cache_cache_s32: {uniform: 1b, role: "hunter"}}]
clear @s minecraft:netherite_sword[minecraft:custom_data~{cache_cache_s32: {hunter_weapon: 1b}}]
give @s minecraft:netherite_sword[minecraft:custom_name={text: "Epee du chasseur", color: "dark_red", italic: false}, minecraft:unbreakable={}, minecraft:attribute_modifiers=[{id: "cache_cache_s32:hunter_damage", type: "minecraft:attack_damage", amount: 0.0d, operation: "add_value", slot: "mainhand"}], minecraft:custom_data={cache_cache_s32: {hunter_weapon: 1b}}] 1
execute unless items entity @s armor.chest *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run tellraw @s {text: "Liberez votre emplacement de plastron pour recevoir la tenue de chasseur.", color: "red"}

