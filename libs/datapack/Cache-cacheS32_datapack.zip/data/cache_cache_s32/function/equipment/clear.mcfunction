
#> cache_cache_s32:equipment/clear
#
# @within	cache_cache_s32:game/cleanup
#

execute as @a[team=RTT] if items entity @s armor.chest *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.chest with air
execute as @a[team=RTT] if items entity @s armor.head *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.head with air
execute as @a[team=Albertos] if items entity @s armor.chest *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.chest with air
execute as @a[team=Albertos] if items entity @s armor.head *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.head with air
execute as @a[tag=SpecChasses] if items entity @s armor.chest *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.chest with air
execute as @a[tag=SpecChasses] if items entity @s armor.head *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.head with air
clear @a[team=RTT] minecraft:netherite_sword[minecraft:custom_data~{cache_cache_s32: {hunter_weapon: 1b}}]
clear @a[team=Albertos] minecraft:netherite_sword[minecraft:custom_data~{cache_cache_s32: {hunter_weapon: 1b}}]
clear @a[tag=SpecChasses] minecraft:netherite_sword[minecraft:custom_data~{cache_cache_s32: {hunter_weapon: 1b}}]

