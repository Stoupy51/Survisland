
#> cache_cache_s32:equipment/force_hunter
#
# @executed	as @a[tag=survisland.seeker]
#
# @within	cache_cache_s32:admin/force_all_equipment [ as @a[tag=survisland.seeker] ]
#			cache_cache_s32:admin/force_all_equipment [ as @a[tag=...] ]
#			cache_cache_s32:admin/force_hunter_equipment [ as @a[tag=survisland.seeker] ]
#			cache_cache_s32:admin/force_hunter_equipment_player
#			cache_cache_s32:game/transition/after_round1 [ as @a[tag=ChasseurMap2] ]
#			cache_cache_s32:game/transition/after_round2 [ as @a[tag=ChasseurMap3] ]
#

item replace entity @s armor.chest with minecraft:leather_chestplate[minecraft:dyed_color=1908001, minecraft:trim={material: "minecraft:iron", pattern: "minecraft:dune"}, minecraft:unbreakable={}, minecraft:enchantments={"minecraft:binding_curse": 1}, minecraft:custom_data={cache_cache_s32: {uniform: 1b, role: "hunter"}}]
execute if items entity @s armor.head *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.head with air
clear @s minecraft:netherite_sword[minecraft:custom_data~{cache_cache_s32: {hunter_weapon: 1b}}]
give @s minecraft:netherite_sword[minecraft:custom_name={text: "Epee du chasseur", color: "dark_red", italic: false}, minecraft:unbreakable={}, minecraft:attribute_modifiers=[{id: "cache_cache_s32:hunter_damage", type: "minecraft:attack_damage", amount: 0.0d, operation: "add_value", slot: "mainhand"}], minecraft:custom_data={cache_cache_s32: {hunter_weapon: 1b}}] 1

