
#> cache_cache_s32:equipment/apply_round
#
# @within	cache_cache_s32:game/start_hide
#

function cache_cache_s32:equipment/team_colors
execute if score #round cachecache_state matches 1 as @a[tag=ChasseurMap1] run function cache_cache_s32:equipment/hunter
execute if score #round cachecache_state matches 2 as @a[tag=ChasseurMap2] run function cache_cache_s32:equipment/hunter
execute if score #round cachecache_state matches 3 as @a[tag=ChasseurMap3] run function cache_cache_s32:equipment/hunter

