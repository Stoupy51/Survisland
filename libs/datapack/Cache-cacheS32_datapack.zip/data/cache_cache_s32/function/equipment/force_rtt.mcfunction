
#> cache_cache_s32:equipment/force_rtt
#
# @within	cache_cache_s32:admin/force_all_equipment
#			cache_cache_s32:admin/force_rtt_chestplates
#			cache_cache_s32:admin/force_team_chestplates
#			cache_cache_s32:equipment/team_colors
#

item replace entity @a[team=RTT] armor.chest with minecraft:leather_chestplate[minecraft:dyed_color=16383998, minecraft:trim={material: "minecraft:emerald", pattern: "minecraft:dune"}, minecraft:unbreakable={}, minecraft:enchantments={"minecraft:binding_curse": 1}, minecraft:custom_data={cache_cache_s32: {uniform: 1b, role: "rtt"}}]

