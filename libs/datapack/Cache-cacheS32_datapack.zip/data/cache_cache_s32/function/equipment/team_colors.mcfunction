
#> cache_cache_s32:equipment/team_colors
#
# @within	cache_cache_s32:equipment/apply_round
#

# Remove only uniforms previously created by this datapack.
execute as @a[team=RTT] if items entity @s armor.chest *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.chest with air
execute as @a[team=Albertos] if items entity @s armor.chest *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.chest with air
execute as @a[tag=SpecChasses] if items entity @s armor.chest *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.chest with air
execute as @a[team=RTT] if items entity @s armor.head *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.head with air
execute as @a[team=Albertos] if items entity @s armor.head *[minecraft:custom_data~{cache_cache_s32: {uniform: 1b}}] run item replace entity @s armor.head with air
clear @a[team=RTT] minecraft:netherite_sword[minecraft:custom_data~{cache_cache_s32: {hunter_weapon: 1b}}]
clear @a[team=Albertos] minecraft:netherite_sword[minecraft:custom_data~{cache_cache_s32: {hunter_weapon: 1b}}]

# Tous les participants portent obligatoirement la tenue du jeu.
# L'emplacement de plastron est remplacé même s'il était déjà occupé.
function cache_cache_s32:equipment/force_rtt
function cache_cache_s32:equipment/force_albertos
function cache_cache_s32:equipment/force_specs

