
#> cache_cache_s32:effects/maintain
#
# @within	cache_cache_s32:game/second
#			cache_cache_s32:game/start
#			cache_cache_s32:game/start_hide
#			cache_cache_s32:game/start_hunt_release
#

# Maintient les effets communs sur tous les participants pendant la partie.
effect give @a[team=RTT] minecraft:saturation infinite 0 true
effect give @a[team=Albertos] minecraft:saturation infinite 0 true
effect give @a[tag=SpecChasses] minecraft:saturation infinite 0 true
execute as @a[team=RTT] run attribute @s minecraft:fall_damage_multiplier base set 0
execute as @a[team=Albertos] run attribute @s minecraft:fall_damage_multiplier base set 0
execute as @a[tag=SpecChasses] run attribute @s minecraft:fall_damage_multiplier base set 0

