
#> cache_cache_s32:score/reset
#
# @within	???
#

scoreboard players set Albertos cachecache_score 0
scoreboard players set RTT cachecache_score 0
scoreboard players set #score_event cachecache_state 0
scoreboard players set #rtt_reached cachecache_state 0
scoreboard players set #albertos_reached cachecache_state 0

