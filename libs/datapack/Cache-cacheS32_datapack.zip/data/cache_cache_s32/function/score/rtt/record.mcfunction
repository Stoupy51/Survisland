
#> cache_cache_s32:score/rtt/record
#
# @executed	as the player & at current position
#
# @within	cache_cache_s32:score/rtt/add
#			cache_cache_s32:score/rtt/add_3
#			cache_cache_s32:score/rtt/add_5
#			cache_cache_s32:score/rtt/remove
#			cache_cache_s32:score/rtt/remove_3
#

scoreboard players add #score_event cachecache_state 1
scoreboard players operation #rtt_reached cachecache_state = #score_event cachecache_state

