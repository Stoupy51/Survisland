
#> cache_cache_s32:score/rtt/add_3
#
# @executed	as the player & at current position
#
# @within	cache_cache_s32:hit/by_rtt
#

scoreboard players add RTT cachecache_score 3
function cache_cache_s32:score/rtt/record

