
#> cache_cache_s32:score/rtt/remove
#
# @within	???
#

scoreboard players remove RTT cachecache_score 1
function cache_cache_s32:score/rtt/record

