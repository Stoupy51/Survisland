
#> cache_cache_s32:score/rtt/add_5
#
# @executed	as @a[tag=...,team=RTT]
#
# @within	cache_cache_s32:game/end_hunt [ as @a[tag=...,team=RTT] ]
#

scoreboard players add RTT cachecache_score 5
function cache_cache_s32:score/rtt/record

