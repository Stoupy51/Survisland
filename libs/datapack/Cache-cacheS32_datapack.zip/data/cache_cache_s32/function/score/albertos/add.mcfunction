
#> cache_cache_s32:score/albertos/add
#
# @executed	as the player & at current position
#
# @within	cache_cache_s32:hit/by_albertos
#			cache_cache_s32:zone/points/check [ positioned ~-3 ~ ~-3 ]
#

scoreboard players add Albertos cachecache_score 1
function cache_cache_s32:score/albertos/record

