
#> cache_cache_s32:score/albertos/add_3
#
# @executed	as the player & at current position
#
# @within	cache_cache_s32:hit/by_albertos
#

scoreboard players add Albertos cachecache_score 3
function cache_cache_s32:score/albertos/record

