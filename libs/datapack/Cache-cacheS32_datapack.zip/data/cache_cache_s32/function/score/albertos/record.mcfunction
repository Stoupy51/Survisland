
#> cache_cache_s32:score/albertos/record
#
# @executed	as the player & at current position
#
# @within	cache_cache_s32:score/albertos/add
#			cache_cache_s32:score/albertos/add_3
#			cache_cache_s32:score/albertos/add_5
#			cache_cache_s32:score/albertos/remove
#			cache_cache_s32:score/albertos/remove_3
#

scoreboard players add #score_event cachecache_state 1
scoreboard players operation #albertos_reached cachecache_state = #score_event cachecache_state

