
#> cache_cache_s32:score/albertos/remove
#
# @within	???
#

scoreboard players remove Albertos cachecache_score 1
function cache_cache_s32:score/albertos/record

