
#> cache_cache_s32:score/albertos/add_5
#
# @executed	as @a[tag=...,team=Albertos]
#
# @within	cache_cache_s32:game/end_hunt [ as @a[tag=...,team=Albertos] ]
#

scoreboard players add Albertos cachecache_score 5
function cache_cache_s32:score/albertos/record

