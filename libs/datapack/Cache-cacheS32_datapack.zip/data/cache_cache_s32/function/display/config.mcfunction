
#> cache_cache_s32:display/config
#
# @within	cache_cache_s32:v0.0.1/load/confirm_load
#

# Temporary round duration. It can be changed once the final rules are known.
scoreboard players set #duration_min cachecache_timer 10
scoreboard players set #duration_sec cachecache_timer 0

# Constant used to convert the remaining time into minutes and seconds.
scoreboard players set #sixty cachecache_timer 60

# Initialise a fresh timer only when no value exists yet.
execute unless score #total cachecache_timer matches 0.. run function cache_cache_s32:timer/reset

