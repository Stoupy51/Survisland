
#> cache_cache_s32:display/line_intermission_albertos
#
# @within	???
#

execute if score #sec cachecache_timer matches 10.. run title @s actionbar [{text: "Prochaine manche ", color: "yellow"}, {score: {name: "#min", objective: "cachecache_timer"}}, {text: ":"}, {score: {name: "#sec", objective: "cachecache_timer"}}, {text: " | Albertos ", color: "aqua"}, {score: {name: "Albertos", objective: "cachecache_score"}}, {text: " - "}, {score: {name: "RTT", objective: "cachecache_score"}}, {text: " RTT", color: "green"}]
execute if score #sec cachecache_timer matches ..9 run title @s actionbar [{text: "Prochaine manche ", color: "yellow"}, {score: {name: "#min", objective: "cachecache_timer"}}, {text: ":0"}, {score: {name: "#sec", objective: "cachecache_timer"}}, {text: " | Albertos ", color: "aqua"}, {score: {name: "Albertos", objective: "cachecache_score"}}, {text: " - "}, {score: {name: "RTT", objective: "cachecache_score"}}, {text: " RTT", color: "green"}]

