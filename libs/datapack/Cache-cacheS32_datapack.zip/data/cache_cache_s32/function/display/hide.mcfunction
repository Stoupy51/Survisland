
#> cache_cache_s32:display/hide
#
# @within	cache_cache_s32:display/show
#

execute as @a run function cache_cache_s32:display/line_hide_spec

