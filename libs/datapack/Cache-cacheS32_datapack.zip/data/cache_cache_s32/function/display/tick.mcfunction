
#> cache_cache_s32:display/tick
#
# @within	???
#

execute if score #running cachecache_state matches 1 run function cache_cache_s32:timer/tick
function cache_cache_s32:display/show

