
#> cache_cache_s32:display/show
#
# @within	cache_cache_s32:admin/skip_hide
#			cache_cache_s32:display/tick
#			cache_cache_s32:timer/end
#			cache_cache_s32:timer/second
#			cache_cache_s32:timer/start
#			cache_cache_s32:timer/start_config
#

execute if score #phase cachecache_state matches 1 run function cache_cache_s32:display/preparation
execute if score #phase cachecache_state matches 2 run function cache_cache_s32:display/hide
execute if score #phase cachecache_state matches 3 run function cache_cache_s32:display/hunt
execute if score #phase cachecache_state matches 4 run function cache_cache_s32:display/intermission

