
#> cache_cache_s32:display/line_hide_spec
#
# @executed	as @a
#
# @within	cache_cache_s32:display/hide [ as @a ]
#

execute if score #sec cachecache_timer matches 10.. run title @s actionbar [{text: "Cachez-vous : ", color: "gold"}, {score: {name: "#min", objective: "cachecache_timer"}, color: "yellow"}, {text: ":", color: "yellow"}, {score: {name: "#sec", objective: "cachecache_timer"}, color: "yellow"}, {text: " - ", color: "gray"}, {score: {name: "Albertos", objective: "cachecache_score"}, color: "aqua", bold: true}, {text: "-", color: "gray"}, {score: {name: "RTT", objective: "cachecache_score"}, color: "green", bold: true}]
execute if score #sec cachecache_timer matches ..9 run title @s actionbar [{text: "Cachez-vous : ", color: "gold"}, {score: {name: "#min", objective: "cachecache_timer"}, color: "yellow"}, {text: ":0", color: "yellow"}, {score: {name: "#sec", objective: "cachecache_timer"}, color: "yellow"}, {text: " - ", color: "gray"}, {score: {name: "Albertos", objective: "cachecache_score"}, color: "aqua", bold: true}, {text: "-", color: "gray"}, {score: {name: "RTT", objective: "cachecache_score"}, color: "green", bold: true}]

