
#> cache_cache_s32:admin/add_spec
#
# @within	string in cache_cache_s32:admin/add_spec {player:"Pseudo"}
#
# @args		player (string)
#

# Usage: /function cache_cache_s32:admin/add_spec {player:"Pseudo"}
$tag $(player) remove Chasses
$tag $(player) remove survisland.seeker
$tag $(player) remove Malus
$tag $(player) add SpecChasses
$tag $(player) add survisland.alive
$gamemode adventure $(player)
$effect give $(player) saturation 999999 0 true
$tellraw @a [{"text":"[Admin] ","color":"gold"},{"text":"$(player)","color":"white"},{"text":" est maintenant spectateur participant.","color":"yellow"}]

