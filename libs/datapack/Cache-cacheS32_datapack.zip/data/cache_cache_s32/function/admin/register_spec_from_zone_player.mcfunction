
#> cache_cache_s32:admin/register_spec_from_zone_player
#
# @executed	at @e[type=minecraft:marker,tag=cachecache.marker.spec_registration,limit=1] & as @a[distance=..30]
#
# @within	cache_cache_s32:admin/register_specs_from_zone [ at @e[type=minecraft:marker,tag=cachecache.marker.spec_registration,limit=1] & as @a[distance=..30] ]
#

tag @s remove Chasses
tag @s remove survisland.seeker
tag @s remove Malus
tag @s add SpecChasses
tag @s add survisland.alive
gamemode adventure @s
effect give @s saturation 999999 0 true
scoreboard players add #spec_count cachecache_state 1

