
#> cache_cache_s32:admin/force_hunter_equipment_player
#
# @within	string in cache_cache_s32:admin/force_hunter_equipment_player {player:"Pseudo"}
#
# @args		player (string)
#

# Usage: /function cache_cache_s32:admin/force_hunter_equipment_player {player:"Pseudo"}
$execute as $(player) run function cache_cache_s32:equipment/force_hunter

