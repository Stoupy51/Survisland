
#> cache_cache_s32:admin/verify_hunters
#
# @within	???
#

function cache_cache_s32:admin/check_hunters
tellraw @s [{text: "RTT map 1 : ", color: "green"}, {selector: "@a[team=RTT,tag=ChasseurMap1]", color: "white"}]
tellraw @s [{text: "RTT map 2 : ", color: "green"}, {selector: "@a[team=RTT,tag=ChasseurMap2]", color: "white"}]
tellraw @s [{text: "RTT map 3 : ", color: "green"}, {selector: "@a[team=RTT,tag=ChasseurMap3]", color: "white"}]
tellraw @s [{text: "Albertos map 1 : ", color: "aqua"}, {selector: "@a[team=Albertos,tag=ChasseurMap1]", color: "white"}]
tellraw @s [{text: "Albertos map 2 : ", color: "aqua"}, {selector: "@a[team=Albertos,tag=ChasseurMap2]", color: "white"}]
tellraw @s [{text: "Albertos map 3 : ", color: "aqua"}, {selector: "@a[team=Albertos,tag=ChasseurMap3]", color: "white"}]
scoreboard players set #hunters_ok cachecache_state 1
execute unless score #rtt1 cachecache_state matches 1 run scoreboard players set #hunters_ok cachecache_state 0
execute unless score #rtt2 cachecache_state matches 1 run scoreboard players set #hunters_ok cachecache_state 0
execute unless score #rtt3 cachecache_state matches 1 run scoreboard players set #hunters_ok cachecache_state 0
execute unless score #alb1 cachecache_state matches 1 run scoreboard players set #hunters_ok cachecache_state 0
execute unless score #alb2 cachecache_state matches 1 run scoreboard players set #hunters_ok cachecache_state 0
execute unless score #alb3 cachecache_state matches 1 run scoreboard players set #hunters_ok cachecache_state 0
execute if entity @a[tag=ChasseurMap1, tag=ChasseurMap2] run scoreboard players set #hunters_ok cachecache_state 0
execute if entity @a[tag=ChasseurMap1, tag=ChasseurMap3] run scoreboard players set #hunters_ok cachecache_state 0
execute if entity @a[tag=ChasseurMap2, tag=ChasseurMap3] run scoreboard players set #hunters_ok cachecache_state 0
execute if score #hunters_ok cachecache_state matches 1 run tellraw @s {text: "VALID\u00c9 : 3 chasseurs diff\u00e9rents dans chaque \u00e9quipe.", color: "green", bold: true}
execute unless score #hunters_ok cachecache_state matches 1 run tellraw @s {text: "ERREUR : la s\u00e9lection des six chasseurs n'est pas valide.", color: "red", bold: true}

