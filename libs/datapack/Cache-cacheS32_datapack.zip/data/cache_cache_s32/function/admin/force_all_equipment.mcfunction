
#> cache_cache_s32:admin/force_all_equipment
#
# @within	???
#

# Force les tenues des deux équipes, puis remplace celles des chasseurs de la manche en cours.
function cache_cache_s32:equipment/force_rtt
function cache_cache_s32:equipment/force_albertos
function cache_cache_s32:equipment/force_specs
execute as @a[tag=survisland.seeker] run function cache_cache_s32:equipment/force_hunter
execute if score #round cachecache_state matches 1 as @a[tag=ChasseurMap1, tag=!survisland.seeker] run function cache_cache_s32:equipment/force_hunter
execute if score #round cachecache_state matches 2 as @a[tag=ChasseurMap2, tag=!survisland.seeker] run function cache_cache_s32:equipment/force_hunter
execute if score #round cachecache_state matches 3 as @a[tag=ChasseurMap3, tag=!survisland.seeker] run function cache_cache_s32:equipment/force_hunter
tellraw @a {text: "[Admin] \u00c9quipements des joueurs et des chasseurs forc\u00e9s.", color: "yellow"}

