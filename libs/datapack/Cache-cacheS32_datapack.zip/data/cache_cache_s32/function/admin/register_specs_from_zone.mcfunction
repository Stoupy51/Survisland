
#> cache_cache_s32:admin/register_specs_from_zone
#
# @within	???
#

execute unless entity @e[type=minecraft:marker, tag=cachecache.marker.spec_registration, limit=1] run tellraw @s {text: "Zone des specs absente : utilisez setup/set_spec_registration.", color: "red"}
execute unless entity @e[type=minecraft:marker, tag=cachecache.marker.spec_registration, limit=1] run return 0
scoreboard players set #spec_count cachecache_state 0
execute at @e[type=minecraft:marker, tag=cachecache.marker.spec_registration, limit=1] as @a[distance=..30] unless entity @s[team=RTT] unless entity @s[team=Albertos] run function cache_cache_s32:admin/register_spec_from_zone_player
function cache_cache_s32:equipment/force_specs
tellraw @s [{text: "Specs participants enregistres : ", color: "yellow"}, {score: {name: "#spec_count", objective: "cachecache_state"}, color: "white", bold: true}]
function cache_cache_s32:admin/check_specs

