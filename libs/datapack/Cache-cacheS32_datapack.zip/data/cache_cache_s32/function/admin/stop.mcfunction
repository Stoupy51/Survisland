
#> cache_cache_s32:admin/stop
#
# @within	???
#

execute unless score #running cachecache_state matches 1 run tellraw @s {text: "Aucune partie n'est en cours.", color: "red"}
execute unless score #running cachecache_state matches 1 run return 0
function cache_cache_s32:game/abort

