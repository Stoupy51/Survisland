
#> cache_cache_s32:admin/send_players_to_hunted_hold
#
# @within	???
#

# Envoie les joueurs d'equipe dans la zone d'attente des chasses.
# Seuls les chasseurs de la manche actuellement selectionnee sont exclus.
execute if score #round cachecache_state matches 0 as @a[team=RTT] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute if score #round cachecache_state matches 0 as @a[team=Albertos] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute if score #round cachecache_state matches 1 as @a[team=RTT, tag=!ChasseurMap1] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute if score #round cachecache_state matches 1 as @a[team=Albertos, tag=!ChasseurMap1] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute if score #round cachecache_state matches 2 as @a[team=RTT, tag=!ChasseurMap2] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute if score #round cachecache_state matches 2 as @a[team=Albertos, tag=!ChasseurMap2] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute if score #round cachecache_state matches 3 as @a[team=RTT, tag=!ChasseurMap3] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute if score #round cachecache_state matches 3 as @a[team=Albertos, tag=!ChasseurMap3] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
gamemode adventure @a[team=RTT]
gamemode adventure @a[team=Albertos]
tellraw @s {text: "Joueurs envoyes dans leur zone d'attente.", color: "green"}

