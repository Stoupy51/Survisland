
#> cache_cache_s32:admin/force_spec_chestplates
#
# @within	???
#

function cache_cache_s32:equipment/force_specs
tellraw @a {text: "[Admin] Les plastrons des Specs ont \u00e9t\u00e9 forc\u00e9s.", color: "gray"}

