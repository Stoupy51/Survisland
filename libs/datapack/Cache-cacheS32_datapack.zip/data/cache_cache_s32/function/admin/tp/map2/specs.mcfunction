
#> cache_cache_s32:admin/tp/map2/specs
#
# @within	???
#

execute as @a[tag=SpecChasses] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map2, limit=1]

