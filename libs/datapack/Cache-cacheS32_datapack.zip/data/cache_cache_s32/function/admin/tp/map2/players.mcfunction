
#> cache_cache_s32:admin/tp/map2/players
#
# @within	???
#

execute as @a[tag=Chasses] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map2, limit=1]

