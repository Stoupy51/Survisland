
#> cache_cache_s32:admin/tp/map2/hunters
#
# @within	???
#

execute as @a[tag=survisland.seeker] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map2, limit=1]
execute if score #round cachecache_state matches 1 as @a[tag=ChasseurMap1, tag=!survisland.seeker] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map2, limit=1]
execute if score #round cachecache_state matches 2 as @a[tag=ChasseurMap2, tag=!survisland.seeker] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map2, limit=1]
execute if score #round cachecache_state matches 3 as @a[tag=ChasseurMap3, tag=!survisland.seeker] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map2, limit=1]

