
#> cache_cache_s32:admin/pause
#
# @within	???
#

execute unless score #running cachecache_state matches 1 run tellraw @s {text: "Aucune partie n'est en cours.", color: "red"}
execute unless score #running cachecache_state matches 1 run return 0
scoreboard players set #paused cachecache_state 1
function cache_cache_s32:integration/survisland/heart_beat_stop
title @a actionbar {text: "JEU EN PAUSE", color: "red", bold: true}
tellraw @a {text: "[Cache-cache] Jeu mis en pause par l'organisateur.", color: "yellow"}

