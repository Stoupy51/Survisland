
#> cache_cache_s32:admin/prepare_specs
#
# @within	cache_cache_s32:game/start
#

gamemode adventure @a[tag=SpecChasses]
effect give @a[tag=SpecChasses] saturation 999999 0 true
execute as @a[tag=SpecChasses] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map1, limit=1]

