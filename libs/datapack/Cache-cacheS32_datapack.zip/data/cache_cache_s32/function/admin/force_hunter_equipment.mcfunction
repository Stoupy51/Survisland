
#> cache_cache_s32:admin/force_hunter_equipment
#
# @within	???
#

execute as @a[tag=survisland.seeker] run function cache_cache_s32:equipment/force_hunter
tellraw @a {text: "[Admin] L'\u00e9quipement a \u00e9t\u00e9 forc\u00e9 sur les chasseurs actifs.", color: "yellow"}

