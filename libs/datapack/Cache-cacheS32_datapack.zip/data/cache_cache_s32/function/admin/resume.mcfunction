
#> cache_cache_s32:admin/resume
#
# @within	???
#

execute unless score #running cachecache_state matches 1 run tellraw @s {text: "Aucune partie n'est en cours.", color: "red"}
execute unless score #running cachecache_state matches 1 run return 0
scoreboard players set #paused cachecache_state 0
tellraw @a {text: "[Cache-cache] Reprise du jeu.", color: "green"}
playsound minecraft:block.note_block.pling master @a ~ ~ ~ 1 1.2

