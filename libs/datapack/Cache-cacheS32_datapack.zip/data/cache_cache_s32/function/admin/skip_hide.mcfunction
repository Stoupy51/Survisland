
#> cache_cache_s32:admin/skip_hide
#
# @within	???
#

# Fonction de test : termine immédiatement la phase de cachette et libère les chasseurs.
execute unless score #running cachecache_state matches 1 run tellraw @s {text: "Aucune partie de cache-cache n'est en cours.", color: "red"}
execute unless score #running cachecache_state matches 1 run return 0
execute unless score #phase cachecache_state matches 2 run tellraw @s {text: "Cette fonction ne peut etre utilisee que pendant la phase de cachette.", color: "red"}
execute unless score #phase cachecache_state matches 2 run return 0

scoreboard players set #total cachecache_timer 0
function cache_cache_s32:timer/convert
function cache_cache_s32:display/show
scoreboard players set #phase cachecache_state 6
schedule clear cache_cache_s32:game/start_hunt_release
execute if score #hunt_countdown cachecache_state matches 1 run schedule clear survisland:utils/compteur_schedule
scoreboard players set #hunt_countdown cachecache_state 0
function cache_cache_s32:game/start_hunt_release

