
#> cache_cache_s32:admin/add_hunted
#
# @within	string in cache_cache_s32:admin/add_hunted {player:"Pseudo"}
#
# @args		player (string)
#

# Usage: /function cache_cache_s32:admin/add_hunted {player:"Pseudo"}
$tag $(player) remove SpecChasses
$tag $(player) remove survisland.seeker
$tag $(player) remove Malus
$tag $(player) add Chasses
$tag $(player) add survisland.alive
$gamemode adventure $(player)
$tellraw @a [{"text":"[Admin] ","color":"gold"},{"text":"$(player)","color":"white"},{"text":" est maintenant joueur chassé.","color":"green"}]

