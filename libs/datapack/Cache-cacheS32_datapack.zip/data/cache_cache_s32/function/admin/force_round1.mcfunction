
#> cache_cache_s32:admin/force_round1
#
# @within	???
#

scoreboard players set #running cachecache_state 1
scoreboard players set #paused cachecache_state 0
scoreboard players set #round cachecache_state 1
function cache_cache_s32:game/start_hide

