
#> cache_cache_s32:admin/add_hunter
#
# @within	string in cache_cache_s32:admin/add_hunter {player:"Pseudo",map:1}
#
# @args		player (string)
#			map (int)
#

# Usage: /function cache_cache_s32:admin/add_hunter {player:"Pseudo",map:1}
$tag $(player) remove SpecChasses
$tag $(player) remove Chasses
$tag $(player) remove survisland.alive
$tag $(player) remove ChasseurMap1
$tag $(player) remove ChasseurMap2
$tag $(player) remove ChasseurMap3
$tag $(player) add ChasseurMap$(map)
$gamemode adventure $(player)
$tellraw @a [{"text":"[Admin] ","color":"gold"},{"text":"$(player)","color":"white"},{"text":" est chasseur de la map $(map).","color":"red"}]

