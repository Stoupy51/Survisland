
#> cache_cache_s32:admin/hunter_to_hunted
#
# @within	string in cache_cache_s32:admin/hunter_to_hunted {player:"Pseudo"}
#
# @args		player (string)
#

# Usage: /function cache_cache_s32:admin/hunter_to_hunted {player:"Pseudo"}
$tag $(player) remove ChasseurMap1
$tag $(player) remove ChasseurMap2
$tag $(player) remove ChasseurMap3
$tag $(player) remove survisland.seeker
$tag $(player) remove Malus
$tag $(player) add Chasses
$tag $(player) add survisland.alive
$effect clear $(player) strength
$effect clear $(player) resistance
$effect clear $(player) speed
$effect give $(player) speed 185 0 true
$execute as $(player) run function cache_cache_s32:equipment/force_team_player
$gamemode adventure $(player)
$tellraw @a [{"text":"[Admin] ","color":"gold"},{"text":"$(player)","color":"white"},{"text":" n'est plus chasseur et devient joueur chassé.","color":"green"}]

