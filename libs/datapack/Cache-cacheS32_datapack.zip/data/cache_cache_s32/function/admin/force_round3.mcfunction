
#> cache_cache_s32:admin/force_round3
#
# @within	???
#

scoreboard players set #running cachecache_state 1
scoreboard players set #paused cachecache_state 0
scoreboard players set #round cachecache_state 3
function cache_cache_s32:game/start_hide

