
#> cache_cache_s32:admin/check_specs
#
# @within	cache_cache_s32:admin/register_specs_from_zone
#

execute unless entity @e[type=minecraft:marker, tag=cachecache.marker.spec_registration, limit=1] run tellraw @s {text: "Zone des specs absente : utilisez setup/set_spec_registration.", color: "red"}
execute unless entity @e[type=minecraft:marker, tag=cachecache.marker.spec_registration, limit=1] run return 0
scoreboard players set #spec_count cachecache_state 0
execute as @a[tag=SpecChasses] run scoreboard players add #spec_count cachecache_state 1
tellraw @s [{text: "Specs participants avec le tag SpecChasses : ", color: "yellow"}, {score: {name: "#spec_count", objective: "cachecache_state"}, color: "white", bold: true}]
tellraw @s [{text: "Noms : ", color: "gray"}, {selector: "@a[tag=SpecChasses]", color: "white"}]
scoreboard players set #spec_missing cachecache_state 0
execute at @e[type=minecraft:marker, tag=cachecache.marker.spec_registration, limit=1] as @a[distance=..30, tag=!SpecChasses] unless entity @s[team=RTT] unless entity @s[team=Albertos] run function cache_cache_s32:admin/report_missing_spec
execute if score #spec_missing cachecache_state matches 0 run tellraw @s {text: "Verification OK : personne dans la zone n'a oublie le tag.", color: "green"}
execute if score #spec_missing cachecache_state matches 1.. run tellraw @s [{text: "ATTENTION : ", color: "red", bold: true}, {score: {name: "#spec_missing", objective: "cachecache_state"}, color: "red"}, {text: " personne(s) dans la zone n'ont pas le tag SpecChasses.", color: "red"}]

