
#> cache_cache_s32:admin/stage_after_round1
#
# @within	???
#

# Place les rôles de la manche 1 dans leurs zones d'attente respectives.
execute as @a[team=RTT, tag=!ChasseurMap1] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute as @a[team=Albertos, tag=!ChasseurMap1] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute as @a[tag=ChasseurMap1] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunter_hold, limit=1]
gamemode adventure @a[team=RTT]
gamemode adventure @a[team=Albertos]
tellraw @a {text: "[Cache-cache] Joueurs chass\u00e9s et chasseurs de la manche 1 plac\u00e9s dans leurs zones d'attente.", color: "yellow"}

