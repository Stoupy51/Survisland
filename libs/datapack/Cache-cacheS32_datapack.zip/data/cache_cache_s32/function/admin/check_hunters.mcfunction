
#> cache_cache_s32:admin/check_hunters
#
# @within	cache_cache_s32:admin/verify_hunters
#			cache_cache_s32:game/end_preparation
#

scoreboard players set #rtt1 cachecache_state 0
scoreboard players set #rtt2 cachecache_state 0
scoreboard players set #rtt3 cachecache_state 0
scoreboard players set #alb1 cachecache_state 0
scoreboard players set #alb2 cachecache_state 0
scoreboard players set #alb3 cachecache_state 0
execute as @a[team=RTT, tag=ChasseurMap1] run scoreboard players add #rtt1 cachecache_state 1
execute as @a[team=RTT, tag=ChasseurMap2] run scoreboard players add #rtt2 cachecache_state 1
execute as @a[team=RTT, tag=ChasseurMap3] run scoreboard players add #rtt3 cachecache_state 1
execute as @a[team=Albertos, tag=ChasseurMap1] run scoreboard players add #alb1 cachecache_state 1
execute as @a[team=Albertos, tag=ChasseurMap2] run scoreboard players add #alb2 cachecache_state 1
execute as @a[team=Albertos, tag=ChasseurMap3] run scoreboard players add #alb3 cachecache_state 1
tellraw @a [{text: "Chasseurs RTT : ", color: "aqua"}, {score: {name: "#rtt1", objective: "cachecache_state"}}, {text: " / "}, {score: {name: "#rtt2", objective: "cachecache_state"}}, {text: " / "}, {score: {name: "#rtt3", objective: "cachecache_state"}}, {text: " (attendu : 1 / 1 / 1)", color: "gray"}]
tellraw @a [{text: "Chasseurs Albertos : ", color: "red"}, {score: {name: "#alb1", objective: "cachecache_state"}}, {text: " / "}, {score: {name: "#alb2", objective: "cachecache_state"}}, {text: " / "}, {score: {name: "#alb3", objective: "cachecache_state"}}, {text: " (attendu : 1 / 1 / 1)", color: "gray"}]
execute unless score #rtt1 cachecache_state matches 1 run tellraw @a {text: "ATTENTION : il faut 1 chasseur RTT pour la map 1.", color: "red"}
execute unless score #rtt2 cachecache_state matches 1 run tellraw @a {text: "ATTENTION : il faut 1 chasseur RTT pour la map 2.", color: "red"}
execute unless score #rtt3 cachecache_state matches 1 run tellraw @a {text: "ATTENTION : il faut 1 chasseur RTT pour la map 3.", color: "red"}
execute unless score #alb1 cachecache_state matches 1 run tellraw @a {text: "ATTENTION : il faut 1 chasseur Albertos pour la map 1.", color: "red"}
execute unless score #alb2 cachecache_state matches 1 run tellraw @a {text: "ATTENTION : il faut 1 chasseur Albertos pour la map 2.", color: "red"}
execute unless score #alb3 cachecache_state matches 1 run tellraw @a {text: "ATTENTION : il faut 1 chasseur Albertos pour la map 3.", color: "red"}
execute as @a[team=RTT, tag=ChasseurMap1, tag=ChasseurMap2] run tellraw @a [{selector: "@s", color: "aqua"}, {text: " est chasseur RTT sur plusieurs maps.", color: "red"}]
execute as @a[team=RTT, tag=ChasseurMap1, tag=ChasseurMap3] run tellraw @a [{selector: "@s", color: "aqua"}, {text: " est chasseur RTT sur plusieurs maps.", color: "red"}]
execute as @a[team=RTT, tag=ChasseurMap2, tag=ChasseurMap3] run tellraw @a [{selector: "@s", color: "aqua"}, {text: " est chasseur RTT sur plusieurs maps.", color: "red"}]
execute as @a[team=Albertos, tag=ChasseurMap1, tag=ChasseurMap2] run tellraw @a [{selector: "@s", color: "red"}, {text: " est chasseur Albertos sur plusieurs maps.", color: "red"}]
execute as @a[team=Albertos, tag=ChasseurMap1, tag=ChasseurMap3] run tellraw @a [{selector: "@s", color: "red"}, {text: " est chasseur Albertos sur plusieurs maps.", color: "red"}]
execute as @a[team=Albertos, tag=ChasseurMap2, tag=ChasseurMap3] run tellraw @a [{selector: "@s", color: "red"}, {text: " est chasseur Albertos sur plusieurs maps.", color: "red"}]

