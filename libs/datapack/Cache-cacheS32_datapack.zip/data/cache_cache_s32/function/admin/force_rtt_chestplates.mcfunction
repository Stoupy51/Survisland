
#> cache_cache_s32:admin/force_rtt_chestplates
#
# @within	???
#

function cache_cache_s32:equipment/force_rtt
tellraw @a {text: "[Admin] Les plastrons RTT ont \u00e9t\u00e9 forc\u00e9s.", color: "green"}

