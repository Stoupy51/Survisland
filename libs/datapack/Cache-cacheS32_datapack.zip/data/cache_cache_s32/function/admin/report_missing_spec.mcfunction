
#> cache_cache_s32:admin/report_missing_spec
#
# @executed	at @e[type=minecraft:marker,tag=cachecache.marker.spec_registration,limit=1] & as @a[distance=..30,tag=!SpecChasses]
#
# @within	cache_cache_s32:admin/check_specs [ at @e[type=minecraft:marker,tag=cachecache.marker.spec_registration,limit=1] & as @a[distance=..30,tag=!SpecChasses] ]
#

scoreboard players add #spec_missing cachecache_state 1
tellraw @a [{text: "[Spec sans tag] ", color: "red"}, {selector: "@s", color: "white"}]

