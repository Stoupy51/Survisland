
#> cache_cache_s32:v0.0.1/tick
#
# @within	cache_cache_s32:v0.0.1/load/tick_verification
#

function cache_cache_s32:game/tick

