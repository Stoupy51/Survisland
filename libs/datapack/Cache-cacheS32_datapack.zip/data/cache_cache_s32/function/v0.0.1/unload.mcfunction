
#> cache_cache_s32:v0.0.1/unload
#
# @within	#cache_cache_s32:unload
#

# Remove scoreboard objectives
scoreboard objectives remove cache_cache_s32.data
scoreboard objectives remove cachecache_capture
scoreboard objectives remove cachecache_config
scoreboard objectives remove cachecache_deaths
scoreboard objectives remove cachecache_score
scoreboard objectives remove cachecache_shiny_sound
scoreboard objectives remove cachecache_state
scoreboard objectives remove cachecache_timer
scoreboard objectives remove load.status
scoreboard objectives remove survisland.temp.heart_beat

# Clear storages
data remove storage cache_cache_s32:config teams

