
#> cache_cache_s32:v0.0.1/load/resolve
#
# @within	#cache_cache_s32:resolve
#

# If correct version, load the datapack
execute if score #cache_cache_s32.major load.status matches 0 if score #cache_cache_s32.minor load.status matches 0 if score #cache_cache_s32.patch load.status matches 1 run function cache_cache_s32:v0.0.1/load/main

