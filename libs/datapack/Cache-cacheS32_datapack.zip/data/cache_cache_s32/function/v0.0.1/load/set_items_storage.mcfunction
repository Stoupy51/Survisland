
#> cache_cache_s32:v0.0.1/load/set_items_storage
#
# @within	cache_cache_s32:v0.0.1/load/confirm_load
#


