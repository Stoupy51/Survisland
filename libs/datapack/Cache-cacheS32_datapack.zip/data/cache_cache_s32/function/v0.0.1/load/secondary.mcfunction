
#> cache_cache_s32:v0.0.1/load/secondary
#
# @within	cache_cache_s32:v0.0.1/load/main
#

# Cache-cacheS32
scoreboard objectives add cache_cache_s32.data dummy
tag vauch add convention.debug

# Confirm load
function cache_cache_s32:v0.0.1/load/confirm_load

