
#> cache_cache_s32:v0.0.1/load/tick_verification
#
# @within	#minecraft:tick
#

execute if score #cache_cache_s32.major load.status matches 0 if score #cache_cache_s32.minor load.status matches 0 if score #cache_cache_s32.patch load.status matches 1 run function cache_cache_s32:v0.0.1/tick

