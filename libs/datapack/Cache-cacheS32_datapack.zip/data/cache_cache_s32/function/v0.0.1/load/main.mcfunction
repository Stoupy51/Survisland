
#> cache_cache_s32:v0.0.1/load/main
#
# @within	cache_cache_s32:v0.0.1/load/resolve
#

# Avoiding multiple executions of the same load function
execute unless score #cache_cache_s32.loaded load.status matches 1 run function cache_cache_s32:v0.0.1/load/secondary

