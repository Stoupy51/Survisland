
#> cache_cache_s32:v0.0.1/load/enumerate
#
# @within	#cache_cache_s32:enumerate
#

# If current major is too low, set it to the current major
execute unless score #cache_cache_s32.major load.status matches 0.. run scoreboard players set #cache_cache_s32.major load.status 0

# If current minor is too low, set it to the current minor (only if major is correct)
execute if score #cache_cache_s32.major load.status matches 0 unless score #cache_cache_s32.minor load.status matches 0.. run scoreboard players set #cache_cache_s32.minor load.status 0

# If current patch is too low, set it to the current patch (only if major and minor are correct)
execute if score #cache_cache_s32.major load.status matches 0 if score #cache_cache_s32.minor load.status matches 0 unless score #cache_cache_s32.patch load.status matches 1.. run scoreboard players set #cache_cache_s32.patch load.status 1

