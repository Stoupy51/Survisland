
#> cache_cache_s32:v0.0.1/load/confirm_load
#
# @within	cache_cache_s32:v0.0.1/load/secondary
#

# Confirm load
tellraw @a[tag=convention.debug] {text: "[Loaded Cache-cacheS32 v0.0.1]", color: "green"}
scoreboard players set #cache_cache_s32.loaded load.status 1
function cache_cache_s32:v0.0.1/load/set_items_storage

scoreboard objectives add cachecache_score dummy
scoreboard objectives add cachecache_timer dummy
scoreboard objectives add cachecache_state dummy
scoreboard objectives add cachecache_shiny_sound dummy
scoreboard objectives add cachecache_deaths deathCount
scoreboard objectives add cachecache_capture dummy {text: "Zone de capture", color: "gold", bold: true}
scoreboard objectives add cachecache_config dummy
scoreboard objectives add survisland.temp.heart_beat dummy
team add RTT {text: "RTT", color: "green"}
team add Albertos {text: "Albertos", color: "aqua"}
team modify RTT color green
team modify Albertos color aqua
scoreboard players add Albertos cachecache_score 0
scoreboard players add RTT cachecache_score 0
scoreboard players add #running cachecache_state 0
scoreboard players add #finished cachecache_state 0
scoreboard players add #phase cachecache_state 0
scoreboard players add #round cachecache_state 0
scoreboard players add #malus_team cachecache_state 0
scoreboard players add #malus_seconds cachecache_state 0
scoreboard players add #advantage_claimed cachecache_state 0
scoreboard players add #paused cachecache_state 0
scoreboard players add #score_event cachecache_state 0
scoreboard players add #rtt_reached cachecache_state 0
scoreboard players add #albertos_reached cachecache_state 0
execute unless data storage cache_cache_s32:config teams.rtt run data modify storage cache_cache_s32:config teams.rtt set value "RTT"
execute unless data storage cache_cache_s32:config teams.albertos run data modify storage cache_cache_s32:config teams.albertos set value "Albertos"
function cache_cache_s32:display/config
function cache_cache_s32:config/init
function cache_cache_s32:timer/convert
tellraw @a {text: "Cache-cacheS32 est charge !", color: "green"}

