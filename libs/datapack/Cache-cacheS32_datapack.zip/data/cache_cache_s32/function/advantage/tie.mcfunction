
#> cache_cache_s32:advantage/tie
#
# @within	cache_cache_s32:zone/map2_result
#

scoreboard players set #advantage_claimed cachecache_state 1
scoreboard players set #malus_team cachecache_state 0
tellraw @a [{text: "Zone de capture : egalite ! ", color: "gold", bold: true}, {text: "Aucune equipe ne recoit l'avantage.", color: "yellow"}]

