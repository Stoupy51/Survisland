
#> cache_cache_s32:advantage/albertos
#
# @executed	at @s
#
# @within	cache_cache_s32:zone/map1_tick [ at @s ]
#			cache_cache_s32:zone/map2_result
#

scoreboard players set #advantage_claimed cachecache_state 1
scoreboard players set #malus_team cachecache_state 1
tellraw @a [{text: "Avantage Albertos ! ", color: "aqua", bold: true}, {text: "Les chasseurs RTT partiront 20 secondes plus tard.", color: "yellow"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 0.8 1.2

