
#> cache_cache_s32:game/start_hunt_release
#
# @within	cache_cache_s32:admin/skip_hide
#			cache_cache_s32:game/start_hunt 130 replace [ scheduled ]
#			cache_cache_s32:game/start_hunt_countdown 130 replace [ scheduled ]
#			cache_cache_s32:game/start_hunt_release 1s replace [ scheduled ]
#

# Une pause pendant le décompte retarde la libération des chasseurs.
execute unless score #running cachecache_state matches 1 run return 0
execute unless score #phase cachecache_state matches 6 run return 0
execute if score #paused cachecache_state matches 1 run schedule function cache_cache_s32:game/start_hunt_release 1s replace
execute if score #paused cachecache_state matches 1 run return 0

scoreboard players set #phase cachecache_state 3
# Le score de capture reste visible jusqu'a la fin complete de la manche 2.
execute unless score #round cachecache_state matches 2 run scoreboard objectives setdisplay sidebar
function cache_cache_s32:effects/maintain
effect clear @a speed
effect clear @a resistance
execute if score #round cachecache_state matches 1 run tag @a[tag=ChasseurMap1] add survisland.seeker
execute if score #round cachecache_state matches 2 run tag @a[tag=ChasseurMap2] add survisland.seeker
execute if score #round cachecache_state matches 3 run tag @a[tag=ChasseurMap3] add survisland.seeker
execute as @a[tag=survisland.seeker] run function cache_cache_s32:equipment/hunter
gamemode adventure @a[tag=survisland.seeker]
effect clear @a[tag=survisland.seeker] strength
effect give @a[tag=survisland.seeker] speed infinite 1 true
effect give @a[tag=Chasses] minecraft:instant_health 1 10 true
effect give @a[tag=SpecChasses] minecraft:instant_health 1 10 true
effect give @a[tag=Chasses] minecraft:absorption infinite 4 true
effect give @a[tag=SpecChasses] minecraft:absorption infinite 4 true
execute if score #malus_team cachecache_state matches 1 run tag @a[tag=survisland.seeker, team=RTT] add Malus
execute if score #malus_team cachecache_state matches 2 run tag @a[tag=survisland.seeker, team=Albertos] add Malus
execute as @a[tag=survisland.seeker, tag=!Malus] at @s run function cache_cache_s32:game/to_current_map
execute as @a[tag=Malus] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunter_hold, limit=1]
execute if entity @a[tag=Malus] run scoreboard players set #malus_seconds cachecache_state 20

# Le titre principal vide affiche le message avec la petite taille d'un sous-titre.
title @a times 5 30 10
title @a subtitle {text: "Que la chasse commence !", color: "gold", bold: true}
title @a title {text: ""}
playsound minecraft:entity.ender_dragon.growl master @a ~ ~ ~ 0.7 1.2
execute if score #round cachecache_state matches 1 run function cache_cache_s32:timer/start_config {source: "hunt1"}
execute if score #round cachecache_state matches 2 run function cache_cache_s32:timer/start_config {source: "hunt2"}
execute if score #round cachecache_state matches 3 run function cache_cache_s32:timer/start_config {source: "hunt3"}

