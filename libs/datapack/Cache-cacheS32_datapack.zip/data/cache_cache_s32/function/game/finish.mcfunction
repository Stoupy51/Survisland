
#> cache_cache_s32:game/finish
#
# @within	cache_cache_s32:game/end_hunt
#

scoreboard players set #running cachecache_state 0
scoreboard players set #finished cachecache_state 1
tellraw @a [{text: "Score final - RTT : ", color: "green"}, {score: {name: "RTT", objective: "cachecache_score"}, bold: true}, {text: " | Albertos : ", color: "aqua"}, {score: {name: "Albertos", objective: "cachecache_score"}, bold: true}]
execute if score RTT cachecache_score > Albertos cachecache_score run title @a title {text: "Victoire des RTT !", color: "green", bold: true}
execute if score Albertos cachecache_score > RTT cachecache_score run title @a title {text: "Victoire des Albertos !", color: "aqua", bold: true}
execute if score RTT cachecache_score = Albertos cachecache_score if score #rtt_reached cachecache_state <= #albertos_reached cachecache_state run title @a title {text: "Victoire des RTT au departage !", color: "green", bold: true}
execute if score RTT cachecache_score = Albertos cachecache_score if score #albertos_reached cachecache_state < #rtt_reached cachecache_state run title @a title {text: "Victoire des Albertos au departage !", color: "aqua", bold: true}
execute if score RTT cachecache_score = Albertos cachecache_score if score #rtt_reached cachecache_state <= #albertos_reached cachecache_state run tellraw @a {text: "Score \u00e9gal : RTT a atteint ce score en premier.", color: "green"}
execute if score RTT cachecache_score = Albertos cachecache_score if score #albertos_reached cachecache_state < #rtt_reached cachecache_state run tellraw @a {text: "Score \u00e9gal : Albertos a atteint ce score en premier.", color: "aqua"}
function cache_cache_s32:game/cleanup

