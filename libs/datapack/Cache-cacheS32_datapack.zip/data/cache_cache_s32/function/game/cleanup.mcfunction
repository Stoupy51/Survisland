
#> cache_cache_s32:game/cleanup
#
# @within	cache_cache_s32:game/abort
#			cache_cache_s32:game/finish
#

function cache_cache_s32:integration/survisland/heart_beat_stop
function cache_cache_s32:equipment/clear
scoreboard players set #running cachecache_state 0
scoreboard players set #phase cachecache_state 0
scoreboard players set #paused cachecache_state 0
scoreboard objectives setdisplay sidebar
effect clear @a speed
effect clear @a strength
effect clear @a resistance
effect clear @a saturation
effect clear @a absorption
execute as @a[team=RTT] run attribute @s minecraft:fall_damage_multiplier base set 1
execute as @a[team=Albertos] run attribute @s minecraft:fall_damage_multiplier base set 1
execute as @a[tag=SpecChasses] run attribute @s minecraft:fall_damage_multiplier base set 1
execute as @a[team=RTT] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.middle, limit=1]
execute as @a[team=Albertos] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.middle, limit=1]
execute as @a[tag=SpecChasses] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.middle, limit=1]
gamemode spectator @a[tag=SpecChasses]
tag @a remove survisland.seeker
tag @a remove survisland.alive
tag @a remove Chasses
tag @a remove Malus
tag @a remove ChasseurMap1
tag @a remove ChasseurMap2
tag @a remove ChasseurMap3
tag @a remove shiny
tag @a remove cachecache.selection_warned
tag @a remove cachecache.on_selection_plate
scoreboard players reset @a cachecache_deaths
scoreboard players reset RTT cachecache_capture
scoreboard players reset Albertos cachecache_capture
title @a actionbar {text: ""}

