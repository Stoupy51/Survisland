
#> cache_cache_s32:game/phase_end
#
# @within	cache_cache_s32:timer/second
#

# Memorise la phase qui vient de se terminer. Les fonctions appelees changent #phase :
# sans cette copie, la fin de transition pouvait lancer cachette puis chasse au meme tick.
scoreboard players operation #ended_phase cachecache_state = #phase cachecache_state
execute if score #ended_phase cachecache_state matches 4 run function cache_cache_s32:game/next_round
execute if score #ended_phase cachecache_state matches 3 run function cache_cache_s32:game/end_hunt
execute if score #ended_phase cachecache_state matches 2 run function cache_cache_s32:game/start_hunt
execute if score #ended_phase cachecache_state matches 1 run function cache_cache_s32:game/end_preparation

