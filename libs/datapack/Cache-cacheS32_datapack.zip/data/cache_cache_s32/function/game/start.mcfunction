
#> cache_cache_s32:game/start
#
# @within	???
#

execute if score #running cachecache_state matches 1 run tellraw @s {text: "Une partie est deja en cours.", color: "red"}
execute if score #running cachecache_state matches 1 run return 0
function cache_cache_s32:setup/check
execute unless score #setup_ok cachecache_state matches 16 run return 0
scoreboard players set RTT cachecache_score 0
scoreboard players set Albertos cachecache_score 0
scoreboard players set #round cachecache_state 0
scoreboard players set #phase cachecache_state 1
scoreboard players set #running cachecache_state 1
scoreboard players set #paused cachecache_state 0
scoreboard players set #finished cachecache_state 0
scoreboard players set #malus_team cachecache_state 0
scoreboard players set #advantage_claimed cachecache_state 0
scoreboard players set #score_event cachecache_state 0
scoreboard players set #rtt_reached cachecache_state 0
scoreboard players set #albertos_reached cachecache_state 0
scoreboard players reset @a cachecache_deaths
tag @a remove cachecache.selection_warned
tag @a remove cachecache.on_selection_plate
scoreboard objectives setdisplay sidebar
execute as @a[team=RTT] run attribute @s minecraft:fall_damage_multiplier base set 0
execute as @a[team=Albertos] run attribute @s minecraft:fall_damage_multiplier base set 0
execute as @a[tag=SpecChasses] run attribute @s minecraft:fall_damage_multiplier base set 0
function cache_cache_s32:admin/prepare_specs
function cache_cache_s32:effects/maintain
title @a actionbar [{text: "Choisissez vos chasseurs ! ", color: "gold", bold: true}, {text: "La selection reste ouverte jusqu'au lancement manuel", color: "yellow", bold: false}]
tellraw @a [{text: "[Cache-cache] ", color: "gold"}, {text: "Choisissez un chasseur different par map. L'organisateur lancera ensuite la manche 1.", color: "yellow"}]
playsound minecraft:block.note_block.pling master @a ~ ~ ~ 1 1.2
scoreboard players set #total cachecache_timer 0

