
#> cache_cache_s32:game/to_current_map
#
# @executed	as @a[tag=Malus] & at @s
#
# @within	cache_cache_s32:game/release_malus [ as @a[tag=Malus] & at @s ]
#			cache_cache_s32:game/start_hunt_release [ as @a[tag=...] & at @s ]
#

execute if score #round cachecache_state matches 1 run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map1, limit=1]
execute if score #round cachecache_state matches 2 run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map2, limit=1]
execute if score #round cachecache_state matches 3 run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map3, limit=1]

