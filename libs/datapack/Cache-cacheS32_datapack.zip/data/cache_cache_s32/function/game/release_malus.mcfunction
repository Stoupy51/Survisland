
#> cache_cache_s32:game/release_malus
#
# @within	cache_cache_s32:game/second
#

execute as @a[tag=Malus] at @s run function cache_cache_s32:game/to_current_map
title @a[tag=Malus] times 0 25 5
title @a[tag=Malus] title {text: "A vous de chasser !", color: "red", bold: true}
playsound minecraft:block.note_block.pling master @a[tag=Malus] ~ ~ ~ 1 1.4
tag @a[tag=Malus] remove Malus

