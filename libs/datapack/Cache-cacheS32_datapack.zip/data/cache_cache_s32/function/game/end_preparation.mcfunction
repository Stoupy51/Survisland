
#> cache_cache_s32:game/end_preparation
#
# @within	cache_cache_s32:game/phase_end
#

function cache_cache_s32:admin/check_hunters
function cache_cache_s32:game/start_hide

