
#> cache_cache_s32:game/tick
#
# @within	cache_cache_s32:v0.0.1/tick
#

execute if score #paused cachecache_state matches 1 run return 0
execute if score #running cachecache_state matches 1 if score #phase cachecache_state matches 1 run function cache_cache_s32:selection/tick
execute if score #running cachecache_state matches 1 if score #phase cachecache_state matches 2..4 run function cache_cache_s32:timer/tick
execute if score #running cachecache_state matches 1 if score #phase cachecache_state matches 2 if score #round cachecache_state matches 1 run function cache_cache_s32:zone/map1_tick
# Maintient le score de capture visible pendant toute la recherche de la manche 2,
# meme si le compteur Survisland ou un autre datapack modifie le sidebar.
execute if score #running cachecache_state matches 1 if score #phase cachecache_state matches 3 if score #round cachecache_state matches 2 run scoreboard objectives setdisplay sidebar cachecache_capture
execute if score #running cachecache_state matches 1 if score #phase cachecache_state matches 3 as @a[scores={cachecache_deaths=1..}] at @s run function cache_cache_s32:death/process
execute if score #running cachecache_state matches 1 if score #phase cachecache_state matches 3 unless entity @a[tag=Chasses, tag=survisland.alive] unless entity @a[tag=SpecChasses, tag=survisland.alive] run function cache_cache_s32:game/end_hunt
execute if score #running cachecache_state matches 1 if score #phase cachecache_state matches 3 run function cache_cache_s32:integration/survisland/heart_beat

