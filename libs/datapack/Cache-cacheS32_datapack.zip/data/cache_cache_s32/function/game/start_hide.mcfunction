
#> cache_cache_s32:game/start_hide
#
# @within	cache_cache_s32:admin/force_round1
#			cache_cache_s32:admin/force_round2
#			cache_cache_s32:admin/force_round3
#			cache_cache_s32:game/end_preparation
#			cache_cache_s32:game/next_round
#

execute if score #round cachecache_state matches 0 run scoreboard players set #round cachecache_state 1
scoreboard players set #phase cachecache_state 2
scoreboard players set #hunt_countdown cachecache_state 0
scoreboard players set #malus_seconds cachecache_state 0
# L'avantage gagne en manche 2 doit rester actif jusqu'au depart des chasseurs de la manche 3.
execute unless score #round cachecache_state matches 3 run scoreboard players set #malus_team cachecache_state 0
execute unless score #round cachecache_state matches 3 run scoreboard players set #advantage_claimed cachecache_state 0
execute if score #round cachecache_state matches 2 run scoreboard players set RTT cachecache_capture 0
execute if score #round cachecache_state matches 2 run scoreboard players set Albertos cachecache_capture 0
execute as @a[team=RTT] run attribute @s minecraft:fall_damage_multiplier base set 0
execute as @a[team=Albertos] run attribute @s minecraft:fall_damage_multiplier base set 0
execute as @a[tag=SpecChasses] run attribute @s minecraft:fall_damage_multiplier base set 0
tag @a remove Chasses
tag @a remove survisland.seeker
tag @a remove survisland.alive
tag @a remove Malus
effect clear @a speed
effect clear @a strength
effect clear @a resistance
effect clear @a absorption
scoreboard players reset @a cachecache_deaths
execute if score #round cachecache_state matches 1 run function cache_cache_s32:game/round1_hide
execute if score #round cachecache_state matches 2 run function cache_cache_s32:game/round2_hide
execute if score #round cachecache_state matches 3 run function cache_cache_s32:game/round3_hide
function cache_cache_s32:equipment/apply_round
tag @a[tag=Chasses] add survisland.alive
tag @a[tag=SpecChasses] add survisland.alive
gamemode adventure @a[tag=Chasses]
gamemode adventure @a[tag=SpecChasses]
effect give @a[tag=Chasses] speed 185 0 true
effect give @a[tag=SpecChasses] speed 185 0 true
function cache_cache_s32:effects/maintain
title @a times 5 35 10
title @a subtitle {text: "Trouvez une cachette avant la fin du chrono", color: "green"}
title @a title {text: "Cachez-vous !", color: "dark_green", bold: true}
playsound minecraft:block.note_block.chime master @a ~ ~ ~ 1 1.1
execute if score #round cachecache_state matches 1 run function cache_cache_s32:timer/start_config {source: "hide1"}
execute if score #round cachecache_state matches 2 run function cache_cache_s32:timer/start_config {source: "hide2"}
execute if score #round cachecache_state matches 3 run function cache_cache_s32:timer/start_config {source: "hide3"}

