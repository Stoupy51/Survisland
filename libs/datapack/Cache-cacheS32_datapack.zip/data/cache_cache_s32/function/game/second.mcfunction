
#> cache_cache_s32:game/second
#
# @within	cache_cache_s32:timer/second
#

function cache_cache_s32:effects/maintain
execute if score #phase cachecache_state matches 2..3 if score #round cachecache_state matches 2 run function cache_cache_s32:zone/map2_tick
execute if score #phase cachecache_state matches 3 if score #malus_seconds cachecache_state matches 1.. run scoreboard players remove #malus_seconds cachecache_state 1
execute if score #phase cachecache_state matches 3 if score #malus_seconds cachecache_state matches 0 if entity @a[tag=Malus] run function cache_cache_s32:game/release_malus

