
#> cache_cache_s32:game/start_hunt
#
# @within	cache_cache_s32:game/phase_end
#

# Lance le compteur Survisland avant de libérer les chasseurs.
execute if score #hunt_countdown cachecache_state matches 1 run scoreboard players set #phase cachecache_state 6
execute if score #hunt_countdown cachecache_state matches 1 run return 0
scoreboard players set #phase cachecache_state 6
scoreboard players set #total cachecache_timer 0
data modify storage survisland:main compteur set value {decompte: 5, sounds: {xp: 1b, goat_horn: 1b, wither: 0b}, title: [{text: ""}]}
function survisland:_compteur
schedule function cache_cache_s32:game/start_hunt_release 130 replace

