
#> cache_cache_s32:game/transition/after_round2
#
# @within	cache_cache_s32:game/end_hunt
#

# Tous les joueurs, trouves ou non, attendent ensemble.
# Seuls les chasseurs de la manche 3 vont dans l'autre salle.
execute as @a[team=RTT, tag=!ChasseurMap3] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute as @a[team=Albertos, tag=!ChasseurMap3] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1]
execute as @a[tag=ChasseurMap2] run function cache_cache_s32:equipment/force_team_player
tag @a[tag=ChasseurMap2] remove survisland.seeker
tag @a[tag=ChasseurMap2] add Chasses
tag @a[tag=ChasseurMap2] remove ChasseurMap2

# Les chasseurs de la manche 3 sont prepares dans leur zone.
tag @a[tag=ChasseurMap3] remove Chasses
tag @a[tag=ChasseurMap3] add survisland.seeker
execute as @a[tag=ChasseurMap3] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunter_hold, limit=1]
execute as @a[tag=ChasseurMap3] run function cache_cache_s32:equipment/force_hunter

