
#> cache_cache_s32:game/round3_hide
#
# @within	cache_cache_s32:game/start_hide
#

tag @a[team=RTT, tag=!ChasseurMap3, tag=!SpecChasses] add Chasses
tag @a[team=Albertos, tag=!ChasseurMap3, tag=!SpecChasses] add Chasses
execute as @a[tag=Chasses] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map3, limit=1]
execute as @a[tag=ChasseurMap3] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.hunter_hold, limit=1]
gamemode adventure @a[tag=ChasseurMap3]

