
#> cache_cache_s32:game/start_hunt_countdown
#
# @within	cache_cache_s32:timer/second
#

# Lance le compteur Survisland pendant les six dernieres secondes de cachette.
scoreboard players set #hunt_countdown cachecache_state 1
data modify storage survisland:main compteur set value {decompte: 5, sounds: {xp: 1b, goat_horn: 1b, wither: 0b}, title: [{text: ""}]}
function survisland:_compteur
schedule function cache_cache_s32:game/start_hunt_release 130 replace

