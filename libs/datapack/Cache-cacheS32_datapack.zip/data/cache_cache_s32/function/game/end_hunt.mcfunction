
#> cache_cache_s32:game/end_hunt
#
# @within	cache_cache_s32:game/phase_end
#			cache_cache_s32:game/tick
#

# La zone de la map 2 est departagee seulement maintenant, une seule fois.
execute if score #round cachecache_state matches 2 if score #advantage_claimed cachecache_state matches 0 run function cache_cache_s32:zone/map2_result
execute if score #round cachecache_state matches 2 run scoreboard objectives setdisplay sidebar

# Points des joueurs chasses qui n'ont pas ete trouves.
execute as @a[tag=Chasses, tag=survisland.alive, team=RTT] run function cache_cache_s32:score/rtt/add_5
execute as @a[tag=Chasses, tag=survisland.alive, team=Albertos] run function cache_cache_s32:score/albertos/add_5
tellraw @a [{text: "[Cache-cache] ", color: "gold"}, {text: "+5 points par joueur non trouve.", color: "green"}]

function cache_cache_s32:integration/survisland/heart_beat_stop
tag @a remove Malus
effect clear @a speed
effect clear @a strength
effect clear @a resistance
effect clear @a absorption
gamemode adventure @a[team=RTT]
gamemode adventure @a[team=Albertos]

# Les specs passent directement a la map suivante. La map 3 les ramene au centre.
execute if score #round cachecache_state matches 1 as @a[tag=SpecChasses, tag=survisland.alive] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map2, limit=1]
execute if score #round cachecache_state matches 2 as @a[tag=SpecChasses, tag=survisland.alive] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map3, limit=1]
execute if score #round cachecache_state matches 3 as @a[tag=SpecChasses, tag=survisland.alive] at @s run tp @s @e[type=minecraft:marker, tag=cachecache.marker.middle, limit=1]

# La derniere manche termine directement la partie.
execute if score #round cachecache_state matches 3 run function cache_cache_s32:game/finish
execute if score #round cachecache_state matches 3 run return 0

# Preparation des anciens et nouveaux roles dans leurs zones d'attente.
execute if score #round cachecache_state matches 1 run function cache_cache_s32:game/transition/after_round1
execute if score #round cachecache_state matches 2 run function cache_cache_s32:game/transition/after_round2
tag @a remove survisland.alive

# Transition automatique de 20 secondes avant la cachette suivante.
scoreboard players set #phase cachecache_state 4
scoreboard players set #intermission cachecache_config 20
function cache_cache_s32:timer/start_config {source: "intermission"}
tellraw @a [{text: "[Cache-cache] ", color: "gold"}, {text: "Prochaine manche automatique dans 20 secondes.", color: "yellow"}]

