
#> cache_cache_s32:game/next_round
#
# @within	cache_cache_s32:game/phase_end
#

scoreboard players add #round cachecache_state 1
function cache_cache_s32:game/start_hide

