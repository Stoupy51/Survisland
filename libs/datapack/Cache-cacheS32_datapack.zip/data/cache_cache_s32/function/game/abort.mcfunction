
#> cache_cache_s32:game/abort
#
# @within	cache_cache_s32:admin/stop
#

schedule clear cache_cache_s32:game/start_hunt_release
execute if score #phase cachecache_state matches 6 run schedule clear survisland:utils/compteur_schedule
title @a clear
tellraw @a {text: "La partie de cache-cache a ete arretee.", color: "red"}
function cache_cache_s32:game/cleanup

