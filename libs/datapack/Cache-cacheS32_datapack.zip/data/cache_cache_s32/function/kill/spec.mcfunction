
#> cache_cache_s32:kill/spec
#
# @executed	as the player & at current position
#
# @within	advancement cache_cache_s32:kill/spec
#

advancement revoke @s only cache_cache_s32:kill/spec
# Le score est désormais attribué au coup détecté, pas à la mort.

