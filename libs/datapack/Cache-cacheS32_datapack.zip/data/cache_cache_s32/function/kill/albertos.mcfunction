
#> cache_cache_s32:kill/albertos
#
# @executed	as the player & at current position
#
# @within	advancement cache_cache_s32:kill/albertos
#

advancement revoke @s only cache_cache_s32:kill/albertos
# Le score est désormais attribué au coup détecté, pas à la mort.

