
#> cache_cache_s32:kill/rtt
#
# @executed	as the player & at current position
#
# @within	advancement cache_cache_s32:kill/rtt
#

advancement revoke @s only cache_cache_s32:kill/rtt
# Le score est désormais attribué au coup détecté, pas à la mort.

