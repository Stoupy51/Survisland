
#> cache_cache_s32:selection/assign_albertos_map1
#
# @executed	at @s & as @p[distance=..1.25,team=Albertos,tag=!...,limit=1]
#
# @within	cache_cache_s32:selection/tick [ at @s & as @p[distance=..1.25,team=Albertos,tag=!...,limit=1] ]
#

tag @s add ChasseurMap1
title @s actionbar {text: "Vous etes le chasseur Albertos de la map 1 !", color: "aqua", bold: true}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.4
tellraw @a [{selector: "@s", color: "aqua"}, {text: " devient chasseur Albertos de la map 1.", color: "yellow"}]

