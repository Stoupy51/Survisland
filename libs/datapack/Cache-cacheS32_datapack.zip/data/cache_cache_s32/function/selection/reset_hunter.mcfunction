
#> cache_cache_s32:selection/reset_hunter
#
# @executed	at @s & as @p[distance=..1.25,tag=ChasseurMap1,limit=1]
#
# @within	cache_cache_s32:selection/tick [ at @s & as @p[distance=..1.25,tag=ChasseurMap1,limit=1] ]
#			cache_cache_s32:selection/tick [ at @s & as @p[distance=..1.25,tag=ChasseurMap2,limit=1] ]
#			cache_cache_s32:selection/tick [ at @s & as @p[distance=..1.25,tag=ChasseurMap3,limit=1] ]
#

tag @s remove ChasseurMap1
tag @s remove ChasseurMap2
tag @s remove ChasseurMap3
title @s actionbar {text: "S\u00e9lection de chasseur annul\u00e9e.", color: "red", bold: true}
playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.8
tellraw @a [{selector: "@s", color: "white"}, {text: " annule sa s\u00e9lection de chasseur.", color: "yellow"}]

