
#> cache_cache_s32:selection/wrong_plate
#
# @executed	at @s & as @p[distance=..1.25,team=RTT,tag=...,limit=1]
#
# @within	cache_cache_s32:selection/tick [ at @s & as @p[distance=..1.25,team=RTT,tag=...,limit=1] ]
#			cache_cache_s32:selection/tick [ at @s & as @p[distance=..1.25,team=Albertos,tag=...,limit=1] ]
#

tag @s add cachecache.selection_warned
title @s actionbar {text: "Vous \u00eates d\u00e9j\u00e0 chasseur sur une autre map !", color: "red", bold: true}
tellraw @s {text: "Passez d'abord sur la plaque RESET pour changer de map.", color: "yellow"}
playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.7

