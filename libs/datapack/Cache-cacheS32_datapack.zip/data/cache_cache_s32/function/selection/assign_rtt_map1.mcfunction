
#> cache_cache_s32:selection/assign_rtt_map1
#
# @executed	at @s & as @p[distance=..1.25,team=RTT,tag=!...,limit=1]
#
# @within	cache_cache_s32:selection/tick [ at @s & as @p[distance=..1.25,team=RTT,tag=!...,limit=1] ]
#

tag @s add ChasseurMap1
title @s actionbar {text: "Vous etes le chasseur RTT de la map 1 !", color: "green", bold: true}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.4
tellraw @a [{selector: "@s", color: "green"}, {text: " devient chasseur RTT de la map 1.", color: "yellow"}]

