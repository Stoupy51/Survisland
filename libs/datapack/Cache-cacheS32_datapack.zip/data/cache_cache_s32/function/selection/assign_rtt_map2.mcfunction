
#> cache_cache_s32:selection/assign_rtt_map2
#
# @executed	at @s & as @p[distance=..1.25,team=RTT,tag=!...,limit=1]
#
# @within	cache_cache_s32:selection/tick [ at @s & as @p[distance=..1.25,team=RTT,tag=!...,limit=1] ]
#

tag @s add ChasseurMap2
title @s actionbar {text: "Vous etes le chasseur RTT de la map 2 !", color: "green", bold: true}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.4
tellraw @a [{selector: "@s", color: "green"}, {text: " devient chasseur RTT de la map 2.", color: "yellow"}]

