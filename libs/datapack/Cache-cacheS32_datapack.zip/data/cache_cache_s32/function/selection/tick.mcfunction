
#> cache_cache_s32:selection/tick
#
# @within	cache_cache_s32:game/tick
#

# Seules les sept plaques enregistrées peuvent modifier les tags de chasseurs.
# L'avertissement est réarmé lorsque le joueur quitte les plaques.
tag @a remove cachecache.on_selection_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.selection] at @s as @a[distance=..1.25] run tag @s add cachecache.on_selection_plate
tag @a[tag=!cachecache.on_selection_plate] remove cachecache.selection_warned

# Avertissement RTT si le joueur essaie de choisir une autre map.
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map1, limit=1] at @s as @p[distance=..1.25, team=RTT, tag=ChasseurMap2, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map1, limit=1] at @s as @p[distance=..1.25, team=RTT, tag=ChasseurMap3, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map2, limit=1] at @s as @p[distance=..1.25, team=RTT, tag=ChasseurMap1, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map2, limit=1] at @s as @p[distance=..1.25, team=RTT, tag=ChasseurMap3, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map3, limit=1] at @s as @p[distance=..1.25, team=RTT, tag=ChasseurMap1, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map3, limit=1] at @s as @p[distance=..1.25, team=RTT, tag=ChasseurMap2, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate

# Avertissement Albertos si le joueur essaie de choisir une autre map.
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map1, limit=1] at @s as @p[distance=..1.25, team=Albertos, tag=ChasseurMap2, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map1, limit=1] at @s as @p[distance=..1.25, team=Albertos, tag=ChasseurMap3, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map2, limit=1] at @s as @p[distance=..1.25, team=Albertos, tag=ChasseurMap1, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map2, limit=1] at @s as @p[distance=..1.25, team=Albertos, tag=ChasseurMap3, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map3, limit=1] at @s as @p[distance=..1.25, team=Albertos, tag=ChasseurMap1, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map3, limit=1] at @s as @p[distance=..1.25, team=Albertos, tag=ChasseurMap2, tag=!cachecache.selection_warned, limit=1] run function cache_cache_s32:selection/wrong_plate

# Attribution normale : une place par équipe et par map, un seul rôle par joueur.
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map1, limit=1] at @s if block ~ ~ ~ minecraft:heavy_weighted_pressure_plate unless entity @a[team=RTT, tag=ChasseurMap1] as @p[distance=..1.25, team=RTT, tag=!ChasseurMap1, tag=!ChasseurMap2, tag=!ChasseurMap3, limit=1] run function cache_cache_s32:selection/assign_rtt_map1
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map2, limit=1] at @s if block ~ ~ ~ minecraft:heavy_weighted_pressure_plate unless entity @a[team=RTT, tag=ChasseurMap2] as @p[distance=..1.25, team=RTT, tag=!ChasseurMap1, tag=!ChasseurMap2, tag=!ChasseurMap3, limit=1] run function cache_cache_s32:selection/assign_rtt_map2
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map3, limit=1] at @s if block ~ ~ ~ minecraft:heavy_weighted_pressure_plate unless entity @a[team=RTT, tag=ChasseurMap3] as @p[distance=..1.25, team=RTT, tag=!ChasseurMap1, tag=!ChasseurMap2, tag=!ChasseurMap3, limit=1] run function cache_cache_s32:selection/assign_rtt_map3
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map1, limit=1] at @s if block ~ ~ ~ minecraft:heavy_weighted_pressure_plate unless entity @a[team=Albertos, tag=ChasseurMap1] as @p[distance=..1.25, team=Albertos, tag=!ChasseurMap1, tag=!ChasseurMap2, tag=!ChasseurMap3, limit=1] run function cache_cache_s32:selection/assign_albertos_map1
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map2, limit=1] at @s if block ~ ~ ~ minecraft:heavy_weighted_pressure_plate unless entity @a[team=Albertos, tag=ChasseurMap2] as @p[distance=..1.25, team=Albertos, tag=!ChasseurMap1, tag=!ChasseurMap2, tag=!ChasseurMap3, limit=1] run function cache_cache_s32:selection/assign_albertos_map2
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map3, limit=1] at @s if block ~ ~ ~ minecraft:heavy_weighted_pressure_plate unless entity @a[team=Albertos, tag=ChasseurMap3] as @p[distance=..1.25, team=Albertos, tag=!ChasseurMap1, tag=!ChasseurMap2, tag=!ChasseurMap3, limit=1] run function cache_cache_s32:selection/assign_albertos_map3

# La plaque RESET est commune aux deux équipes et uniquement valide à son emplacement enregistré.
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.reset, limit=1] at @s if block ~ ~ ~ minecraft:stone_pressure_plate as @p[distance=..1.25, tag=ChasseurMap1, limit=1] run function cache_cache_s32:selection/reset_hunter
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.reset, limit=1] at @s if block ~ ~ ~ minecraft:stone_pressure_plate as @p[distance=..1.25, tag=ChasseurMap2, limit=1] run function cache_cache_s32:selection/reset_hunter
execute as @e[type=minecraft:marker, tag=cachecache.marker.select.reset, limit=1] at @s if block ~ ~ ~ minecraft:stone_pressure_plate as @p[distance=..1.25, tag=ChasseurMap3, limit=1] run function cache_cache_s32:selection/reset_hunter

