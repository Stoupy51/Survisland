
#> cache_cache_s32:integration/survisland/heart_beat
#
# @within	cache_cache_s32:game/tick
#

# Survisland keeps its regular heartbeat for every living hidden player except
# the player carrying the shiny tag.
execute as @a[tag=survisland.alive, tag=!survisland.seeker, tag=!shiny] at @s run function survisland:modes/cache_cache/heart_beat

# The shiny player hears the Lucky Pal sound instead of the regular heartbeat.
execute as @a[tag=survisland.alive, tag=!survisland.seeker, tag=shiny] at @s run function cache_cache_s32:integration/survisland/shiny_heart_beat

