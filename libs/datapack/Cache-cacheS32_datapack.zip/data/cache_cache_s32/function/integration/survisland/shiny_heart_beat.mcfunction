
#> cache_cache_s32:integration/survisland/shiny_heart_beat
#
# @executed	as @a[tag=...] & at @s
#
# @within	cache_cache_s32:integration/survisland/heart_beat [ as @a[tag=...] & at @s ]
#

# This function runs as and at the living hidden player tagged shiny.
# The Lucky Pal sound lasts eight seconds, so it uses its own 160-tick cooldown
# instead of following the much faster regular heartbeat pulses.
scoreboard players add @s cachecache_shiny_sound 0

# Stop and reset the custom sound as soon as no seeker is within detection range.
execute unless entity @a[distance=0.001..32, tag=survisland.seeker] if score @s cachecache_shiny_sound matches 1.. run stopsound @s ambient cache_cache_s32:palworld_lucky_shining
execute unless entity @a[distance=0.001..32, tag=survisland.seeker] run scoreboard players set @s cachecache_shiny_sound 0

# Start one eight-second cycle when a seeker enters the 32-block detection range.
execute if entity @a[distance=0.001..32, tag=survisland.seeker] run scoreboard players add @s cachecache_shiny_sound 1
execute if score @s cachecache_shiny_sound matches 1 unless entity @a[distance=0.001..16, tag=survisland.seeker] if entity @a[distance=16..32, tag=survisland.seeker] run playsound cache_cache_s32:palworld_lucky_shining ambient @s ~ ~ ~ 0.5 1
execute if score @s cachecache_shiny_sound matches 1 unless entity @a[distance=0.001..8, tag=survisland.seeker] if entity @a[distance=8..16, tag=survisland.seeker] run playsound cache_cache_s32:palworld_lucky_shining ambient @s ~ ~ ~ 0.75 1
execute if score @s cachecache_shiny_sound matches 1 if entity @a[distance=0.001..8, tag=survisland.seeker] run playsound cache_cache_s32:palworld_lucky_shining ambient @s ~ ~ ~ 1 1

# Allow the next cycle after the current sound has finished.
execute if score @s cachecache_shiny_sound matches 160.. run scoreboard players set @s cachecache_shiny_sound 0

