
#> cache_cache_s32:integration/survisland/heart_beat_stop
#
# @within	cache_cache_s32:admin/pause
#			cache_cache_s32:game/cleanup
#			cache_cache_s32:game/end_hunt
#			cache_cache_s32:timer/end
#			cache_cache_s32:timer/stop
#

scoreboard players reset @a survisland.temp.heart_beat
scoreboard players reset @a cachecache_shiny_sound
stopsound @a[tag=shiny] ambient cache_cache_s32:palworld_lucky_shining

