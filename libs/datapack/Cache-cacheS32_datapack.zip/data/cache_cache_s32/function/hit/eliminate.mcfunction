
#> cache_cache_s32:hit/eliminate
#
# @executed	as the player & at current position
#
# @within	cache_cache_s32:hit/by_albertos
#			cache_cache_s32:hit/by_rtt
#

effect give @s minecraft:instant_health 1 10 true
execute if entity @s[tag=SpecChasses] run function cache_cache_s32:death/spec
execute unless entity @s[tag=SpecChasses] if entity @s[tag=Chasses] run function cache_cache_s32:death/player

