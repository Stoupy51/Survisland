
#> cache_cache_s32:hit/detected
#
# @executed	as the player & at current position
#
# @within	advancement cache_cache_s32:hit/detected
#

# Cette fonction est executee en tant que joueur touche.
advancement revoke @s only cache_cache_s32:hit/detected
scoreboard players set #hit_team cachecache_state 0
execute on attacker if entity @s[type=minecraft:player, team=RTT, tag=survisland.seeker] if items entity @s weapon.mainhand minecraft:netherite_sword[minecraft:custom_data~{cache_cache_s32: {hunter_weapon: 1b}}] run scoreboard players set #hit_team cachecache_state 1
execute on attacker if entity @s[type=minecraft:player, team=Albertos, tag=survisland.seeker] if items entity @s weapon.mainhand minecraft:netherite_sword[minecraft:custom_data~{cache_cache_s32: {hunter_weapon: 1b}}] run scoreboard players set #hit_team cachecache_state 2
execute if score #hit_team cachecache_state matches 1 run function cache_cache_s32:hit/by_rtt
execute if score #hit_team cachecache_state matches 2 run function cache_cache_s32:hit/by_albertos

