
#> cache_cache_s32:hit/by_albertos
#
# @executed	as the player & at current position
#
# @within	cache_cache_s32:hit/detected
#

execute unless score #running cachecache_state matches 1 run return 0
execute unless score #phase cachecache_state matches 3 run return 0
execute unless entity @s[tag=survisland.alive, tag=!survisland.seeker] run return 0
execute if entity @s[tag=SpecChasses] run function cache_cache_s32:score/albertos/add
execute unless entity @s[tag=SpecChasses] if entity @s[tag=Chasses, team=RTT] run function cache_cache_s32:score/albertos/add_3
execute unless entity @s[tag=SpecChasses] if entity @s[tag=Chasses, team=Albertos] run function cache_cache_s32:score/albertos/remove_3
function cache_cache_s32:hit/eliminate

