
#> cache_cache_s32:team/show
#
# @within	???
#

tellraw @s [{text: "Correspondance des \u00e9quipes \u2014 RTT : ", color: "green"}, {nbt: "teams.rtt", storage: "cache_cache_s32:config", color: "white"}, {text: " | Albertos : ", color: "aqua"}, {nbt: "teams.albertos", storage: "cache_cache_s32:config", color: "white"}]

