
#> cache_cache_s32:team/sync
#
# @within	cache_cache_s32:team/configure with storage cache_cache_s32:config teams
#
# @args		rtt (unknown)
#			albertos (unknown)
#

# Keep the datapack team tags aligned with the configured Minecraft teams.
tag @a remove cachecache_team_rtt
tag @a remove cachecache_team_albertos
$tag @a[team=$(rtt)] add cachecache_team_rtt
$tag @a[team=$(albertos)] add cachecache_team_albertos

