
#> cache_cache_s32:team/configure
#
# @within	string in cache_cache_s32:team/configure {rtt:"MinecraftTeam1",albertos:"MinecraftTeam2"}
#
# @args		rtt (string)
#			albertos (string)
#

# Usage: /function cache_cache_s32:team/configure {rtt:"MinecraftTeam1",albertos:"MinecraftTeam2"}
$data modify storage cache_cache_s32:config teams.rtt set value "$(rtt)"
$data modify storage cache_cache_s32:config teams.albertos set value "$(albertos)"
function cache_cache_s32:team/sync with storage cache_cache_s32:config teams
tellraw @s [{text: "\u00c9quipes configur\u00e9es \u2014 RTT : ", color: "green"}, {nbt: "teams.rtt", storage: "cache_cache_s32:config", color: "white"}, {text: " | Albertos : ", color: "aqua"}, {nbt: "teams.albertos", storage: "cache_cache_s32:config", color: "white"}]

