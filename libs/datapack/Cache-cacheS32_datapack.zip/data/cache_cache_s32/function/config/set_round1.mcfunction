
#> cache_cache_s32:config/set_round1
#
# @within	string in cache_cache_s32:config/set_round1 {hide:3,hunt:10}
#
# @args		hide (int)
#			hunt (int)
#

# Usage: /function cache_cache_s32:config/set_round1 {hide:3,hunt:10}
$scoreboard players set #hide1 cachecache_config $(hide)
scoreboard players operation #hide1 cachecache_config *= #sixty cachecache_timer
$scoreboard players set #hunt1 cachecache_config $(hunt)
scoreboard players operation #hunt1 cachecache_config *= #sixty cachecache_timer
function cache_cache_s32:config/show

