
#> cache_cache_s32:config/set_intermission
#
# @within	string in cache_cache_s32:config/set_intermission {seconds:30}
#
# @args		seconds (int)
#

# Usage: /function cache_cache_s32:config/set_intermission {seconds:30}
$scoreboard players set #intermission cachecache_config $(seconds)
function cache_cache_s32:config/show

