
#> cache_cache_s32:config/show
#
# @within	cache_cache_s32:config/set_intermission
#			cache_cache_s32:config/set_round1
#			cache_cache_s32:config/set_round2
#			cache_cache_s32:config/set_round3
#			cache_cache_s32:config/set_selection
#

tellraw @s [{text: "Chronos (secondes) - Selection: ", color: "gold"}, {score: {name: "#selection", objective: "cachecache_config"}}, {text: " | M1 cache/recherche: "}, {score: {name: "#hide1", objective: "cachecache_config"}}, {text: "/"}, {score: {name: "#hunt1", objective: "cachecache_config"}}, {text: " | M2: "}, {score: {name: "#hide2", objective: "cachecache_config"}}, {text: "/"}, {score: {name: "#hunt2", objective: "cachecache_config"}}, {text: " | M3: "}, {score: {name: "#hide3", objective: "cachecache_config"}}, {text: "/"}, {score: {name: "#hunt3", objective: "cachecache_config"}}, {text: " | Transition: "}, {score: {name: "#intermission", objective: "cachecache_config"}}]

