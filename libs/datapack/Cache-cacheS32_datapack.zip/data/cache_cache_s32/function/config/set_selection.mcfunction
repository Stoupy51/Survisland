
#> cache_cache_s32:config/set_selection
#
# @within	string in cache_cache_s32:config/set_selection {minutes:2}
#
# @args		minutes (int)
#

# Usage: /function cache_cache_s32:config/set_selection {minutes:2}
$scoreboard players set #selection cachecache_config $(minutes)
scoreboard players operation #selection cachecache_config *= #sixty cachecache_timer
function cache_cache_s32:config/show

