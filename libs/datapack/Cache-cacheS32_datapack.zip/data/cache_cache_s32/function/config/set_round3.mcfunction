
#> cache_cache_s32:config/set_round3
#
# @within	string in cache_cache_s32:config/set_round3 {hide:2,hunt:8}
#
# @args		hide (int)
#			hunt (int)
#

# Usage: /function cache_cache_s32:config/set_round3 {hide:2,hunt:8}
$scoreboard players set #hide3 cachecache_config $(hide)
scoreboard players operation #hide3 cachecache_config *= #sixty cachecache_timer
$scoreboard players set #hunt3 cachecache_config $(hunt)
scoreboard players operation #hunt3 cachecache_config *= #sixty cachecache_timer
function cache_cache_s32:config/show

