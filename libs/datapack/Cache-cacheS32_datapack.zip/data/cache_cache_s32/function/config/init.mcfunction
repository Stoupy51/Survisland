
#> cache_cache_s32:config/init
#
# @within	cache_cache_s32:v0.0.1/load/confirm_load
#

scoreboard players add #initialized cachecache_config 0
execute unless score #initialized cachecache_config matches 1 run function cache_cache_s32:config/default_timers

