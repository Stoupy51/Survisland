
#> cache_cache_s32:config/default_timers
#
# @within	cache_cache_s32:config/init
#

scoreboard players set #selection cachecache_config 120
scoreboard players set #hide1 cachecache_config 180
scoreboard players set #hunt1 cachecache_config 600
scoreboard players set #hide2 cachecache_config 120
scoreboard players set #hunt2 cachecache_config 480
scoreboard players set #hide3 cachecache_config 120
scoreboard players set #hunt3 cachecache_config 480
scoreboard players set #intermission cachecache_config 20
scoreboard players set #initialized cachecache_config 1
tellraw @s {text: "Chronos remis aux valeurs par defaut.", color: "green"}

