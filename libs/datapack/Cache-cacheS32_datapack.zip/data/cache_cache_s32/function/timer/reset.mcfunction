
#> cache_cache_s32:timer/reset
#
# @within	cache_cache_s32:display/config
#

scoreboard players operation #total cachecache_timer = #duration_min cachecache_timer
scoreboard players operation #total cachecache_timer *= #sixty cachecache_timer
scoreboard players operation #total cachecache_timer += #duration_sec cachecache_timer
scoreboard players set #tick cachecache_timer 20
scoreboard players set #running cachecache_state 0
scoreboard players set #finished cachecache_state 0
function cache_cache_s32:timer/convert

