
#> cache_cache_s32:timer/end
#
# @within	???
#

scoreboard players set #running cachecache_state 0
scoreboard players set #finished cachecache_state 1
function cache_cache_s32:integration/survisland/heart_beat_stop
function cache_cache_s32:display/show
title @a times 0 40 20
title @a subtitle {text: "Le chrono est termin\u00e9", color: "yellow"}
title @a title {text: "Temps \u00e9coul\u00e9 !", color: "red", bold: true}
playsound minecraft:block.note_block.bass master @a ~ ~ ~ 1 0.7

