
#> cache_cache_s32:timer/second
#
# @within	cache_cache_s32:timer/tick
#

scoreboard players set #tick cachecache_timer 20
execute if score #total cachecache_timer matches 1.. run scoreboard players remove #total cachecache_timer 1
function cache_cache_s32:timer/convert
function cache_cache_s32:game/second
function cache_cache_s32:display/show
execute if score #phase cachecache_state matches 2 if score #total cachecache_timer matches 6 if score #hunt_countdown cachecache_state matches 0 run function cache_cache_s32:game/start_hunt_countdown
execute if score #total cachecache_timer matches ..0 run function cache_cache_s32:game/phase_end

