
#> cache_cache_s32:timer/tick
#
# @within	cache_cache_s32:display/tick
#			cache_cache_s32:game/tick
#

scoreboard players remove #tick cachecache_timer 1
execute if score #tick cachecache_timer matches ..0 run function cache_cache_s32:timer/second

