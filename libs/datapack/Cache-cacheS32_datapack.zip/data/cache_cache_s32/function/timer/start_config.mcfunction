
#> cache_cache_s32:timer/start_config
#
# @within	cache_cache_s32:game/end_hunt {source: "intermission"}
#			cache_cache_s32:game/start_hide {source: "hide1"}
#			cache_cache_s32:game/start_hide {source: "hide2"}
#			cache_cache_s32:game/start_hide {source: "hide3"}
#			cache_cache_s32:game/start_hunt_release {source: "hunt1"}
#			cache_cache_s32:game/start_hunt_release {source: "hunt2"}
#			cache_cache_s32:game/start_hunt_release {source: "hunt3"}
#			string in cache_cache_s32:timer/start_config {source:"hide1"}
#
# @args		source (string)
#

# Usage: /function cache_cache_s32:timer/start_config {source:"hide1"}
$scoreboard players operation #total cachecache_timer = #$(source) cachecache_config
scoreboard players set #tick cachecache_timer 20
function cache_cache_s32:timer/convert
function cache_cache_s32:display/show

