
#> cache_cache_s32:timer/convert
#
# @within	cache_cache_s32:admin/skip_hide
#			cache_cache_s32:timer/reset
#			cache_cache_s32:timer/second
#			cache_cache_s32:timer/start
#			cache_cache_s32:timer/start_config
#			cache_cache_s32:v0.0.1/load/confirm_load
#

scoreboard players operation #min cachecache_timer = #total cachecache_timer
scoreboard players operation #min cachecache_timer /= #sixty cachecache_timer
scoreboard players operation #sec cachecache_timer = #total cachecache_timer
scoreboard players operation #sec cachecache_timer %= #sixty cachecache_timer

