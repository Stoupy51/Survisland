
#> cache_cache_s32:timer/stop
#
# @within	???
#

scoreboard players set #running cachecache_state 0
function cache_cache_s32:integration/survisland/heart_beat_stop

