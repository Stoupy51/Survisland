
#> cache_cache_s32:timer/start
#
# @within	???
#
# @args		seconds (unknown)
#

$scoreboard players set #total cachecache_timer $(seconds)
scoreboard players set #tick cachecache_timer 20
function cache_cache_s32:timer/convert
function cache_cache_s32:display/show

