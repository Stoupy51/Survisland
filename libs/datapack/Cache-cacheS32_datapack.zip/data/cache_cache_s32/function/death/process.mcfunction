
#> cache_cache_s32:death/process
#
# @executed	as @a[scores={cachecache_deaths=1..}] & at @s
#
# @within	cache_cache_s32:game/tick [ as @a[scores={cachecache_deaths=1..}] & at @s ]
#

execute if entity @s[tag=SpecChasses] run function cache_cache_s32:death/spec
execute if entity @s[tag=Chasses] run function cache_cache_s32:death/player
scoreboard players set @s cachecache_deaths 0

