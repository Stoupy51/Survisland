
#> cache_cache_s32:death/spec
#
# @executed	as @a[scores={cachecache_deaths=1..}] & at @s
#
# @within	cache_cache_s32:death/process
#			cache_cache_s32:hit/eliminate
#

tag @s remove survisland.alive
effect clear @s speed
gamemode adventure @s
execute if score #round cachecache_state matches 1 run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map2, limit=1]
execute if score #round cachecache_state matches 2 run tp @s @e[type=minecraft:marker, tag=cachecache.marker.map3, limit=1]
execute if score #round cachecache_state matches 3 run tp @s @e[type=minecraft:marker, tag=cachecache.marker.middle, limit=1]
tellraw @s {text: "Vous avez \u00e9t\u00e9 touch\u00e9 et attendez maintenant sur la zone suivante.", color: "yellow"}

