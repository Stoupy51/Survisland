
#> cache_cache_s32:death/player
#
# @executed	as @a[scores={cachecache_deaths=1..}] & at @s
#
# @within	cache_cache_s32:death/process
#			cache_cache_s32:hit/eliminate
#

tag @s remove survisland.alive
tag @s remove Chasses
effect clear @s
gamemode adventure @s
tp @s @e[type=minecraft:marker, tag=cachecache.marker.middle, limit=1]
tellraw @s {text: "Vous avez \u00e9t\u00e9 touch\u00e9 : vous \u00eates \u00e9limin\u00e9 pour cette manche.", color: "red"}

