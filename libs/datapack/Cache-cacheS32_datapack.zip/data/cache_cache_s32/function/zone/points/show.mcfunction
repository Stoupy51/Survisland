
#> cache_cache_s32:zone/points/show
#
# @within	???
#

# Briefly display the marker centres and the four corners.
execute as @e[type=minecraft:marker, tag=cache_cache.points_zone] at @s run particle minecraft:dust{color: [1.0d, 0.8d, 0.0d], scale: 1.0d} ~ ~0.2 ~ 0 0 0 0 1 force @s
execute as @e[type=minecraft:marker, tag=cache_cache.points_zone] at @s run particle minecraft:dust{color: [0.0d, 1.0d, 0.2d], scale: 0.8d} ~-3 ~0.2 ~-3 0 0 0 0 1 force @s
execute as @e[type=minecraft:marker, tag=cache_cache.points_zone] at @s run particle minecraft:dust{color: [0.0d, 1.0d, 0.2d], scale: 0.8d} ~3 ~0.2 ~-3 0 0 0 0 1 force @s
execute as @e[type=minecraft:marker, tag=cache_cache.points_zone] at @s run particle minecraft:dust{color: [0.0d, 1.0d, 0.2d], scale: 0.8d} ~-3 ~0.2 ~2 0 0 0 0 1 force @s
execute as @e[type=minecraft:marker, tag=cache_cache.points_zone] at @s run particle minecraft:dust{color: [0.0d, 1.0d, 0.2d], scale: 0.8d} ~3 ~0.2 ~2 0 0 0 0 1 force @s

