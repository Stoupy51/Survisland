
#> cache_cache_s32:zone/points/remove_nearest
#
# @within	???
#

execute if entity @e[type=minecraft:marker, tag=cache_cache.points_zone, distance=..5, sort=nearest, limit=1] run kill @e[type=minecraft:marker, tag=cache_cache.points_zone, distance=..5, sort=nearest, limit=1]
tellraw @s {text: "Le marqueur de zone de points le plus proche a \u00e9t\u00e9 supprim\u00e9.", color: "yellow"}

