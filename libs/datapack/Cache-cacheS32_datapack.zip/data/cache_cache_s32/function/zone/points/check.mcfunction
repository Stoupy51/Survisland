
#> cache_cache_s32:zone/points/check
#
# @executed	at @s
#
# @within	cache_cache_s32:zone/points/tick [ at @s ]
#

# The marker is placed at floor level in the centre of a 7 x 1 x 6 zone.
execute positioned ~-3 ~ ~-3 if entity @a[gamemode=adventure, tag=survisland.alive, tag=cachecache_team_albertos, dx=6, dy=0, dz=5] run function cache_cache_s32:score/albertos/add
execute positioned ~-3 ~ ~-3 if entity @a[gamemode=adventure, tag=survisland.alive, tag=cachecache_team_rtt, dx=6, dy=0, dz=5] run function cache_cache_s32:score/rtt/add

