
#> cache_cache_s32:zone/points/tick
#
# @within	???
#

# Award one point per scoring zone occupied by at least one hidden player.
execute as @e[type=minecraft:marker, tag=cache_cache.points_zone] at @s run function cache_cache_s32:zone/points/check

