
#> cache_cache_s32:zone/points/create
#
# @within	???
#

# Run this function while standing at floor level in the centre of the zone.
execute unless entity @e[type=minecraft:marker, tag=cache_cache.points_zone, distance=..1] run summon minecraft:marker ~ ~ ~ {Tags: ["cache_cache.points_zone"]}
tellraw @s [{text: "Zone de points enregistr\u00e9e autour de ", color: "green"}, {text: "votre position", color: "yellow"}, {text: " (7 \u00d7 1 \u00d7 6 blocs).", color: "green"}]

