
#> cache_cache_s32:zone/map2_tick
#
# @within	cache_cache_s32:game/second
#

execute if score #advantage_claimed cachecache_state matches 0 as @e[type=minecraft:marker, tag=cachecache.marker.zone2_capture, limit=1] at @s if entity @a[tag=Chasses, team=RTT, distance=..4] unless entity @a[tag=Chasses, team=Albertos, distance=..4] run scoreboard players add RTT cachecache_capture 1
execute if score #advantage_claimed cachecache_state matches 0 as @e[type=minecraft:marker, tag=cachecache.marker.zone2_capture, limit=1] at @s if entity @a[tag=Chasses, team=Albertos, distance=..4] unless entity @a[tag=Chasses, team=RTT, distance=..4] run scoreboard players add Albertos cachecache_capture 1

