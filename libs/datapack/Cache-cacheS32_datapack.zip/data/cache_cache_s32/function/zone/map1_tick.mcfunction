
#> cache_cache_s32:zone/map1_tick
#
# @within	cache_cache_s32:game/tick
#

execute if score #advantage_claimed cachecache_state matches 0 as @e[type=minecraft:marker, tag=cachecache.marker.zone1_object, limit=1] at @s if entity @a[tag=Chasses, team=RTT, distance=..1.5, limit=1] run function cache_cache_s32:advantage/rtt
execute if score #advantage_claimed cachecache_state matches 0 as @e[type=minecraft:marker, tag=cachecache.marker.zone1_object, limit=1] at @s if entity @a[tag=Chasses, team=Albertos, distance=..1.5, limit=1] run function cache_cache_s32:advantage/albertos

