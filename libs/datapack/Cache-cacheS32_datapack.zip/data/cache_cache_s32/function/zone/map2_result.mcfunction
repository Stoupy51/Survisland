
#> cache_cache_s32:zone/map2_result
#
# @within	cache_cache_s32:game/end_hunt
#

# Compare le temps cumule sans plafond pendant toute la manche 2.
execute if score RTT cachecache_capture > Albertos cachecache_capture run function cache_cache_s32:advantage/rtt
execute if score #advantage_claimed cachecache_state matches 0 if score Albertos cachecache_capture > RTT cachecache_capture run function cache_cache_s32:advantage/albertos
execute if score #advantage_claimed cachecache_state matches 0 if score RTT cachecache_capture = Albertos cachecache_capture run function cache_cache_s32:advantage/tie

