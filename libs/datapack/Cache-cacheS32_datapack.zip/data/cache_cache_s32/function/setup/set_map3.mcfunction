
#> cache_cache_s32:setup/set_map3
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.map3]
summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.map3"]}
tellraw @s {text: "Spawn map 3 place.", color: "green"}

