
#> cache_cache_s32:setup/set_hunter_hold
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.hunter_hold]
summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.hunter_hold"]}
tellraw @s {text: "Zone des chasseurs placee.", color: "green"}

