
#> cache_cache_s32:setup/set_zone1_object
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.zone1_object]
summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.zone1_object"]}
tellraw @s {text: "Objet-avantage de la map 1 place.", color: "green"}

