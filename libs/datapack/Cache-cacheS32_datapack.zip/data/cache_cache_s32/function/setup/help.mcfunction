
#> cache_cache_s32:setup/help
#
# @within	string in cache_cache_s32:setup/check
#

tellraw @s {text: "Placez-vous a chaque position puis lancez la fonction correspondante :", color: "gold"}
tellraw @s {text: "Zones : set_middle, set_hunted_hold, set_hunter_hold, set_map1, set_map2, set_map3, set_zone1_object, set_zone2_capture, set_spec_registration", color: "yellow"}
tellraw @s {text: "Plaques RTT : set_select_rtt_map1, set_select_rtt_map2, set_select_rtt_map3", color: "green"}
tellraw @s {text: "Plaques Albertos : set_select_albertos_map1, set_select_albertos_map2, set_select_albertos_map3", color: "aqua"}
tellraw @s {text: "Plaque d'annulation : set_select_reset", color: "red"}
function cache_cache_s32:setup/check

