
#> cache_cache_s32:setup/check
#
# @within	cache_cache_s32:game/start
#			cache_cache_s32:setup/help
#			cache_cache_s32:setup/set_spec_registration
#

scoreboard players set #setup_ok cachecache_state 0
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.middle, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.hunter_hold, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.map1, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.map2, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.map3, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.zone1_object, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.zone2_capture, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map1, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map2, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map3, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map1, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map2, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map3, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.select.reset, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if entity @e[type=minecraft:marker, tag=cachecache.marker.spec_registration, limit=1] run scoreboard players add #setup_ok cachecache_state 1
execute if score #setup_ok cachecache_state matches 16 run tellraw @s [{text: "Installation complete : ", color: "green"}, {text: "16/16 marqueurs trouves.", color: "yellow", bold: true}]
execute unless score #setup_ok cachecache_state matches 16 run tellraw @s [{text: "Installation incomplete : ", color: "red"}, {score: {name: "#setup_ok", objective: "cachecache_state"}}, {text: "/16 marqueurs trouves. Lancez /function cache_cache_s32:setup/help", color: "yellow"}]

