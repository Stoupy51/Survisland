
#> cache_cache_s32:setup/set_map1
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.map1]
summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.map1"]}
tellraw @s {text: "Spawn map 1 place.", color: "green"}

