
#> cache_cache_s32:setup/set_select_reset
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.select.reset]
setblock ~ ~ ~ minecraft:stone_pressure_plate
execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.selection", "cachecache.marker.select.reset"]}
tellraw @s {text: "Plaque RESET des chasseurs plac\u00e9e.", color: "green"}

