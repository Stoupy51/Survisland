
#> cache_cache_s32:setup/set_map2
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.map2]
summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.map2"]}
tellraw @s {text: "Spawn map 2 place.", color: "green"}

