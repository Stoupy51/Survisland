
#> cache_cache_s32:setup/set_select_albertos_map2
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map2]
setblock ~ ~ ~ minecraft:heavy_weighted_pressure_plate
execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.selection", "cachecache.marker.select.albertos.map2"]}
tellraw @s {text: "Plaque Albertos - chasseur map 2 placee.", color: "aqua"}

