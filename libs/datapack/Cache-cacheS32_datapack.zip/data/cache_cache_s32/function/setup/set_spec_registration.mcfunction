
#> cache_cache_s32:setup/set_spec_registration
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.spec_registration]
summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.spec_registration"]}
tellraw @s {text: "Centre de la zone d'inscription des specs place (rayon : 30 blocs).", color: "yellow"}
function cache_cache_s32:setup/check

