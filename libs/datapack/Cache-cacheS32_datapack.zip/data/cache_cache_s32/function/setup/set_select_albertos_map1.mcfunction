
#> cache_cache_s32:setup/set_select_albertos_map1
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.select.albertos.map1]
setblock ~ ~ ~ minecraft:heavy_weighted_pressure_plate
execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.selection", "cachecache.marker.select.albertos.map1"]}
tellraw @s {text: "Plaque Albertos - chasseur map 1 placee.", color: "aqua"}

