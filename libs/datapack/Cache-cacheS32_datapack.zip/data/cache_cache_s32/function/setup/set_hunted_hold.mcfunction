
#> cache_cache_s32:setup/set_hunted_hold
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.hunted_hold]
summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.hunted_hold"]}
tellraw @s {text: "Zone des chasses placee.", color: "green"}

