
#> cache_cache_s32:setup/set_select_rtt_map3
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.select.rtt.map3]
setblock ~ ~ ~ minecraft:heavy_weighted_pressure_plate
execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.selection", "cachecache.marker.select.rtt.map3"]}
tellraw @s {text: "Plaque RTT - chasseur map 3 placee.", color: "green"}

