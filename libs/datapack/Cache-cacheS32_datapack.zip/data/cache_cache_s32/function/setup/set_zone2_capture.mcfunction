
#> cache_cache_s32:setup/set_zone2_capture
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.zone2_capture]
summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.zone2_capture"]}
tellraw @s {text: "Zone de capture de la map 2 placee.", color: "green"}

