
#> cache_cache_s32:setup/set_middle
#
# @within	???
#

kill @e[type=minecraft:marker, tag=cachecache.marker.middle]
summon minecraft:marker ~ ~ ~ {Tags: ["cachecache.marker.middle"]}
tellraw @s {text: "Marqueur milieu place.", color: "green"}

