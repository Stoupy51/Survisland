
execute align xyz positioned ~0.5 ~ ~0.5 unless entity @e[type=minecraft:marker,tag=soleil_origin,distance=..2,limit=1] run summon minecraft:marker ~ ~ ~ {Tags:["soleil_origin"]}
execute at @e[type=minecraft:marker,tag=soleil_origin,sort=nearest,limit=1] unless entity @e[type=minecraft:marker,tag=soleil_head_anchor,distance=..50,limit=1] run summon minecraft:marker ~34 ~22.5 ~21 {Tags:["soleil_head_anchor"]}
scoreboard players set @e[type=minecraft:marker,tag=soleil_head_anchor] yh_steps 0
scoreboard players set @e[type=minecraft:marker,tag=soleil_head_anchor] yh_dir 0
scoreboard players set @e[type=minecraft:marker,tag=soleil_head_anchor] yh_facing 0
execute at @e[type=minecraft:marker,tag=soleil_origin,sort=nearest,limit=1] unless entity @e[tag=soleil_head,distance=..50,limit=1] as @e[type=minecraft:marker,tag=soleil_head_anchor,sort=nearest,limit=1] at @s run function soleil:head/spawn
execute at @e[type=minecraft:marker,tag=soleil_origin,sort=nearest,limit=1] unless entity @e[type=minecraft:text_display,tag=soleil_signal,distance=..50,limit=1] run summon minecraft:text_display ~34 ~29 ~25 {Tags:["soleil_signal"],billboard:"center",text:{text:"PRÊT",color:"yellow",bold:true}}
data merge entity @e[type=minecraft:text_display,tag=soleil_signal,sort=nearest,limit=1] {billboard:"center",text:{text:"PRÊT",color:"yellow",bold:true},line_width:240,see_through:1b,shadow:1b,view_range:20f,transformation:{scale:[15f,15f,15f]}}
execute at @e[type=minecraft:marker,tag=soleil_origin,sort=nearest,limit=1] unless entity @e[type=minecraft:text_display,tag=soleil_timer,distance=..50,limit=1] run summon minecraft:text_display ~34 ~34 ~25 {Tags:["soleil_timer"],billboard:"center",text:{text:"60",color:"red",bold:true},alignment:"center",background:0,line_width:160,see_through:1b,shadow:1b,view_range:20f,transformation:{scale:[25f,25f,25f]}}
data merge entity @e[type=minecraft:text_display,tag=soleil_timer,sort=nearest,limit=1] {billboard:"center",text:{text:"60",color:"red",bold:true},alignment:"center",background:0,line_width:160,see_through:1b,shadow:1b,view_range:20f,transformation:{scale:[25f,25f,25f]}}
bossbar remove soleil:etat
bossbar add soleil:etat {"text":"1, 2, 3 Soleil","color":"white","bold":true}
bossbar set soleil:etat max 100
bossbar set soleil:etat value 100
bossbar set soleil:etat visible false
scoreboard players set #state sun_game 0
scoreboard players set #manche sun_game 1
scoreboard players set #round sun_game 1
scoreboard players set #dead sun_game 0
scoreboard players set #final sun_game 0
scoreboard players set #test sun_game 0
scoreboard players set #twenty sun_game 20
scoreboard players set #manche_ticks sun_game 1200
scoreboard players set #seconds sun_game 60
scoreboard players set #last_seconds sun_game -1
function soleil:timer/render
function soleil:terrain/restaurer
function soleil:house/restaurer_vitres
tellraw @s [{"text":"[1, 2, 3 Soleil] ","color":"gold"},{"text":"Box configurée. Les joueurs portant le tag F15 participeront à l'épreuve. Utilise /function soleil:demarrer","color":"white"}]
tellraw @s [{text:"[1, 2, 3 Soleil] ",color:"gold"},{text:"Partie test : /function soleil:test/demarrer",color:"aqua"}]
