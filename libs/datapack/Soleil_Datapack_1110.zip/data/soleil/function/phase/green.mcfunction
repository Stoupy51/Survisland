
scoreboard players set #state sun_game 1
execute store result score #voice sun_game run random value 0..6
function soleil:head/turn_back
bossbar set soleil:etat color green
bossbar set soleil:etat name {"text":"GREEN LIGHT","color":"green","bold":true}
data merge entity @e[type=minecraft:text_display,tag=soleil_signal,limit=1] {text:{text:"GREEN LIGHT",color:"green",bold:true}}
execute if score #test sun_game matches 1 run tellraw @a[tag=soleil_participant] {"text":"[TEST] GREEN LIGHT — avancez !","color":"green","bold":true}
function soleil:voice/select
