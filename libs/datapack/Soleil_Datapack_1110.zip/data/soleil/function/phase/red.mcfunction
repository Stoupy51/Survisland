
scoreboard players set #state sun_game 2
execute store result score #timer sun_game run random value 80..140
stopsound @a[tag=soleil_participant] master survisland:soleil/green_light
execute as @a[tag=soleil_en_jeu] store result score @s sun_x0 run data get entity @s Pos[0] 100
execute as @a[tag=soleil_en_jeu] store result score @s sun_z0 run data get entity @s Pos[2] 100
function soleil:head/turn_front
bossbar set soleil:etat color red
bossbar set soleil:etat name {"text":"RED LIGHT","color":"red","bold":true}
execute as @a[tag=soleil_participant] at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 3 0.6 1
data merge entity @e[type=minecraft:text_display,tag=soleil_signal,limit=1] {text:{text:"RED LIGHT",color:"red",bold:true}}
execute if score #test sun_game matches 1 run tellraw @a[tag=soleil_participant] {"text":"[TEST] RED LIGHT — ne bougez plus !","color":"red","bold":true}
