
execute if score #test sun_game matches 1 run return run function soleil:test/finish
function soleil:winner/check_end
execute if score #state sun_game matches 6 if score #manche sun_game matches 6 if entity @a[tag=soleil_qualifie] run function soleil:winner/resolve_final_ties
scoreboard players set #qualified sun_game 0
execute as @a[tag=soleil_qualifie] run scoreboard players add #qualified sun_game 1
execute if score #state sun_game matches 6 if score #manche sun_game matches ..5 if score #qualified sun_game matches 1.. run function soleil:manche/restart
execute if score #state sun_game matches 6 if score #qualified sun_game matches 0 if entity @a[tag=soleil_gagnant] run function soleil:final/end
execute if score #state sun_game matches 6 if score #qualified sun_game matches 0 unless entity @a[tag=soleil_gagnant] run function soleil:game/restart_all
