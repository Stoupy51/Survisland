
scoreboard players remove #timer sun_game 1
execute if score #timer sun_game matches ..0 run function soleil:countdown/start
