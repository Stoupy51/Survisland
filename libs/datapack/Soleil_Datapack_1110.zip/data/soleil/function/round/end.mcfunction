
scoreboard players set #state sun_game 3
scoreboard players set #timer sun_game 10
execute if score #round sun_game matches 2 run function soleil:zone/activate_1
execute if score #round sun_game matches 3 run function soleil:zone/activate_2
execute if score #round sun_game matches 4 run function soleil:zone/activate_3
execute if score #round sun_game matches 5 run function soleil:zone/activate_4
execute if score #round sun_game matches 6 run function soleil:zone/activate_5
execute if score #round sun_game matches 7 run function soleil:zone/activate_6
execute if score #round sun_game matches 8 run function soleil:zone/activate_7
execute if score #round sun_game matches 9 run function soleil:zone/activate_8
execute if score #round sun_game matches 10 unless score #dead sun_game matches 9 run function soleil:zone/activate_9
execute if score #round sun_game matches ..10 run scoreboard players add #round sun_game 1
bossbar set soleil:etat color yellow
bossbar set soleil:etat name {"text":"PRÉPAREZ-VOUS","color":"yellow","bold":true}
tellraw @a[tag=soleil_participant] [{"text":"ROUND ","color":"aqua","bold":true},{"score":{"name":"#round","objective":"sun_game"},"color":"white","bold":true},{"text":" — la manche continue.","color":"gray"}]
