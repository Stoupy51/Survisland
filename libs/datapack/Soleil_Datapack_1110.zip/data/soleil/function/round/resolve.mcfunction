
execute as @a[tag=soleil_en_jeu,tag=soleil_a_eliminer,limit=1,sort=arbitrary] at @s run function soleil:player/eliminer
execute unless entity @a[tag=soleil_en_jeu,tag=soleil_a_eliminer] run function soleil:round/resolve_after_queue
