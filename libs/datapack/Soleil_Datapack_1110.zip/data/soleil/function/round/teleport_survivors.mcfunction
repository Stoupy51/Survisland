scoreboard players set #slot sun_game 0
tag @a[tag=soleil_en_jeu] remove soleil_replace
function soleil:round/teleport_next
tag @a[tag=soleil_replace] remove soleil_replace
