execute if score #slot sun_game matches 0 run tp @s ~31 ~2 ~110
execute if score #slot sun_game matches 1 run tp @s ~33 ~2 ~110
execute if score #slot sun_game matches 2 run tp @s ~35 ~2 ~110
execute if score #slot sun_game matches 3 run tp @s ~37 ~2 ~110
execute if score #slot sun_game matches 4 run tp @s ~39 ~2 ~110
execute if score #slot sun_game matches 5 run tp @s ~31 ~2 ~113
execute if score #slot sun_game matches 6 run tp @s ~33 ~2 ~113
execute if score #slot sun_game matches 7 run tp @s ~35 ~2 ~113
execute if score #slot sun_game matches 8 run tp @s ~37 ~2 ~113
execute if score #slot sun_game matches 9 run tp @s ~39 ~2 ~113
execute if score #slot sun_game matches 10 run tp @s ~31 ~2 ~116
execute if score #slot sun_game matches 11 run tp @s ~33 ~2 ~116
execute if score #slot sun_game matches 12 run tp @s ~35 ~2 ~116
execute if score #slot sun_game matches 13 run tp @s ~37 ~2 ~116
execute if score #slot sun_game matches 14 run tp @s ~39 ~2 ~116
execute if score #slot sun_game matches 15 run tp @s ~31 ~2 ~109
execute if score #slot sun_game matches 16 run tp @s ~33 ~2 ~109
execute if score #slot sun_game matches 17 run tp @s ~35 ~2 ~109
execute if score #slot sun_game matches 18 run tp @s ~37 ~2 ~109
execute if score #slot sun_game matches 19 run tp @s ~39 ~2 ~109
execute if score #slot sun_game matches 20 run tp @s ~31 ~2 ~118
execute if score #slot sun_game matches 21 run tp @s ~33 ~2 ~118
execute if score #slot sun_game matches 22 run tp @s ~35 ~2 ~118
execute if score #slot sun_game matches 23 run tp @s ~37 ~2 ~118
execute if score #slot sun_game matches 24 run tp @s ~39 ~2 ~118
tag @s add soleil_replace
scoreboard players add #slot sun_game 1
