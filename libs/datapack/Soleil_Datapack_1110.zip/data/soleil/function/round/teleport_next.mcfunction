execute as @a[tag=soleil_en_jeu,tag=!soleil_replace,limit=1,sort=arbitrary] run function soleil:round/place_one
execute if entity @a[tag=soleil_en_jeu,tag=!soleil_replace] run function soleil:round/teleport_next
