
# Alias de compatibilité : force la fin de la manche de 60 secondes.
function soleil:manche/time_up
