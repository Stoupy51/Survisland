# Tags externes demandés par Survisland.
effect clear @a[tag=soleil_participant] minecraft:saturation
execute as @a run attribute @s minecraft:fall_damage_multiplier modifier remove soleil:no_fall
tag @a remove soleil.participant
tag @a remove soleil.elimine
tag @a remove F15
# Tags internes de l'épreuve.
tag @a remove soleil_participant
tag @a remove soleil_en_jeu
tag @a remove soleil_qualifie
tag @a remove soleil_elimine
tag @a remove soleil_gagnant
tag @a remove soleil_a_eliminer
tag @a remove soleil_classe
tag @a remove soleil_equipe_verifiee
tag @a remove soleil_replace
tag @a remove soleil_fallback_candidate
scoreboard players reset @a sun_finish
scoreboard players reset @a sun_qual_count
scoreboard players reset @a sun_qual_ticks
scoreboard players reset @a sun_manche_start
