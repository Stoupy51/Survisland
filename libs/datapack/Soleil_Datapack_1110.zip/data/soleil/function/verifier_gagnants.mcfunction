# L'évaluation d'une équipe n'est sûre qu'une fois la manche terminée.
execute if score #test sun_game matches 1 run tellraw @s {"text":"La partie test ne désigne aucun gagnant : consulte uniquement son classement final.","color":"aqua"}
execute if score #test sun_game matches 1 run return 0
execute if score #state sun_game matches 6 run function soleil:winner/check_end
execute if score #state sun_game matches 6 if score #manche sun_game matches 6 if entity @a[tag=soleil_qualifie] run function soleil:winner/resolve_final_ties
scoreboard players set #winner_count sun_game 0
execute as @a[tag=F15,tag=soleil_gagnant] run scoreboard players add #winner_count sun_game 1
execute if score #winner_count sun_game matches 0 run tellraw @s {"text":"Aucun gagnant d'équipe détecté pour le moment.","color":"gray"}
execute if score #winner_count sun_game matches 1.. run tellraw @s [{"text":"Gagnants détectés : ","color":"gold","bold":true},{"score":{"name":"#winner_count","objective":"sun_game"},"color":"yellow","bold":true}]
execute if score #winner_count sun_game matches 1.. run tellraw @s [{"text":"🏆 ","color":"gold"},{"selector":"@a[tag=F15,tag=soleil_gagnant]","color":"yellow","bold":true}]
execute if score #state sun_game matches 1..5 run tellraw @s {"text":"La manche est encore en cours : les nouveaux gagnants seront déterminés à sa fin.","color":"aqua"}
