
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run fill ~31 ~2 ~107 ~38 ~6 ~107 minecraft:white_stained_glass_pane[east=true,north=false,south=false,waterlogged=false,west=true]
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run fill ~39 ~2 ~107 ~39 ~6 ~107 minecraft:white_stained_glass_pane[east=false,north=false,south=false,waterlogged=false,west=true]
