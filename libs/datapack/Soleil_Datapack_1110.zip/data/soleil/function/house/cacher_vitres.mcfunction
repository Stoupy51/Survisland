
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run fill ~31 ~2 ~107 ~39 ~6 ~107 minecraft:barrier replace minecraft:white_stained_glass_pane
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] positioned ~35 ~4 ~107 run playsound minecraft:block.glass.break master @a[tag=soleil_participant] ~ ~ ~ 1.5 0.9
