
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run fill ~31 ~2 ~107 ~39 ~6 ~107 minecraft:air replace minecraft:barrier
