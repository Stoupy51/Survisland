
scoreboard players remove #manche_ticks sun_game 1
scoreboard players operation #seconds sun_game = #manche_ticks sun_game
scoreboard players add #seconds sun_game 19
scoreboard players operation #seconds sun_game /= #twenty sun_game
execute unless score #seconds sun_game = #last_seconds sun_game run function soleil:timer/render
scoreboard players operation #last_seconds sun_game = #seconds sun_game
execute if score #manche_ticks sun_game matches ..0 run function soleil:manche/time_up
