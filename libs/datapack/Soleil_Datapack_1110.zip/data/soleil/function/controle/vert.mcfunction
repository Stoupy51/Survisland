function soleil:phase/green
