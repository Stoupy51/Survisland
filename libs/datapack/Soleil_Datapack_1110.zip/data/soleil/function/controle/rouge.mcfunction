function soleil:phase/red
