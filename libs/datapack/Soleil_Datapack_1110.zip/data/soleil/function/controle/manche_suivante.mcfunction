
execute if score #state sun_game matches 1..3 run function soleil:manche/time_up
