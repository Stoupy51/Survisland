execute unless score #state sun_game matches 1..6 run tellraw @s {"text":"Aucune partie en cours à terminer.","color":"red"}
execute unless score #state sun_game matches 1..6 run return 0
tellraw @a[tag=F15] [{"text":"[1, 2, 3 Soleil] ","color":"gold"},{"text":"Fin manuelle de la partie.","color":"yellow","bold":true}]
function soleil:final/end
