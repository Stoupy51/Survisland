execute unless score #state sun_game matches 1..5 run tellraw @s {"text":"Aucune manche en cours à faire avancer.","color":"red"}
execute unless score #state sun_game matches 1..5 run return 0
tag @a[tag=soleil_en_jeu] remove soleil_a_eliminer
execute as @a[tag=soleil_en_jeu] at @s run function soleil:player/qualify
scoreboard players set #state sun_game 6
scoreboard players set #manche_ticks sun_game 0
scoreboard players set #seconds sun_game 0
function soleil:timer/render
stopsound @a[tag=soleil_participant] master soleil:green_light
tellraw @a[tag=soleil_participant] [{"text":"[1, 2, 3 Soleil] ","color":"gold"},{"text":"Passage manuel à la manche suivante.","color":"aqua","bold":true}]
function soleil:round/resolve_after_queue
