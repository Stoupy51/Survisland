execute if score #test sun_game matches 1 run return run function soleil:test/ranking_show
scoreboard players add @a[tag=F15] sun_alive 0
scoreboard players add @a[tag=F15] sun_alive_sec 0
execute as @a[tag=F15] run scoreboard players operation @s sun_alive_sec = @s sun_alive
execute as @a[tag=F15] run scoreboard players operation @s sun_alive_sec /= #rank_divisor sun_alive
tag @a remove soleil_classe
tellraw @a [{"text":"\n════════ CLASSEMENT 1, 2, 3 SOLEIL ════════","color":"gold","bold":true}]
tellraw @a [{"text":"1er — GAGNANTS DE LEUR ÉQUIPE","color":"yellow","bold":true}]
execute as @a[tag=F15,tag=soleil_gagnant] run function soleil:ranking/show_winner
execute unless entity @a[tag=F15,tag=soleil_gagnant] run tellraw @a {"text":"  Aucun gagnant d'équipe.","color":"gray","italic":true}
tellraw @a [{"text":"— AUTRES JOUEURS, PAR PROGRESSION PUIS TEMPS DE SURVIE —","color":"gray"}]
scoreboard players set #rank sun_game 1
function soleil:ranking/next
tellraw @a [{"text":"═══════════════════════════════════════\n","color":"gold","bold":true}]
