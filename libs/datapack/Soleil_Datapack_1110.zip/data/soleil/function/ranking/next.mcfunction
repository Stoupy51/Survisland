scoreboard players set #rank_best_quals sun_qual_count -1
execute as @a[tag=F15,tag=!soleil_gagnant,tag=!soleil_classe] run scoreboard players operation #rank_best_quals sun_qual_count > @s sun_qual_count
scoreboard players set #rank_max sun_alive -1
execute as @a[tag=F15,tag=!soleil_gagnant,tag=!soleil_classe] if score @s sun_qual_count = #rank_best_quals sun_qual_count run scoreboard players operation #rank_max sun_alive > @s sun_alive
execute as @a[tag=F15,tag=!soleil_gagnant,tag=!soleil_classe] if score @s sun_qual_count = #rank_best_quals sun_qual_count if score @s sun_alive = #rank_max sun_alive run function soleil:ranking/place
execute if entity @a[tag=F15,tag=!soleil_gagnant,tag=!soleil_classe] run function soleil:ranking/next
