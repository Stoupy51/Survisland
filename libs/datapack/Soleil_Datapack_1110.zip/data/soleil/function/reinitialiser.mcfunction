
scoreboard players set #state sun_game 0
scoreboard players set #manche sun_game 1
scoreboard players set #round sun_game 1
scoreboard players set #dead sun_game 0
scoreboard players set #final sun_game 0
scoreboard players set #test sun_game 0
scoreboard players set #manche_ticks sun_game 1200
scoreboard players set #seconds sun_game 60
scoreboard players set #last_seconds sun_game -1
scoreboard players set #ranking_done sun_game 0
function soleil:timer/render
function soleil:music/stop
function soleil:terrain/restaurer
function soleil:head/reset
function soleil:house/restaurer_vitres
tag @a[tag=soleil_participant] remove soleil_participant
tag @a[tag=soleil_en_jeu] remove soleil_en_jeu
tag @a[tag=soleil_elimine] remove soleil_elimine
tag @a[tag=soleil_gagnant] remove soleil_gagnant
tag @a[tag=soleil_a_eliminer] remove soleil_a_eliminer
tag @a remove soleil_qualifie
tag @a remove soleil_classe
tag @a remove soleil_equipe_verifiee
scoreboard players reset @a sun_alive
scoreboard players reset @a sun_alive_sec
function soleil:cleanup/player_tags
bossbar set soleil:etat visible false
data merge entity @e[type=minecraft:text_display,tag=soleil_signal,limit=1] {text:{text:"PRÊT",color:"yellow",bold:true}}
tellraw @s {"text":"Épreuve réinitialisée et sols restaurés.","color":"green"}
