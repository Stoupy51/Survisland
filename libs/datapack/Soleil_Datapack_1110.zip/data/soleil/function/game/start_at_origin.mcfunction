
tag @a[tag=soleil_participant] remove soleil_participant
tag @a[tag=soleil_en_jeu] remove soleil_en_jeu
tag @a[tag=soleil_elimine] remove soleil_elimine
tag @a[tag=soleil_gagnant] remove soleil_gagnant
tag @a[tag=soleil_a_eliminer] remove soleil_a_eliminer
tag @a remove soleil_qualifie
tag @a remove soleil_classe
tag @a remove soleil_equipe_verifiee
tag @a remove soleil_fallback_candidate
tag @a[tag=F15] add soleil_participant
tag @a[tag=soleil_participant] add soleil_en_jeu
effect give @a[tag=soleil_participant] minecraft:saturation infinite 0 true
execute as @a[tag=soleil_participant] run attribute @s minecraft:fall_damage_multiplier modifier remove soleil:no_fall
execute as @a[tag=soleil_participant] run attribute @s minecraft:fall_damage_multiplier modifier add soleil:no_fall -1 add_multiplied_total
scoreboard players set @a[tag=soleil_participant] sun_team 0
scoreboard players set @a[tag=soleil_participant,team=mAkijan] sun_team 1
scoreboard players set @a[tag=soleil_participant,team=mBekou] sun_team 2
scoreboard players set @a[tag=soleil_participant,team=mGalia] sun_team 3
scoreboard players set @a[tag=soleil_participant,team=mHainy] sun_team 4
scoreboard players set @a[tag=soleil_participant,team=mIjo] sun_team 5
scoreboard players set @a[tag=soleil_participant,team=mKanawa] sun_team 6
scoreboard players set @a[tag=soleil_participant,team=mKecak] sun_team 7
scoreboard players set @a[tag=soleil_participant,team=mKembali] sun_team 8
scoreboard players set @a[tag=soleil_participant,team=mKuning] sun_team 9
scoreboard players set @a[tag=soleil_participant,team=mLiwai] sun_team 10
scoreboard players set @a[tag=soleil_participant,team=mMayra] sun_team 11
scoreboard players set @a[tag=soleil_participant,team=mMerge] sun_team 12
scoreboard players set @a[tag=soleil_participant,team=mMoemoea] sun_team 13
scoreboard players set @a[tag=soleil_participant,team=mPeluang] sun_team 14
scoreboard players set @a[tag=soleil_participant,team=mPonogoro] sun_team 15
scoreboard players set @a[tag=soleil_participant,team=mSambor] sun_team 16
scoreboard players set @a[tag=soleil_participant,team=mSinaoh] sun_team 17
scoreboard players set @a[tag=soleil_participant,team=mTuarua] sun_team 18
scoreboard players set @a[tag=soleil_participant,team=mAvispa] sun_team 19
scoreboard players set @a[tag=soleil_participant,team=Avispa] sun_team 19
scoreboard players set @a[tag=soleil_participant,team=avispa] sun_team 19
scoreboard players set @a[tag=soleil_participant,team=mStaff] sun_team 20
scoreboard players set @a[tag=soleil_participant,team=Staff] sun_team 20
scoreboard players set @a[tag=soleil_participant,team=staff] sun_team 20
scoreboard players set @a[tag=soleil_participant] sun_alive 0
scoreboard players set @a[tag=soleil_participant] sun_alive_sec 0
scoreboard players set @a[tag=soleil_participant] sun_finish 0
scoreboard players set @a[tag=soleil_participant] sun_qual_count 0
scoreboard players set @a[tag=soleil_participant] sun_qual_ticks 0
scoreboard players set @a[tag=soleil_participant] sun_manche_start 0
gamemode adventure @a[tag=soleil_participant]
spawnpoint @a[tag=soleil_participant] ~35 ~37 ~55
scoreboard players set #initial sun_game 0
execute as @a[tag=soleil_en_jeu] run scoreboard players add #initial sun_game 1
scoreboard players set #state sun_game 0
scoreboard players set #manche sun_game 1
scoreboard players set #finish_order sun_game 0
scoreboard players set #round sun_game 1
scoreboard players set #dead sun_game 0
scoreboard players set #final sun_game 0
scoreboard players set #ranking_done sun_game 0
function soleil:manche/set_duration
function soleil:terrain/restaurer
function soleil:head/reset
bossbar set soleil:etat players @a[tag=soleil_participant]
execute if score #initial sun_game matches 1.. run bossbar set soleil:etat visible true
execute if score #initial sun_game matches 1.. run function soleil:music/play
execute if score #initial sun_game matches 1.. run tellraw @a[tag=soleil_participant] [{"text":"[1, 2, 3 Soleil] ","color":"gold"},{"text":"Manche 1 — 60 secondes pour franchir l'arrivée.","color":"yellow","bold":true}]
execute if score #initial sun_game matches 1.. run tellraw @a[tag=soleil_participant] {text:"Aucune zone condamnée.",color:"green",bold:true}
execute if score #initial sun_game matches 1.. if score #test sun_game matches 1 run function soleil:test/round_info
execute if score #initial sun_game matches 1.. if score #test sun_game matches 1 run function soleil:test/start_info
execute if score #initial sun_game matches 1.. run function soleil:countdown/start
execute if score #initial sun_game matches 0 run tellraw @s {"text":"Aucun joueur avec le tag F15 n'a été trouvé.","color":"red"}
