tellraw @a[tag=F15] [{"text":"[1, 2, 3 Soleil] ","color":"gold"},{"text":"Aucun joueur qualifié et aucun gagnant : la partie recommence avec tous les joueurs F15.","color":"red","bold":true}]
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run function soleil:game/start_at_origin
