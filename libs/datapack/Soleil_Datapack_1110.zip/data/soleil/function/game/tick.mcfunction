
execute if score #state sun_game matches 1..3 as @a[tag=soleil_en_jeu] run scoreboard players add @s sun_alive 1
execute if score #state sun_game matches 1..3 run function soleil:zone/check
execute if score #state sun_game matches 2 as @a[tag=soleil_en_jeu] at @s run function soleil:player/check_move
execute if score #state sun_game matches 1..3 as @a[tag=soleil_en_jeu,tag=soleil_a_eliminer,limit=1,sort=arbitrary] at @s run function soleil:player/eliminer
execute if score #state sun_game matches 1..3 at @e[type=minecraft:marker,tag=soleil_origin,limit=1] positioned ~1 ~0 ~1 as @a[tag=soleil_en_jeu,tag=!soleil_a_eliminer,dx=68,dy=35,dz=10] at @s run function soleil:player/qualify
execute if score #state sun_game matches 1 run function soleil:phase/tick_green
execute if score #state sun_game matches 2 run function soleil:phase/tick_red
execute if score #state sun_game matches 3 run function soleil:phase/tick_transition
scoreboard players set #alive sun_game 0
execute if score #state sun_game matches 1..3 as @a[tag=soleil_en_jeu] run scoreboard players add #alive sun_game 1
execute if score #state sun_game matches 1..3 if score #alive sun_game matches 0 run function soleil:manche/complete_early
