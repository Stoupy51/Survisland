tag @s add soleil_gagnant
tag @s remove soleil_qualifie
gamemode adventure @s
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run tp @s ~35 ~37 ~55
execute as @a[tag=soleil_participant] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 2 1
tellraw @a[tag=soleil_participant] [{"text":"🏆 ","color":"gold"},{"selector":"@s","bold":true},{"text":" est le dernier survivant de son équipe !","color":"yellow"}]
