# Garantit exactement un gagnant pour chaque équipe représentée au début de la partie.
tag @a remove soleil_equipe_verifiee
tag @a remove soleil_fallback_candidate
execute as @a[tag=soleil_participant,tag=!soleil_equipe_verifiee] run function soleil:winner/evaluate_missing_team
tag @a remove soleil_equipe_verifiee
tag @a remove soleil_fallback_candidate
