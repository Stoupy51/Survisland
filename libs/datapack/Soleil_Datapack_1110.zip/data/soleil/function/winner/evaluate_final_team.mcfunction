execute if entity @s[tag=soleil_equipe_verifiee] run return 0
scoreboard players operation #current_team sun_game = @s sun_team
execute as @a[tag=soleil_qualifie] if score @s sun_team = #current_team sun_game run tag @s add soleil_equipe_verifiee
scoreboard players set #best_total sun_alive 2147483647
execute as @a[tag=soleil_qualifie] if score @s sun_team = #current_team sun_game run scoreboard players operation #best_total sun_alive < @s sun_alive
scoreboard players set #best_finish sun_finish 2147483647
execute as @a[tag=soleil_qualifie] if score @s sun_team = #current_team sun_game if score @s sun_alive = #best_total sun_alive run scoreboard players operation #best_finish sun_finish < @s sun_finish
execute as @a[tag=soleil_qualifie] if score @s sun_team = #current_team sun_game if score @s sun_alive = #best_total sun_alive if score @s sun_finish = #best_finish sun_finish run function soleil:winner/dynamic_final
execute as @a[tag=soleil_qualifie] if score @s sun_team = #current_team sun_game run tellraw @a[tag=soleil_participant] [{"text":"✖ ","color":"dark_red","bold":true},{"selector":"@s","color":"red","bold":true},{"text":" éliminé","color":"red","bold":true}]
execute as @a[tag=soleil_qualifie] if score @s sun_team = #current_team sun_game run tag @s add soleil_elimine
execute as @a[tag=soleil_qualifie] if score @s sun_team = #current_team sun_game run tag @s remove soleil_qualifie
