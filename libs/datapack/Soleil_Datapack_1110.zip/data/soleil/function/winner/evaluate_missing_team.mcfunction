execute if entity @s[tag=soleil_equipe_verifiee] run return 0
scoreboard players operation #current_team sun_game = @s sun_team
execute as @a[tag=soleil_participant] if score @s sun_team = #current_team sun_game run tag @s add soleil_equipe_verifiee
scoreboard players set #team_winners sun_game 0
execute as @a[tag=soleil_gagnant] if score @s sun_team = #current_team sun_game run scoreboard players add #team_winners sun_game 1
execute if score #team_winners sun_game matches 1.. run return 0
scoreboard players set #best_quals sun_qual_count -1
execute as @a[tag=soleil_participant] if score @s sun_team = #current_team sun_game run scoreboard players operation #best_quals sun_qual_count > @s sun_qual_count
scoreboard players set #best_qual_time sun_qual_ticks 2147483647
execute as @a[tag=soleil_participant] if score @s sun_team = #current_team sun_game if score @s sun_qual_count = #best_quals sun_qual_count run scoreboard players operation #best_qual_time sun_qual_ticks < @s sun_qual_ticks
scoreboard players set #best_survival sun_alive -1
execute as @a[tag=soleil_participant] if score @s sun_team = #current_team sun_game if score @s sun_qual_count = #best_quals sun_qual_count if score @s sun_qual_ticks = #best_qual_time sun_qual_ticks run scoreboard players operation #best_survival sun_alive > @s sun_alive
execute as @a[tag=soleil_participant] if score @s sun_team = #current_team sun_game if score @s sun_qual_count = #best_quals sun_qual_count if score @s sun_qual_ticks = #best_qual_time sun_qual_ticks if score @s sun_alive = #best_survival sun_alive run tag @s add soleil_fallback_candidate
execute as @a[tag=soleil_fallback_candidate,limit=1,sort=arbitrary] run function soleil:winner/dynamic_fallback
tag @a remove soleil_fallback_candidate
