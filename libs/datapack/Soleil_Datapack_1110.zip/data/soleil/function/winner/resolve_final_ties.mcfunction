# Après la sixième manche, chaque équipe encore indécise est départagée par le temps cumulé de qualification.
tag @a remove soleil_equipe_verifiee
execute as @a[tag=soleil_qualifie,tag=!soleil_equipe_verifiee] run function soleil:winner/evaluate_final_team
tag @a remove soleil_equipe_verifiee
