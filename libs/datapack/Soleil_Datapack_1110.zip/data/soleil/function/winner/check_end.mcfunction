# À la fin de la manche, chaque équipe est évaluée une seule fois.
# Une équipe avec un unique survivant obtient son gagnant ; avec plusieurs survivants, elle continue.
tag @a remove soleil_equipe_verifiee
execute as @a[tag=soleil_qualifie,tag=!soleil_equipe_verifiee] run function soleil:winner/evaluate_player
tag @a remove soleil_equipe_verifiee
