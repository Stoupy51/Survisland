execute if entity @s[tag=soleil_equipe_verifiee] run return 0
scoreboard players operation #current_team sun_game = @s sun_team
scoreboard players set #team_alive sun_game 0
execute as @a[tag=soleil_qualifie] if score @s sun_team = #current_team sun_game run scoreboard players add #team_alive sun_game 1
execute as @a[tag=soleil_qualifie] if score @s sun_team = #current_team sun_game run tag @s add soleil_equipe_verifiee
execute if score #team_alive sun_game matches 1 run function soleil:winner/dynamic
