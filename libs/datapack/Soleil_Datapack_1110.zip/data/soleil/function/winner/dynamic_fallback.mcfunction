tag @s add soleil_gagnant
tag @s remove soleil_elimine
tag @s remove soleil_qualifie
tag @s remove soleil_en_jeu
tag @s remove soleil_a_eliminer
gamemode adventure @s
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run tp @s ~35 ~37 ~55
scoreboard players operation @s sun_alive_sec = @s sun_qual_ticks
scoreboard players operation @s sun_alive_sec /= #rank_divisor sun_alive
execute as @a[tag=soleil_participant] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 2 1
tellraw @a[tag=soleil_participant] [{"text":"🏆 ","color":"gold"},{"selector":"@s","bold":true},{"text":" devient gagnant de son équipe grâce à sa meilleure performance : ","color":"yellow"},{"score":{"name":"@s","objective":"sun_qual_count"},"color":"aqua","bold":true},{"text":" qualification(s), ","color":"yellow"},{"score":{"name":"@s","objective":"sun_alive_sec"},"color":"green","bold":true},{"text":" s cumulées.","color":"yellow"}]
