scoreboard players add #manche sun_game 1
scoreboard players set #finish_order sun_game 0
scoreboard players set #round sun_game 1
scoreboard players set #dead sun_game 0
function soleil:manche/set_duration
function soleil:terrain/restaurer
function soleil:house/restaurer_vitres
tag @a[tag=soleil_qualifie] add soleil_en_jeu
tag @a remove soleil_qualifie
execute as @a[tag=soleil_en_jeu] run scoreboard players operation @s sun_manche_start = @s sun_alive
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run function soleil:round/teleport_survivors
function soleil:head/reset
data merge entity @e[type=minecraft:text_display,tag=soleil_signal,limit=1] {text:{text:"PRÊT",color:"yellow",bold:true}}
scoreboard players set #state sun_game 5
scoreboard players set #timer sun_game 60
bossbar set soleil:etat color yellow
bossbar set soleil:etat name {"text":"RETOUR À LA MAISON","color":"yellow","bold":true}
tellraw @a[tag=soleil_participant] [{"text":"[1, 2, 3 Soleil] ","color":"gold"},{"text":"Prochaine manche : ","color":"yellow"},{"score":{"name":"#manche","objective":"sun_game"},"color":"white","bold":true},{"text":"/6 — durée : ","color":"gray"},{"score":{"name":"#seconds","objective":"sun_game"},"color":"white","bold":true},{"text":" s — les zones repartent de zéro.","color":"gray"}]
execute if score #test sun_game matches 1 run function soleil:test/round_info
