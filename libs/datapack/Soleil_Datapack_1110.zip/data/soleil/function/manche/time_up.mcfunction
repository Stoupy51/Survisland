scoreboard players set #state sun_game 6
scoreboard players set #manche_ticks sun_game 0
scoreboard players set #seconds sun_game 0
function soleil:timer/render
stopsound @a[tag=soleil_participant] master survisland:soleil/green_light
tellraw @a[tag=soleil_participant] [{"text":"[1, 2, 3 Soleil] ","color":"gold"},{"text":"Le temps de la manche est écoulé.","color":"red","bold":true}]
tag @a[tag=soleil_en_jeu] add soleil_a_eliminer
