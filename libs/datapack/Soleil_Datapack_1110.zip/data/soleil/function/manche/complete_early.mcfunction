scoreboard players set #state sun_game 6
scoreboard players set #manche_ticks sun_game 0
scoreboard players set #seconds sun_game 0
function soleil:timer/render
stopsound @a[tag=soleil_participant] master survisland:soleil/green_light
tellraw @a[tag=soleil_participant] [{"text":"[1, 2, 3 Soleil] ","color":"gold"},{"text":"Plus aucun joueur n'est encore sur le terrain : fin immédiate de la manche.","color":"yellow","bold":true}]
