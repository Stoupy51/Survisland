execute if score #manche sun_game matches 1..2 run scoreboard players set #manche_ticks sun_game 1200
execute if score #manche sun_game matches 1..2 run scoreboard players set #seconds sun_game 60
execute if score #manche sun_game matches 3..4 run scoreboard players set #manche_ticks sun_game 900
execute if score #manche sun_game matches 3..4 run scoreboard players set #seconds sun_game 45
execute if score #manche sun_game matches 5.. run scoreboard players set #manche_ticks sun_game 600
execute if score #manche sun_game matches 5.. run scoreboard players set #seconds sun_game 30
