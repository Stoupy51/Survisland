
execute as @a[tag=soleil_elimine,gamemode=!adventure] run gamemode adventure @s
execute as @e[type=minecraft:marker,tag=soleil_head_anchor] at @s if score @s yh_steps matches 1.. run function soleil:head/animate
execute if score #state sun_game matches 1..3 run function soleil:timer/tick
execute if score #state sun_game matches 1..3 run function soleil:game/tick
execute if score #state sun_game matches 4 run function soleil:countdown/tick
execute if score #state sun_game matches 5 run function soleil:round/tick_restart_wait
execute if score #state sun_game matches 6 run function soleil:round/resolve
execute if score #state sun_game matches 1..6 run function soleil:music/tick
