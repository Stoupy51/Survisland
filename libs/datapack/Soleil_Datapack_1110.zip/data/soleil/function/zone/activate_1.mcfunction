
scoreboard players set #dead sun_game 1
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run fill ~1 ~1 ~92 ~69 ~1 ~107 minecraft:red_concrete
tellraw @a[tag=soleil_participant] [{text:"[1, 2, 3 Soleil] ",color:"gold"},{text:"Zone de départ et zone 1 condamnées !",color:"red",bold:true}]
execute as @a[tag=soleil_participant] at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 3 0.75 1
