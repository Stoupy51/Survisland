
scoreboard players set #dead sun_game 7
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run fill ~1 ~1 ~38 ~69 ~1 ~46 minecraft:red_concrete
tellraw @a[tag=soleil_participant] [{"text":"[1, 2, 3 Soleil] ","color":"gold"},{"text":"Zone 7 condamnée !","color":"red","bold":true}]
execute as @a[tag=soleil_participant] at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 1 0.75
