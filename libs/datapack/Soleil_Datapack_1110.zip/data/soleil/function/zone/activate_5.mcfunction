
scoreboard players set #dead sun_game 5
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run fill ~1 ~1 ~56 ~69 ~1 ~64 minecraft:red_concrete
tellraw @a[tag=soleil_participant] [{"text":"[1, 2, 3 Soleil] ","color":"gold"},{"text":"Zone 5 condamnée !","color":"red","bold":true}]
execute as @a[tag=soleil_participant] at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 1 0.75
