execute if score #ranking_done sun_game matches 1 run return 0
scoreboard players set #ranking_done sun_game 1
execute if score #test sun_game matches 0 run function soleil:winner/ensure_all
scoreboard players set #state sun_game 0
function soleil:music/stop
bossbar set soleil:etat visible false
data merge entity @e[type=minecraft:text_display,tag=soleil_signal,limit=1] {text:{text:"CLASSEMENT",color:"gold",bold:true}}
function soleil:head/turn_front
function soleil:ranking/show
function soleil:cleanup/player_tags
