
execute if entity @e[type=minecraft:marker,tag=soleil_origin,limit=1] at @e[type=minecraft:marker,tag=soleil_origin,sort=nearest,limit=1] run function soleil:setup/from_origin
execute unless entity @e[type=minecraft:marker,tag=soleil_origin,limit=1] unless block ~ ~-1 ~ minecraft:gold_block run tellraw @s [{text:"[1, 2, 3 Soleil] ",color:"gold"},{text:"Colle la schematic avec ses entités, ou place-toi sur le bloc d'or supérieur puis relance /function soleil:setup",color:"red"}]
execute unless entity @e[type=minecraft:marker,tag=soleil_origin,limit=1] if block ~ ~-1 ~ minecraft:gold_block positioned ~-35 ~-37 ~-55 run function soleil:setup/from_origin
