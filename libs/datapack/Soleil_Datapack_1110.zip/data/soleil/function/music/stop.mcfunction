
stopsound @a[tag=soleil_participant] record soleil:pink_soldiers
stopsound @a[tag=soleil_participant] master soleil:green_light
