
stopsound @a[tag=soleil_participant] record survisland:soleil/pink_soldiers
stopsound @a[tag=soleil_participant] master survisland:soleil/green_light
