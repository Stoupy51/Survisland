
scoreboard players remove #music_timer sun_game 1
execute if score #music_timer sun_game matches ..0 run function soleil:music/play
