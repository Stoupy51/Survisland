
stopsound @a[tag=soleil_participant] record soleil:pink_soldiers
execute as @a[tag=soleil_participant] at @s run playsound soleil:pink_soldiers record @s ~ ~ ~ 1 1 1
scoreboard players set #music_timer sun_game 675
