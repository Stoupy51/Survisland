execute if score #voice sun_game matches 0 run function soleil:voice/green_60
execute if score #voice sun_game matches 1 run function soleil:voice/green_70
execute if score #voice sun_game matches 2 run function soleil:voice/green_80
execute if score #voice sun_game matches 3 run function soleil:voice/green_90
execute if score #voice sun_game matches 4 run function soleil:voice/green_100
execute if score #voice sun_game matches 5 run function soleil:voice/green_110
execute if score #voice sun_game matches 6 run function soleil:voice/green_120
