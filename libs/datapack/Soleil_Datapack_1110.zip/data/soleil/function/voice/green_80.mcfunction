
scoreboard players set #timer sun_game 127
stopsound @a[tag=soleil_participant] master soleil:green_light
execute as @a[tag=soleil_participant] at @s run playsound soleil:green_light master @s ~ ~ ~ 3 0.73 1
