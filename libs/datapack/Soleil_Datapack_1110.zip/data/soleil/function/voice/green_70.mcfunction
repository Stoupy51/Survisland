
scoreboard players set #timer sun_game 113
stopsound @a[tag=soleil_participant] master survisland:soleil/green_light
execute as @a[tag=soleil_participant] at @s run playsound survisland:soleil/green_light master @s ~ ~ ~ 3 0.8204425 1
