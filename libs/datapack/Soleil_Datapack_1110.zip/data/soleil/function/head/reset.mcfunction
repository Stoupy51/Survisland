
execute as @e[type=minecraft:marker,tag=soleil_head_anchor] at @s run tp @s ~ ~ ~ 0 0
scoreboard players set @e[type=minecraft:marker,tag=soleil_head_anchor] yh_steps 0
scoreboard players set @e[type=minecraft:marker,tag=soleil_head_anchor] yh_dir 0
scoreboard players set @e[type=minecraft:marker,tag=soleil_head_anchor] yh_facing 0
execute as @e[type=minecraft:marker,tag=soleil_head_anchor] at @s rotated as @s run function soleil:head/follow
