
execute as @e[type=minecraft:marker,tag=soleil_head_anchor] unless score @s yh_facing matches 1 run scoreboard players set @s yh_steps 10
execute as @e[type=minecraft:marker,tag=soleil_head_anchor] unless score @s yh_facing matches 1 run scoreboard players set @s yh_dir 1
scoreboard players set @e[type=minecraft:marker,tag=soleil_head_anchor] yh_facing 1
