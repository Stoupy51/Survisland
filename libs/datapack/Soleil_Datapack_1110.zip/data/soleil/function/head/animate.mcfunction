
execute if score @s yh_dir matches 1 run tp @s ~ ~ ~ ~18 ~
execute if score @s yh_dir matches -1 run tp @s ~ ~ ~ ~-18 ~
scoreboard players remove @s yh_steps 1
execute at @s rotated as @s run function soleil:head/follow
