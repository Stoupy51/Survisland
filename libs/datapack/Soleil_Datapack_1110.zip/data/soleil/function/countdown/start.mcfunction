
scoreboard players set #state sun_game 4
scoreboard players set #countdown sun_game 5
scoreboard players set #timer sun_game 20
function soleil:manche/set_duration
scoreboard players set #last_seconds sun_game -1
function soleil:timer/render
function soleil:house/cacher_vitres
bossbar set soleil:etat color yellow
bossbar set soleil:etat name {"text":"OUVERTURE DANS 5","color":"yellow","bold":true}
title @a[tag=soleil_participant] times 0 15 5
function soleil:countdown/show
