
execute if score #countdown sun_game matches 5 run title @a[tag=soleil_participant] title {"text":"5","color":"yellow","bold":true}
execute if score #countdown sun_game matches 4 run title @a[tag=soleil_participant] title {"text":"4","color":"yellow","bold":true}
execute if score #countdown sun_game matches 3 run title @a[tag=soleil_participant] title {"text":"3","color":"gold","bold":true}
execute if score #countdown sun_game matches 2 run title @a[tag=soleil_participant] title {"text":"2","color":"gold","bold":true}
execute if score #countdown sun_game matches 1 run title @a[tag=soleil_participant] title {"text":"1","color":"red","bold":true}
execute if score #countdown sun_game matches 5 run bossbar set soleil:etat name {"text":"OUVERTURE DANS 5","color":"yellow","bold":true}
execute if score #countdown sun_game matches 4 run bossbar set soleil:etat name {"text":"OUVERTURE DANS 4","color":"yellow","bold":true}
execute if score #countdown sun_game matches 3 run bossbar set soleil:etat name {"text":"OUVERTURE DANS 3","color":"gold","bold":true}
execute if score #countdown sun_game matches 2 run bossbar set soleil:etat name {"text":"OUVERTURE DANS 2","color":"gold","bold":true}
execute if score #countdown sun_game matches 1 run bossbar set soleil:etat name {"text":"OUVERTURE DANS 1","color":"red","bold":true}
execute as @a[tag=soleil_participant] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #test sun_game matches 1 run tellraw @a[tag=soleil_participant] [{"text":"[TEST] Départ dans ","color":"aqua"},{"score":{"name":"#countdown","objective":"sun_game"},"color":"yellow","bold":true},{"text":"...","color":"aqua"}]
