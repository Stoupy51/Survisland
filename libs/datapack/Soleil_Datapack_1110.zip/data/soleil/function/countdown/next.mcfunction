
scoreboard players remove #countdown sun_game 1
scoreboard players set #timer sun_game 20
execute if score #countdown sun_game matches 1.. run function soleil:countdown/show
execute if score #countdown sun_game matches ..0 run function soleil:countdown/go
