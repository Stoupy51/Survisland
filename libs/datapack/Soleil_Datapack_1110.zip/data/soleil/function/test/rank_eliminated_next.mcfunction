scoreboard players set #rank_max sun_alive -1
execute as @a[tag=F15,tag=!soleil_qualifie,tag=!soleil_classe] run scoreboard players operation #rank_max sun_alive > @s sun_alive
execute as @a[tag=F15,tag=!soleil_qualifie,tag=!soleil_classe] if score @s sun_alive = #rank_max sun_alive run function soleil:test/rank_eliminated_place
execute if entity @a[tag=F15,tag=!soleil_qualifie,tag=!soleil_classe] run function soleil:test/rank_eliminated_next
