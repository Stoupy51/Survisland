scoreboard players add #rank sun_game 1
tag @s add soleil_classe
tellraw @a [{"score":{"name":"#rank","objective":"sun_game"},"color":"white","bold":true},{"text":". ","color":"white"},{"selector":"@s","color":"green","bold":true},{"text":" — qualifié en ","color":"green"},{"score":{"name":"@s","objective":"sun_alive_sec"},"color":"yellow","bold":true},{"text":" s","color":"yellow"}]
