scoreboard players add #rank sun_game 1
tag @s add soleil_classe
tellraw @a [{"score":{"name":"#rank","objective":"sun_game"},"color":"white","bold":true},{"text":". ","color":"white"},{"selector":"@s","color":"red"},{"text":" — éliminé — ","color":"dark_red"},{"score":{"name":"@s","objective":"sun_alive_sec"},"color":"red"},{"text":" s en vie","color":"red"}]
