# Résumé lisible par les joueurs au début de chaque manche test.
scoreboard players set #alive sun_game 0
execute as @a[tag=soleil_en_jeu] run scoreboard players add #alive sun_game 1
tellraw @a[tag=soleil_participant] [{text:"PARTIE TEST — MANCHE UNIQUE — ROUND ",color:"aqua",bold:true},{score:{name:"#round",objective:"sun_game"},color:"white",bold:true},{text:" — durée : ",color:"yellow"},{score:{name:"#seconds",objective:"sun_game"},color:"white",bold:true},{text:" s — Joueurs en jeu : ",color:"yellow"},{score:{name:"#alive",objective:"sun_game"},color:"white",bold:true}]
execute if score #dead sun_game matches 0 run tellraw @a[tag=soleil_participant] {text:"Aucune zone condamnée.",color:"green",bold:true}
execute if score #dead sun_game matches 1 run tellraw @a[tag=soleil_participant] {text:"Zone de départ et zone 1 condamnées.",color:"red",bold:true}
execute if score #dead sun_game matches 2..9 run tellraw @a[tag=soleil_participant] [{text:"Zone de départ et zones 1 à ",color:"red",bold:true},{score:{name:"#dead",objective:"sun_game"},color:"dark_red",bold:true},{text:" condamnées.",color:"red",bold:true}]
