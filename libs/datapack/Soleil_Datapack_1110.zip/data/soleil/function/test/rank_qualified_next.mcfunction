scoreboard players set #test_best sun_finish 2147483647
execute as @a[tag=F15,tag=soleil_qualifie,tag=!soleil_classe] run scoreboard players operation #test_best sun_finish < @s sun_finish
execute as @a[tag=F15,tag=soleil_qualifie,tag=!soleil_classe] if score @s sun_finish = #test_best sun_finish run function soleil:test/rank_qualified_place
execute if entity @a[tag=F15,tag=soleil_qualifie,tag=!soleil_classe] run function soleil:test/rank_qualified_next
