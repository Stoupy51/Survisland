scoreboard players add @a[tag=F15] sun_alive 0
scoreboard players add @a[tag=F15] sun_alive_sec 0
execute as @a[tag=F15] run scoreboard players operation @s sun_alive_sec = @s sun_alive
execute as @a[tag=F15] run scoreboard players operation @s sun_alive_sec /= #rank_divisor sun_alive
tag @a remove soleil_classe
scoreboard players set #rank sun_game 0
tellraw @a [{"text":"\n════════ CLASSEMENT DE LA PARTIE TEST ════════","color":"aqua","bold":true}]
tellraw @a [{"text":"— JOUEURS QUALIFIÉS, PAR ORDRE D'ARRIVÉE —","color":"green","bold":true}]
function soleil:test/rank_qualified_next
execute unless entity @a[tag=F15,tag=soleil_qualifie] run tellraw @a {"text":"  Aucun joueur qualifié.","color":"gray","italic":true}
tellraw @a [{"text":"— JOUEURS ÉLIMINÉS, PAR TEMPS DE SURVIE —","color":"red","bold":true}]
function soleil:test/rank_eliminated_next
tellraw @a [{"text":"═══════════════════════════════════════════════\n","color":"aqua","bold":true}]
