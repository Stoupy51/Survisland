tellraw @a[tag=soleil_participant] [{"text":"════════ FIN DE LA PARTIE TEST ════════","color":"aqua","bold":true}]
execute if entity @a[tag=soleil_qualifie] run tellraw @a[tag=soleil_participant] [{"text":"Joueurs qualifiés : ","color":"green"},{"selector":"@a[tag=soleil_qualifie]","color":"white","bold":true}]
execute unless entity @a[tag=soleil_qualifie] run tellraw @a[tag=soleil_participant] [{"text":"Aucun joueur qualifié : ","color":"red","bold":true},{"text":"personne n'a franchi la ligne d'arrivée avant la fin de la manche.","color":"yellow"}]
tellraw @a[tag=soleil_participant] {"text":"Le test ne désigne aucun gagnant : seul le classement compte.","color":"aqua"}
function soleil:final/end
scoreboard players set #test sun_game 0
