tellraw @a[tag=soleil_participant] [{"text":"════════ PARTIE TEST ════════","color":"aqua","bold":true}]
tellraw @a[tag=soleil_participant] [{"text":"Cette partie test dure une seule manche de 60 secondes.","color":"yellow"}]
tellraw @a[tag=soleil_participant] [{"text":"À la fin, un classement du test sera affiché sans désigner de gagnant.","color":"green","bold":true}]
tellraw @a[tag=soleil_participant] [{"text":"Les qualifiés seront classés par ordre d'arrivée, puis les éliminés par temps de survie.","color":"gray"}]
