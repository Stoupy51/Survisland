# Lance la partie avec les informations de progression destinées aux joueurs.
scoreboard players set #test sun_game 1
execute unless entity @e[type=minecraft:marker,tag=soleil_origin,limit=1] run tellraw @s {text:"Utilise d'abord /function soleil:setup en étant sur le bloc d'or.",color:"red"}
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run function soleil:game/start_at_origin
