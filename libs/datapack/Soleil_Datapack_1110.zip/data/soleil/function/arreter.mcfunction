
scoreboard players set #state sun_game 0
scoreboard players set #test sun_game 0
function soleil:music/stop
bossbar set soleil:etat visible false
data merge entity @e[type=minecraft:text_display,tag=soleil_signal,limit=1] {text:{text:"ARRÊT",color:"gray",bold:true}}
tellraw @a[tag=soleil_participant] {"text":"Épreuve arrêtée.","color":"gray"}
function soleil:cleanup/player_tags
