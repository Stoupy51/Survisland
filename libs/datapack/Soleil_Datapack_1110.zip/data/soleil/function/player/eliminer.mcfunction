
tag @s remove soleil_en_jeu
tag @s remove soleil_a_eliminer
tag @s add soleil_elimine
gamemode adventure @s
tellraw @a[tag=soleil_participant] [{"text":"✖ ","color":"dark_red","bold":true},{"selector":"@s","color":"red","bold":true},{"text":" éliminé","color":"red","bold":true}]
title @s times 0 50 10
title @s title {"text":"ÉLIMINÉ !","color":"red","bold":true}
playsound minecraft:item.crossbow.shoot master @s ~ ~ ~ 2 0.75
playsound minecraft:entity.firework_rocket.large_blast master @s ~ ~ ~ 2 0.65
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run tp @s ~35 ~37 ~55
