scoreboard players add #finish_order sun_game 1
scoreboard players operation @s sun_finish = #finish_order sun_game
scoreboard players operation #qual_split sun_game = @s sun_alive
scoreboard players operation #qual_split sun_game -= @s sun_manche_start
scoreboard players operation @s sun_qual_ticks += #qual_split sun_game
scoreboard players add @s sun_qual_count 1
tag @s remove soleil_en_jeu
tag @s remove soleil_a_eliminer
tag @s add soleil_qualifie
gamemode adventure @s
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 2 1.2
tellraw @a[tag=soleil_participant] [{"text":"✓ ","color":"green"},{"selector":"@s","bold":true},{"text":" a franchi la ligne et se qualifie pour la prochaine manche.","color":"green"}]
execute at @e[type=minecraft:marker,tag=soleil_origin,limit=1] run tp @s ~35 ~37 ~55
