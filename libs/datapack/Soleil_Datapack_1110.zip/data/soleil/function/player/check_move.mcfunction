
execute store result score @s sun_x run data get entity @s Pos[0] 100
execute store result score @s sun_z run data get entity @s Pos[2] 100
scoreboard players operation @s sun_dx = @s sun_x
scoreboard players operation @s sun_dx -= @s sun_x0
scoreboard players operation @s sun_dz = @s sun_z
scoreboard players operation @s sun_dz -= @s sun_z0
execute if score @s sun_dx matches ..-1 run scoreboard players operation @s sun_dx *= #minus sun_game
execute if score @s sun_dz matches ..-1 run scoreboard players operation @s sun_dz *= #minus sun_game
execute if score @s sun_dx matches 12.. run tag @s add soleil_a_eliminer
execute if score @s sun_dz matches 12.. run tag @s add soleil_a_eliminer
