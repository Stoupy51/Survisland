
scoreboard objectives add sun_game dummy
scoreboard objectives add sun_x dummy
scoreboard objectives add sun_z dummy
scoreboard objectives add sun_x0 dummy
scoreboard objectives add sun_z0 dummy
scoreboard objectives add sun_dx dummy
scoreboard objectives add sun_dz dummy
scoreboard objectives add yh_steps dummy
scoreboard objectives add yh_dir dummy
scoreboard objectives add yh_facing dummy
scoreboard objectives add sun_alive dummy
scoreboard objectives add sun_alive_sec dummy
scoreboard objectives add sun_team dummy
scoreboard objectives add sun_finish dummy
scoreboard objectives add sun_qual_count dummy
scoreboard objectives add sun_qual_ticks dummy
scoreboard objectives add sun_manche_start dummy
scoreboard players set #minus sun_game -1
scoreboard players set #twenty sun_game 20
scoreboard players set #seconds sun_game 60
scoreboard players set #state sun_game 0
scoreboard players set #test sun_game 0
scoreboard players set #rank_divisor sun_alive 20
