
#> shopping_kart:v1.4.1/load/tick_verification
#
# @within	#minecraft:tick
#

execute if score #shopping_kart.major load.status matches 1 if score #shopping_kart.minor load.status matches 4 if score #shopping_kart.patch load.status matches 1 run function shopping_kart:v1.4.1/tick

