execute as @e[tag=smithed.crafter] at @s run function smithed.crafter:v0.6.2/block/table/tick
schedule function smithed.crafter:v0.6.2/technical/tick 1 replace
