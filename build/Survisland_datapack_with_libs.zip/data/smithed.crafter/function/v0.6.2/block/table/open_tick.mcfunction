execute if entity @s[predicate=smithed.crafter:block/table/invalid_items] run function smithed.crafter:v0.6.2/block/table/crafting/manage_invalids/move
data modify storage smithed.crafter:main root.Items set from block ~ ~ ~ Items
execute store success score @s smithed.data run data modify entity @s ArmorItems[3].components."minecraft:custom_data".smithed.stored_output set from storage smithed.crafter:main root.Items[{Slot: 16b}]
execute store success score @s smithed.data unless data storage smithed.crafter:main root.Items[{Slot: 16b}] if data entity @s ArmorItems[3].components."minecraft:custom_data".smithed.stored_output.id run data modify entity @s ArmorItems[3].components."minecraft:custom_data".smithed.stored_output set value {Slot: 16b}
execute if entity @s[scores={smithed.data=1..}] run function smithed.crafter:v0.6.2/block/table/crafting/output/check
execute store success score @s smithed.data run data modify entity @s ArmorItems[3].components."minecraft:custom_data".smithed.stored_barrel_data set from block ~ ~ ~ Items
execute if entity @s[scores={smithed.data=1..}] if data block ~ ~ ~ Items run function smithed.crafter:v0.6.2/block/table/crafting/input/read_barrel
