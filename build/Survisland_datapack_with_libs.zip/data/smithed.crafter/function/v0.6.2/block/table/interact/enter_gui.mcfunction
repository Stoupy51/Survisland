tag @s add smithed.inside_crafter
advancement revoke @s only smithed.crafter:technical/enter_gui
