execute if data storage smithed.custom_block:main {blockApi: {id: "smithed:crafter"}} run function smithed.crafter:v0.6.2/block/table/place
