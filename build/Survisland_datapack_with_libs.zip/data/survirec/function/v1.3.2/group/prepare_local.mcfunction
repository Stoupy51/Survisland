
#> survirec:v1.3.2/group/prepare_local
#
# @within	survirec:v1.3.2/api/play
#

# the group id is resolved when the entity appears, from the entities of the same group nearby
data modify storage survirec:call options.group_id set value -1
data modify storage survirec:call options.group_loop set from storage survirec:call options.loop
data modify storage survirec:call options.loop set value 0

