
#> survirec:v1.3.2/group/mark_if_finished
#
# @within	survirec:v1.3.2/group/check
#			survirec:v1.3.2/group/on_member_frozen
#

scoreboard players set #group_alive survirec.data 0
execute as @e[tag=survirec.instance] if score @s survirec.group_id = #group survirec.data if score @s survirec.play_state matches 1..2 run scoreboard players set #group_alive survirec.data 1
execute if score #group_alive survirec.data matches 0 as @e[tag=survirec.instance] if score @s survirec.group_id = #group survirec.data unless score @s survirec.group_loop matches 0 unless score @s survirec.group_loop matches 2 run scoreboard players set @s survirec.restart_pending 1
execute if score #group_alive survirec.data matches 0 as @e[tag=survirec.instance] if score @s survirec.group_id = #group survirec.data if score @s survirec.redstone matches 1 run function survirec:v1.3.2/pulse/start
execute if score #group_alive survirec.data matches 0 as @e[tag=survirec.instance] if score @s survirec.group_id = #group survirec.data if score @s survirec.group_loop matches 2 run function survirec:v1.3.2/playback/delete
execute if score #group_alive survirec.data matches 0 as @e[tag=survirec.instance] if score @s survirec.group_id = #group survirec.data if score @s survirec.group_loop matches 0 if score @s survirec.restore_mode matches 2 run function survirec:v1.3.2/vault/restore
execute if score #group_alive survirec.data matches 0 run scoreboard players set #has_pending_group survirec.data 1

