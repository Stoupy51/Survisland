
#> survirec:v1.3.2/group/on_member_frozen
#
# @within	survirec:v1.3.2/playback/freeze
#

scoreboard players operation #group survirec.data = @s survirec.group_id
function survirec:v1.3.2/group/mark_if_finished

