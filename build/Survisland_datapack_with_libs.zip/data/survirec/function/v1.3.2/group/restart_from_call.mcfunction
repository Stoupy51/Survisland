
#> survirec:v1.3.2/group/restart_from_call
#
# @within	survirec:v1.3.2/api/group_restart with storage survirec:call options
#
# @args		group (string)
#			radius (int)
#

# radius 0 restarts every scene of that name, any other radius the nearest one only
$execute if data storage survirec:call options{radius:0} as @e[tag=survirec.instance,tag=survirec.group.$(group)] run scoreboard players set @s survirec.restart_pending 1
scoreboard players set #found_group survirec.data 0
$execute unless data storage survirec:call options{radius:0} as @e[tag=survirec.instance,tag=survirec.group.$(group),distance=..$(radius),sort=nearest,limit=1] run scoreboard players operation #found_group survirec.data = @s survirec.group_id
execute if score #found_group survirec.data matches 1.. as @e[tag=survirec.instance] if score @s survirec.group_id = #found_group survirec.data run scoreboard players set @s survirec.restart_pending 1
function survirec:v1.3.2/group/restart_pending

