
#> survirec:v1.3.2/group/restart_pending
#
# @within	survirec:v1.3.2/tick
#			survirec:v1.3.2/group/restart_from_call
#			survirec:v1.3.2/group/check
#

scoreboard players set #has_pending_group survirec.data 0
execute as @e[tag=survirec.instance,scores={survirec.restart_pending=1}] run function survirec:v1.3.2/group/walk_back

