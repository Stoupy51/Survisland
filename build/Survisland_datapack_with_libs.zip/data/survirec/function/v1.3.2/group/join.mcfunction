
#> survirec:v1.3.2/group/join
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init_sequence
#

# an entity joining a group that plays waits for its next cycle, unless the group started this tick
tag @s add survirec.self
scoreboard players operation #group survirec.data = @s survirec.group_id
scoreboard players set #group_alive survirec.data 0
scoreboard players set #started_this_tick survirec.data 0
execute as @e[tag=survirec.instance,tag=!survirec.self] if score @s survirec.group_id = #group survirec.data if score @s survirec.play_state matches 1..2 run scoreboard players set #group_alive survirec.data 1
execute as @e[tag=survirec.instance,tag=!survirec.self] if score @s survirec.group_id = #group survirec.data if score @s survirec.play_state matches 1 if score @s survirec.group_start_tick = #tick survirec.data run scoreboard players set #started_this_tick survirec.data 1
tag @s remove survirec.self
execute if score #group_alive survirec.data matches 1 unless score #started_this_tick survirec.data matches 1 run scoreboard players set @s survirec.play_state 0
execute unless score @s survirec.play_state matches 0 run scoreboard players operation @s survirec.group_start_tick = #tick survirec.data

