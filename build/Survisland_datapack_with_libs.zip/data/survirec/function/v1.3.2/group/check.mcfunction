
#> survirec:v1.3.2/group/check
#
# @within	survirec:v1.3.2/challenge/start
#

function survirec:v1.3.2/group/mark_if_finished
execute if score #has_pending_group survirec.data matches 1 run function survirec:v1.3.2/group/restart_pending

