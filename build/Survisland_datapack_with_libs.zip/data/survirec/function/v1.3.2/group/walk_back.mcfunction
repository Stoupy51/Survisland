
#> survirec:v1.3.2/group/walk_back
#
# @executed	as @e[tag=survirec.instance,scores={survirec.restart_pending=1}]
#
# @within	survirec:v1.3.2/group/restart_pending [ as @e[tag=survirec.instance,scores={survirec.restart_pending=1}] ]
#

# 2 seconds back to the start point, then the group starts again together
scoreboard players set @s survirec.restart_pending 0
execute if score @s survirec.restore_mode matches 1.. run function survirec:v1.3.2/vault/restore
execute unless score @s survirec.keyframe_count matches 1.. run return 0
scoreboard players operation @s survirec.delta_x = @s survirec.start_x
scoreboard players operation @s survirec.delta_x -= @s survirec.keyframe_x
scoreboard players operation @s survirec.delta_y = @s survirec.start_y
scoreboard players operation @s survirec.delta_y -= @s survirec.keyframe_y
scoreboard players operation @s survirec.delta_z = @s survirec.start_z
scoreboard players operation @s survirec.delta_z -= @s survirec.keyframe_z
scoreboard players operation @s survirec.delta_yaw = @s survirec.start_yaw
scoreboard players operation @s survirec.delta_yaw -= @s survirec.keyframe_yaw
execute if score @s survirec.delta_yaw matches 18001.. run scoreboard players remove @s survirec.delta_yaw 36000
execute if score @s survirec.delta_yaw matches ..-18001 run scoreboard players add @s survirec.delta_yaw 36000
scoreboard players operation @s survirec.delta_pitch = @s survirec.start_pitch
scoreboard players operation @s survirec.delta_pitch -= @s survirec.keyframe_pitch
scoreboard players set @s survirec.keyframe_divisor 40
scoreboard players set @s survirec.keyframe_progress 0
scoreboard players set @s survirec.is_still 0
scoreboard players set @s survirec.is_still_placed 0
scoreboard players set @s survirec.next_pose_flags 0
execute if score @s survirec.is_pose_fixed matches 0 unless score @s survirec.next_pose_flags = @s survirec.pose_flags run function survirec:v1.3.2/playback/apply_pose
scoreboard players set @s survirec.play_state 2

