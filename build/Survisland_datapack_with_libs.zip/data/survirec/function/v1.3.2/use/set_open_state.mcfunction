
#> survirec:v1.3.2/use/set_open_state
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/use/toggle_door
#			survirec:v1.3.2/use/toggle_door_half
#			survirec:v1.3.2/use/toggle_open
#

execute if score #target_open survirec.data matches 1 run function #bs.block:replace_properties {properties:[{name:"open",value:"true"}]}
execute if score #target_open survirec.data matches 0 run function #bs.block:replace_properties {properties:[{name:"open",value:"false"}]}

