
#> survirec:v1.3.2/use/toggle_open
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/use_block
#

scoreboard players set #restore_strict survirec.data 0
function survirec:v1.3.2/vault/back_up_here
scoreboard players set #target_open survirec.data 1
execute if score #block_open survirec.data matches 1 run scoreboard players set #target_open survirec.data 0
function survirec:v1.3.2/use/set_open_state
function survirec:v1.3.2/block/store_state
function survirec:v1.3.2/block/set_state with storage survirec:block
execute if block ~ ~ ~ #minecraft:fence_gates if score #block_open survirec.data matches 0 run playsound minecraft:block.fence_gate.open block @a[distance=..24] ~ ~ ~
execute if block ~ ~ ~ #minecraft:fence_gates if score #block_open survirec.data matches 1 run playsound minecraft:block.fence_gate.close block @a[distance=..24] ~ ~ ~
execute unless block ~ ~ ~ #minecraft:fence_gates if score #block_open survirec.data matches 0 run playsound minecraft:block.wooden_trapdoor.open block @a[distance=..24] ~ ~ ~
execute unless block ~ ~ ~ #minecraft:fence_gates if score #block_open survirec.data matches 1 run playsound minecraft:block.wooden_trapdoor.close block @a[distance=..24] ~ ~ ~

