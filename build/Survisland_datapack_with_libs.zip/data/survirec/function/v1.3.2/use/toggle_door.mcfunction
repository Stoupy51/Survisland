
#> survirec:v1.3.2/use/toggle_door
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/use_block
#

# both halves are set without block updates, so that they do not copy each other
scoreboard players set #target_open survirec.data 1
execute if score #block_open survirec.data matches 1 run scoreboard players set #target_open survirec.data 0
function survirec:v1.3.2/block/find_other_half
scoreboard players set #restore_strict survirec.data 1
function survirec:v1.3.2/vault/back_up_here
function survirec:v1.3.2/use/set_open_state
function survirec:v1.3.2/block/store_state
function survirec:v1.3.2/block/set_state_strict with storage survirec:block
execute if score #is_pair survirec.data matches 1 run function survirec:v1.3.2/use/toggle_other_half
execute if score #target_open survirec.data matches 1 run playsound minecraft:block.wooden_door.open block @a[distance=..24] ~ ~ ~
execute if score #target_open survirec.data matches 0 run playsound minecraft:block.wooden_door.close block @a[distance=..24] ~ ~ ~

