
#> survirec:v1.3.2/use/toggle_lever
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/use_block
#

scoreboard players set #restore_strict survirec.data 0
function survirec:v1.3.2/vault/back_up_here
execute if score #block_powered survirec.data matches 0 run function #bs.block:replace_properties {properties:[{name:"powered",value:"true"}]}
execute if score #block_powered survirec.data matches 1 run function #bs.block:replace_properties {properties:[{name:"powered",value:"false"}]}
function survirec:v1.3.2/block/store_state
function survirec:v1.3.2/block/set_state with storage survirec:block
function survirec:v1.3.2/block/find_support
function survirec:v1.3.2/block/update_support_at with storage survirec:playback support_offset
playsound minecraft:block.lever.click block @a[distance=..24] ~ ~ ~

