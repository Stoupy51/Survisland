
#> survirec:v1.3.2/use/toggle_door_half
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/use/toggle_other_half_at
#

# block/read resets the flags: the open state of the first half is kept aside
scoreboard players operation #kept_target_open survirec.data = #target_open survirec.data
function survirec:v1.3.2/block/read
execute if data storage survirec:block {id:""} run return 0
scoreboard players operation #target_open survirec.data = #kept_target_open survirec.data
scoreboard players set #restore_strict survirec.data 1
function survirec:v1.3.2/vault/back_up_here
function survirec:v1.3.2/use/set_open_state
function survirec:v1.3.2/block/store_state
function survirec:v1.3.2/block/set_state_strict with storage survirec:block

