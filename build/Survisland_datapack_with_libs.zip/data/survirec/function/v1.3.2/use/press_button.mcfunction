
#> survirec:v1.3.2/use/press_button
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/use_block
#

execute if score #block_powered survirec.data matches 1 run return 0
scoreboard players set #restore_strict survirec.data 0
function survirec:v1.3.2/vault/back_up_here
function #bs.block:replace_properties {properties:[{name:"powered",value:"true"}]}
function survirec:v1.3.2/block/store_state
function survirec:v1.3.2/block/set_state with storage survirec:block
function survirec:v1.3.2/block/find_support
function survirec:v1.3.2/block/update_support_at with storage survirec:playback support_offset
playsound minecraft:block.stone_button.click_on block @a[distance=..24] ~ ~ ~
# released after the vanilla delay: 1 s for stone, 1.5 s for wood
function #bs.block:replace_properties {properties:[{name:"powered",value:"false"}]}
function survirec:v1.3.2/block/store_state
data modify storage survirec:playback release set value {tick:0,x:0,y:0,z:0,block:"",support_x:0,support_y:0,support_z:0}
function survirec:v1.3.2/block/mark_support with storage survirec:playback support_offset
data modify storage survirec:playback release.block set from storage survirec:block state
scoreboard players operation #release_tick survirec.data = #game_time survirec.data
scoreboard players add #release_tick survirec.data 20
execute if block ~ ~ ~ #minecraft:wooden_buttons run scoreboard players add #release_tick survirec.data 10
execute store result storage survirec:playback release.tick int 1 run scoreboard players get #release_tick survirec.data
execute summon minecraft:marker run function survirec:v1.3.2/release/store_position
function survirec:v1.3.2/release/add

