
#> survirec:v1.3.2/use/toggle_other_half_at
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/use/toggle_other_half with storage survirec:playback pair_offset
#
# @args		y (int)
#

$execute positioned ~ ~$(y) ~ run function survirec:v1.3.2/use/toggle_door_half

