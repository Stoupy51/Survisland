
#> survirec:v1.3.2/api/signals/on_spawn
#
# @within	#survirec:v1/signals/on_spawn
#

# Placeholder so the tag always exists. Add your own function to the tag to react to the event.

