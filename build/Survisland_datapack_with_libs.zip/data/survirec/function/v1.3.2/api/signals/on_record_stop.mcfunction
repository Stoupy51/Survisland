
#> survirec:v1.3.2/api/signals/on_record_stop
#
# @within	#survirec:v1/signals/on_record_stop
#

# Placeholder so the tag always exists. Add your own function to the tag to react to the event.

