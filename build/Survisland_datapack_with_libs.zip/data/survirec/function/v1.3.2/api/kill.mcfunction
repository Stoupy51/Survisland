
#> survirec:v1.3.2/api/kill
#
# @within	#survirec:v1/kill
#
# @args		with (unknown)
#

# Only the newest survirec loaded in the world runs the call
execute unless score #survirec.loaded load.status matches 1 run return fail
execute unless score #survirec.major load.status matches 1 run return fail
execute unless score #survirec.minor load.status matches 3 run return fail
execute unless score #survirec.patch load.status matches 2 run return fail

$data modify storage survirec:call arguments set value $(with)
data modify storage survirec:call options set value {}
data modify storage survirec:call options merge from storage survirec:call arguments
scoreboard players set #has_bad_name survirec.data 0
execute if data storage survirec:call options.tag run data modify storage survirec:name_check request set value {field:"tag"}
execute if data storage survirec:call options.tag run function survirec:v1.3.2/name/check_required with storage survirec:name_check request
execute if data storage survirec:call options.name run data modify storage survirec:name_check request set value {field:"name"}
execute if data storage survirec:call options.name run function survirec:v1.3.2/name/check_required with storage survirec:name_check request
execute if score #has_bad_name survirec.data matches 1 run return run function survirec:v1.3.2/name/report_invalid
execute if data storage survirec:call options.tag run return run function survirec:v1.3.2/kill/by_tag with storage survirec:call options
execute if data storage survirec:call options.name run return run function survirec:v1.3.2/kill/by_name with storage survirec:call options
tellraw @s [{text:"🎥 "},{text:"kill demande un filtre (tag ou name). Pour tout supprimer : ",color:"red"},{text:"#survirec:v1/kill_all",color:"gold",bold:true}]

