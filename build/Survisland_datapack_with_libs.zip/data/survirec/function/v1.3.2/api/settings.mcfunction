
#> survirec:v1.3.2/api/settings
#
# @within	#survirec:v1/settings
#
# @args		with (unknown)
#

# Only the newest survirec loaded in the world runs the call
execute unless score #survirec.loaded load.status matches 1 run return fail
execute unless score #survirec.major load.status matches 1 run return fail
execute unless score #survirec.minor load.status matches 3 run return fail
execute unless score #survirec.patch load.status matches 2 run return fail

$data modify storage survirec:call arguments set value $(with)
data modify storage survirec:call options set value {range:128,move_every:2}
data modify storage survirec:call options.range set from storage survirec:config range
execute store result storage survirec:call options.move_every int 1 run scoreboard players get #move_every survirec.data
data modify storage survirec:call options merge from storage survirec:call arguments
data modify storage survirec:config range set from storage survirec:call options.range
execute store result score #move_every survirec.data run data get storage survirec:call options.move_every
execute unless score #move_every survirec.data matches 1..20 run scoreboard players set #move_every survirec.data 2
tellraw @s [{text:"🎥 "},{text:"Portée : ",color:"green"},{storage:"survirec:config",nbt:"range",color:"gold"},{text:" blocs · position mise à jour tous les ",color:"green"},{score:{name:"#move_every",objective:"survirec.data"},color:"gold"},{text:" ticks",color:"green"}]

