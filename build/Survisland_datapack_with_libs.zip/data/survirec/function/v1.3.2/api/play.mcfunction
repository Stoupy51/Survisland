
#> survirec:v1.3.2/api/play
#
# @within	#survirec:v1/play
#
# @args		with (unknown)
#

# Only the newest survirec loaded in the world runs the call
execute unless score #survirec.loaded load.status matches 1 run return fail
execute unless score #survirec.major load.status matches 1 run return fail
execute unless score #survirec.minor load.status matches 3 run return fail
execute unless score #survirec.patch load.status matches 2 run return fail

$data modify storage survirec:call arguments set value $(with)
data modify storage survirec:call options set value {name:"",pos:"~ ~ ~",entity:"minecraft:mannequin",nbt:{},range:0,size:1,loop:1,redstone:0,restore:1,hit_players:0,speed:100,delay:0,tag:"",group:"",group_radius:50,pose:"",skin:"",texture:"",head:"",chest:"",legs:"",feet:"",mainhand:"",offhand:"",group_id:0,group_loop:0}
data modify storage survirec:call options merge from storage survirec:call arguments
scoreboard players set #has_bad_name survirec.data 0
data modify storage survirec:name_check request set value {field:"name"}
function survirec:v1.3.2/name/check_required with storage survirec:name_check request
data modify storage survirec:name_check request set value {field:"tag"}
function survirec:v1.3.2/name/check_optional with storage survirec:name_check request
data modify storage survirec:name_check request set value {field:"group"}
function survirec:v1.3.2/name/check_optional with storage survirec:name_check request
execute if score #has_bad_name survirec.data matches 1 run return run function survirec:v1.3.2/name/report_invalid
execute if data storage survirec:call options.data run function survirec:v1.3.2/sequence/import
execute unless data storage survirec:call options{group:""} run function survirec:v1.3.2/group/prepare_local
execute summon minecraft:marker run function survirec:v1.3.2/spawn/store_command_block_position
function survirec:v1.3.2/spawn/from_options with storage survirec:call options

