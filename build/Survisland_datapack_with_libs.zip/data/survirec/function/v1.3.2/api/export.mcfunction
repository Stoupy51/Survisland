
#> survirec:v1.3.2/api/export
#
# @within	#survirec:v1/export
#
# @args		with (unknown)
#

# Only the newest survirec loaded in the world runs the call
execute unless score #survirec.loaded load.status matches 1 run return fail
execute unless score #survirec.major load.status matches 1 run return fail
execute unless score #survirec.minor load.status matches 3 run return fail
execute unless score #survirec.patch load.status matches 2 run return fail

$data modify storage survirec:call arguments set value $(with)
data modify storage survirec:call options set value {name:""}
data modify storage survirec:call options merge from storage survirec:call arguments
scoreboard players set #has_bad_name survirec.data 0
data modify storage survirec:name_check request set value {field:"name"}
function survirec:v1.3.2/name/check_required with storage survirec:name_check request
execute if score #has_bad_name survirec.data matches 1 run return run function survirec:v1.3.2/name/report_invalid

function survirec:v1.3.2/record/export_saved with storage survirec:call options

