
#> survirec:v1.3.2/api/part
#
# @within	#survirec:v1/part
#
# @args		with (unknown)
#

# Only the newest survirec loaded in the world runs the call
execute unless score #survirec.loaded load.status matches 1 run return fail
execute unless score #survirec.major load.status matches 1 run return fail
execute unless score #survirec.minor load.status matches 3 run return fail
execute unless score #survirec.patch load.status matches 2 run return fail

$data modify storage survirec:call arguments set value $(with)
data modify storage survirec:call part set value {f:0,d:[],e:[],s:[],a:[]}
data modify storage survirec:call part merge from storage survirec:call arguments
function survirec:v1.3.2/sequence/collect_part

