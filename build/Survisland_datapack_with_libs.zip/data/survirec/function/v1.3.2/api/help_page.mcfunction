
#> survirec:v1.3.2/api/help_page
#
# @within	#survirec:v1/help_page
#
# @args		with (unknown)
#

# Only the newest survirec loaded in the world runs the call
execute unless score #survirec.loaded load.status matches 1 run return fail
execute unless score #survirec.major load.status matches 1 run return fail
execute unless score #survirec.minor load.status matches 3 run return fail
execute unless score #survirec.patch load.status matches 2 run return fail

$data modify storage survirec:call arguments set value $(with)
data modify storage survirec:call options set value {page:1}
data modify storage survirec:call options merge from storage survirec:call arguments
execute store result score #page survirec.data run data get storage survirec:call options.page
execute unless score #page survirec.data matches 1..5 run return run function survirec:v1.3.2/help/open_index
execute store result storage survirec:call options.page int 1 run scoreboard players get #page survirec.data
function survirec:v1.3.2/help/open_page with storage survirec:call options

