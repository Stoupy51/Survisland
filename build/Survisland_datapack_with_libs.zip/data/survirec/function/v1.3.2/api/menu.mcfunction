
#> survirec:v1.3.2/api/menu
#
# @within	#survirec:v1/menu
#

# Only the newest survirec loaded in the world runs the call
execute unless score #survirec.loaded load.status matches 1 run return fail
execute unless score #survirec.major load.status matches 1 run return fail
execute unless score #survirec.minor load.status matches 3 run return fail
execute unless score #survirec.patch load.status matches 2 run return fail

execute unless entity @s[type=minecraft:player] run return fail
dialog show @s survirec:menu

