
#> survirec:v1.3.2/challenge/launch
#
# @executed	as @a[tag=survirec.armed]
#
# @within	survirec:v1.3.2/playback/finish_walk_back [ as @a[tag=survirec.armed] ]
#			survirec:v1.3.2/challenge/arm
#			survirec:v1.3.2/challenge/check_armed
#			survirec:v1.3.2/challenge/start
#

execute if score @s survirec.armed_kind matches 1 run return run function survirec:v1.3.2/record/launch_armed
tag @s remove survirec.armed
title @s actionbar {text:""}
data modify storage survirec:recording meta set value {name:"ch",keyframe_step:4}
function survirec:v1.3.2/challenge/begin
scoreboard players operation #challenge_seconds survirec.data = @s survirec.challenge_ticks
scoreboard players operation #challenge_seconds survirec.data /= #20 survirec.data
tellraw @s [{text:"🎥 "},{text:"Épreuve ! Tu as ",color:"green"},{score:{name:"#challenge_seconds",objective:"survirec.data"},color:"gold",bold:true},{text:" secondes.",color:"green"}]

