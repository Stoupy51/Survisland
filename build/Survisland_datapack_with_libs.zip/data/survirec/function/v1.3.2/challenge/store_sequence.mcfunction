
#> survirec:v1.3.2/challenge/store_sequence
#
# @executed	at @s
#
# @within	survirec:v1.3.2/challenge/end with storage survirec:challenge
#
# @args		id (unknown)
#			player_id (unknown)
#

$data modify storage survirec:data seqs.ch_$(id)_$(player_id) set from storage survirec:recording sequence

