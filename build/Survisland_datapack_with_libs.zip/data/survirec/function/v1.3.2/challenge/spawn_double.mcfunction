
#> survirec:v1.3.2/challenge/spawn_double
#
# @executed	at @s
#
# @within	survirec:v1.3.2/challenge/end with storage survirec:challenge
#
# @args		id (unknown)
#			player_id (unknown)
#			group_id (unknown)
#

$data modify storage survirec:call spawn set value {name:"ch_$(id)_$(player_id)",entity:"minecraft:mannequin",range:0,size:1,loop:0,group_id:$(group_id),speed:100,delay:0,tag:"sv_$(id)_$(player_id)",pose:"",skin:"",texture:"",head:"",chest:"",legs:"",feet:"",mainhand:"",offhand:""}
function survirec:v1.3.2/challenge/spawn_at_start with storage survirec:recording meta

