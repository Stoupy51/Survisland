
#> survirec:v1.3.2/challenge/start
#
# @within	survirec:v1.3.2/challenge/start_from_call
#

execute unless entity @s[type=minecraft:player] run return fail
# a pressure plate fires again and again: ignored without a message
execute if entity @s[tag=survirec.recording] run return 0
execute if entity @s[tag=survirec.armed] run return 0
data modify storage survirec:challenge id set from storage survirec:challenge_call id
data modify storage survirec:challenge time set from storage survirec:challenge_call time
data modify storage survirec:challenge group set from storage survirec:challenge_call group
data modify storage survirec:challenge sync set from storage survirec:challenge_call sync
data modify storage survirec:challenge tp_back set from storage survirec:challenge_call tp_back
execute store result score @s survirec.challenge_ticks run data get storage survirec:challenge time 20
execute unless score @s survirec.challenge_ticks matches 20.. run return run tellraw @s [{text:"🎥 "},{text:"time doit être d'au moins 1 seconde.",color:"red"}]
execute unless score @s survirec.player_id matches 1.. run function survirec:v1.3.2/player/new_id
execute store result storage survirec:challenge player_id int 1 run scoreboard players get @s survirec.player_id
function survirec:v1.3.2/challenge/resolve_group with storage survirec:challenge
execute store result storage survirec:challenge group_id int 1 run scoreboard players get #group survirec.data
function survirec:v1.3.2/challenge/kill_previous_double with storage survirec:challenge
function survirec:v1.3.2/group/check
function survirec:v1.3.2/record/store_player_id
function survirec:v1.3.2/challenge/save_settings with storage survirec:recorder
scoreboard players set @s survirec.armed_kind 0
execute store result score #is_synced survirec.data run data get storage survirec:challenge sync
execute if score #is_synced survirec.data matches 1 run return run function survirec:v1.3.2/challenge/arm
function survirec:v1.3.2/challenge/launch

