
#> survirec:v1.3.2/challenge/save_settings
#
# @within	survirec:v1.3.2/challenge/start with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data modify storage survirec:in_progress players.p$(player_id).challenge set from storage survirec:challenge

