
#> survirec:v1.3.2/challenge/new_group_id
#
# @within	survirec:v1.3.2/challenge/resolve_group with storage survirec:challenge
#
# @args		player_id (unknown)
#			group (unknown)
#

scoreboard players add #next_group_id survirec.data 1
$execute store result storage survirec:challenge_groups ids.p$(player_id)_$(group) int 1 run scoreboard players get #next_group_id survirec.data

