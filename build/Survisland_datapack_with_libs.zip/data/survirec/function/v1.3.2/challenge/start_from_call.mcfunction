
#> survirec:v1.3.2/challenge/start_from_call
#
# @within	survirec:v1.3.2/api/challenge with storage survirec:call options
#
# @args		id (unknown)
#			time (unknown)
#			group (unknown)
#			sync (unknown)
#			tp_back (unknown)
#

$data merge storage survirec:challenge_call {id:"$(id)",time:$(time),group:"$(group)",sync:$(sync),tp_back:$(tp_back)}
function survirec:v1.3.2/challenge/start

