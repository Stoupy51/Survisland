
#> survirec:v1.3.2/challenge/teleport_back
#
# @executed	at @s
#
# @within	survirec:v1.3.2/challenge/end
#

execute store result storage survirec:recording start_point.x double 0.001 run scoreboard players get @s survirec.record_start_x
execute store result storage survirec:recording start_point.y double 0.001 run scoreboard players get @s survirec.record_start_y
execute store result storage survirec:recording start_point.z double 0.001 run scoreboard players get @s survirec.record_start_z
execute store result storage survirec:recording start_point.yaw double 0.01 run scoreboard players get @s survirec.record_start_yaw
execute store result storage survirec:recording start_point.pitch double 0.01 run scoreboard players get @s survirec.record_start_pitch
function survirec:v1.3.2/playback/teleport with storage survirec:recording start_point

