
#> survirec:v1.3.2/challenge/show_hud
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/show_hud
#

scoreboard players operation #seconds survirec.data = @s survirec.challenge_ticks
scoreboard players operation #seconds survirec.data -= @s survirec.record_tick
scoreboard players add #seconds survirec.data 19
scoreboard players operation #seconds survirec.data /= #20 survirec.data
scoreboard players operation #minutes survirec.data = #seconds survirec.data
scoreboard players operation #minutes survirec.data /= #60 survirec.data
scoreboard players operation #seconds survirec.data %= #60 survirec.data
execute if score #seconds survirec.data matches 10.. run title @s actionbar [{text:"● ",color:"red"},{text:"ENREGISTREMENT  ",color:"white",bold:true},{text:"Temps restant : ",color:"gray"},{score:{name:"#minutes",objective:"survirec.data"},color:"gold",bold:true},{text:":",color:"gold",bold:true},{score:{name:"#seconds",objective:"survirec.data"},color:"gold",bold:true}]
execute if score #seconds survirec.data matches ..9 run title @s actionbar [{text:"● ",color:"red"},{text:"ENREGISTREMENT  ",color:"white",bold:true},{text:"Temps restant : ",color:"gray"},{score:{name:"#minutes",objective:"survirec.data"},color:"gold",bold:true},{text:":0",color:"gold",bold:true},{score:{name:"#seconds",objective:"survirec.data"},color:"gold",bold:true}]

