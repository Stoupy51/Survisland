
#> survirec:v1.3.2/challenge/begin
#
# @executed	as @a[tag=survirec.armed]
#
# @within	survirec:v1.3.2/challenge/launch
#

function survirec:v1.3.2/record/init
scoreboard players set @s survirec.is_challenge 1
function #survirec:v1/signals/on_record_start

