
#> survirec:v1.3.2/challenge/resolve_group
#
# @within	survirec:v1.3.2/challenge/start with storage survirec:challenge
#
# @args		player_id (unknown)
#			group (unknown)
#

# one group id per player and group name
$execute unless data storage survirec:challenge_groups ids.p$(player_id)_$(group) run function survirec:v1.3.2/challenge/new_group_id with storage survirec:challenge
$execute store result score #group survirec.data run data get storage survirec:challenge_groups ids.p$(player_id)_$(group)

