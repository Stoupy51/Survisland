
#> survirec:v1.3.2/challenge/check_armed
#
# @executed	as @a[tag=survirec.armed]
#
# @within	survirec:v1.3.2/tick [ as @a[tag=survirec.armed] ]
#

title @s actionbar [{text:"⏳ ",color:"gold"},{text:"EN ATTENTE DU PROCHAIN CYCLE ",color:"white",bold:true},{text:"du groupe",color:"gray"}]
scoreboard players operation #waited_group survirec.data = @s survirec.waited_group
scoreboard players set #group_alive survirec.data 0
execute as @e[tag=survirec.instance] if score @s survirec.group_id = #waited_group survirec.data run scoreboard players set #group_alive survirec.data 1
execute if score #group_alive survirec.data matches 0 run function survirec:v1.3.2/challenge/launch

