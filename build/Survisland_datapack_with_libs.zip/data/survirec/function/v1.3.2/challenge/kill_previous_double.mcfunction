
#> survirec:v1.3.2/challenge/kill_previous_double
#
# @within	survirec:v1.3.2/challenge/start with storage survirec:challenge
#
# @args		id (unknown)
#			player_id (unknown)
#

scoreboard players set #restore_on_kill survirec.data 1
$execute as @e[tag=survirec.tag.sv_$(id)_$(player_id)] run function survirec:v1.3.2/playback/delete
scoreboard players set #restore_on_kill survirec.data 0

