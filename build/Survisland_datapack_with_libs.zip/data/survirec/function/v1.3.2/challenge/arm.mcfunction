
#> survirec:v1.3.2/challenge/arm
#
# @within	survirec:v1.3.2/challenge/start
#

execute store result score @s survirec.waited_group run data get storage survirec:challenge group_id
scoreboard players operation #waited_group survirec.data = @s survirec.waited_group
scoreboard players set #group_alive survirec.data 0
execute as @e[tag=survirec.instance] if score @s survirec.group_id = #waited_group survirec.data run scoreboard players set #group_alive survirec.data 1
execute if score #group_alive survirec.data matches 0 run return run function survirec:v1.3.2/challenge/launch
tag @s add survirec.armed
tellraw @s [{text:"🎥 "},{text:"Enregistrement armé : il démarre au prochain cycle du groupe.",color:"green"}]

