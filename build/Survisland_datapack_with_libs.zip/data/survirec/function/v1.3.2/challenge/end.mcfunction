
#> survirec:v1.3.2/challenge/end
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/tick
#

tag @s remove survirec.recording
scoreboard players set @s survirec.is_challenge 0
function survirec:v1.3.2/record/restore_world
function survirec:v1.3.2/record/pull_state
function survirec:v1.3.2/record/drop_state with storage survirec:recorder
title @s actionbar {text:""}
scoreboard players operation #player_id survirec.data = @s survirec.player_id
function survirec:v1.3.2/record/kill_markers
data modify storage survirec:recording keyframes set value []
data modify storage survirec:recording keyframes append from storage survirec:recording chunks[][]
data modify storage survirec:recording keyframes append from storage survirec:recording d[]
data modify storage survirec:recording sequence set value {}
data modify storage survirec:recording sequence.n set from storage survirec:recording meta.keyframe_step
data modify storage survirec:recording sequence.y set from storage survirec:recording meta.yaw
data modify storage survirec:recording sequence.p set from storage survirec:recording meta.pitch
data modify storage survirec:recording sequence.e set from storage survirec:recording e
data modify storage survirec:recording sequence.s set from storage survirec:recording s
data modify storage survirec:recording sequence.a set from storage survirec:recording a
data modify storage survirec:recording sequence.d set from storage survirec:recording keyframes
function survirec:v1.3.2/challenge/store_sequence with storage survirec:challenge
data modify storage survirec:call profile set value {}
data modify storage survirec:call profile.id set from entity @s UUID
scoreboard players set #group_alive survirec.data 0
function survirec:v1.3.2/challenge/spawn_double with storage survirec:challenge
execute if score #group_alive survirec.data matches 1 run tellraw @s [{text:"🎥 "},{text:"Terminé ! Ton double démarrera quand les autres auront fini leur cycle.",color:"green"}]
execute unless score #group_alive survirec.data matches 1 run tellraw @s [{text:"🎥 "},{text:"Terminé ! Ton double rejoue ton parcours en boucle. ",color:"green"},{text:"Recommence en réactivant l'épreuve.",color:"gold"}]
execute store result score #teleport_back survirec.data run data get storage survirec:challenge tp_back
execute if score #teleport_back survirec.data matches 1 run function survirec:v1.3.2/challenge/teleport_back
function #survirec:v1/signals/on_record_stop

