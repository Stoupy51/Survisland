
#> survirec:v1.3.2/challenge/spawn_at_start
#
# @executed	at @s
#
# @within	survirec:v1.3.2/challenge/spawn_double with storage survirec:recording meta
#
# @args		start_x (unknown)
#			start_y (unknown)
#			start_z (unknown)
#

$execute positioned $(start_x) $(start_y) $(start_z) run function survirec:v1.3.2/spawn/summon

