
#> survirec:v1.3.2/sequence/collect_part
#
# @within	survirec:v1.3.2/api/part
#			survirec:v1.3.2/sequence/import
#

# survirec:call part = {f,d,e,s,a}, f:1 on the first part of the chain
execute if data storage survirec:call part{f:1} run data modify storage survirec:import keyframes set value []
execute if data storage survirec:call part{f:1} run data modify storage survirec:import equipment set value []
execute if data storage survirec:call part{f:1} run data modify storage survirec:import swings set value []
execute if data storage survirec:call part{f:1} run data modify storage survirec:import actions set value []
execute unless data storage survirec:import keyframes run data modify storage survirec:import keyframes set value []
execute unless data storage survirec:import equipment run data modify storage survirec:import equipment set value []
execute unless data storage survirec:import swings run data modify storage survirec:import swings set value []
execute unless data storage survirec:import actions run data modify storage survirec:import actions set value []
data modify storage survirec:import keyframes append from storage survirec:call part.d[]
data modify storage survirec:import equipment append from storage survirec:call part.e[]
data modify storage survirec:import swings append from storage survirec:call part.s[]
data modify storage survirec:import actions append from storage survirec:call part.a[]

