
#> survirec:v1.3.2/sequence/store
#
# @within	survirec:v1.3.2/sequence/import with storage survirec:call options
#
# @args		name (unknown)
#

$data modify storage survirec:data seqs.$(name) set from storage survirec:call sequence

