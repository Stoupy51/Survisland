
#> survirec:v1.3.2/sequence/forget
#
# @within	survirec:v1.3.2/api/forget with storage survirec:call options
#
# @args		name (unknown)
#

$data remove storage survirec:data seqs.$(name)
$data remove storage survirec:library recordings.$(name)
$data remove storage survirec:library names[{name:"$(name)"}]
$tellraw @s [{text:"🎥 "},{text:"Séquence ",color:"green"},{text:"$(name)",color:"gold"},{text:" supprimée.",color:"green"}]

