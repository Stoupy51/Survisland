
#> survirec:v1.3.2/sequence/import
#
# @within	survirec:v1.3.2/api/play
#

data modify storage survirec:call part set from storage survirec:call options.data
function survirec:v1.3.2/sequence/collect_part
data modify storage survirec:call sequence set value {}
data modify storage survirec:call sequence.n set from storage survirec:call options.data.n
data modify storage survirec:call sequence.y set from storage survirec:call options.data.y
data modify storage survirec:call sequence.p set from storage survirec:call options.data.p
data modify storage survirec:call sequence.d set from storage survirec:import keyframes
data modify storage survirec:call sequence.e set from storage survirec:import equipment
data modify storage survirec:call sequence.s set from storage survirec:import swings
data modify storage survirec:call sequence.a set from storage survirec:import actions
function survirec:v1.3.2/sequence/store with storage survirec:call options
data remove storage survirec:import keyframes
data remove storage survirec:import equipment
data remove storage survirec:import swings
data remove storage survirec:import actions

