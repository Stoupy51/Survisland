
#> survirec:v1.3.2/release/store_position
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/use/press_button
#

execute store result storage survirec:playback release.x int 1 run data get entity @s Pos[0]
execute store result storage survirec:playback release.y int 1 run data get entity @s Pos[1]
execute store result storage survirec:playback release.z int 1 run data get entity @s Pos[2]
kill @s

