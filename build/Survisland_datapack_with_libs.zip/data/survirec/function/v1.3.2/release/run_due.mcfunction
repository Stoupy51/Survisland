
#> survirec:v1.3.2/release/run_due
#
# @within	survirec:v1.3.2/release/run_all
#			survirec:v1.3.2/playback/tick
#

execute store result storage survirec:playback instance_id int 1 run scoreboard players get @s survirec.instance_id
function survirec:v1.3.2/release/pull_list with storage survirec:playback
scoreboard players set @s survirec.next_release_tick -1
execute if data storage survirec:playback due_releases[0] at @s run function survirec:v1.3.2/release/check_next

