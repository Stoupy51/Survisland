
#> survirec:v1.3.2/release/add_to_instance
#
# @executed	at @s
#
# @within	survirec:v1.3.2/release/add with storage survirec:playback release
#
# @args		instance_id (unknown)
#			tick (unknown)
#			x (unknown)
#			y (unknown)
#			z (unknown)
#			block (unknown)
#			support_x (unknown)
#			support_y (unknown)
#			support_z (unknown)
#

$data modify storage survirec:instances i$(instance_id).releases append value {tick:$(tick),x:$(x),y:$(y),z:$(z),block:"$(block)",support_x:$(support_x),support_y:$(support_y),support_z:$(support_z)}

