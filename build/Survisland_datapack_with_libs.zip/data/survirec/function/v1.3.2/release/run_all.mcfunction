
#> survirec:v1.3.2/release/run_all
#
# @within	survirec:v1.3.2/playback/delete
#

scoreboard players set #release_all survirec.data 1
function survirec:v1.3.2/release/run_due
scoreboard players set #release_all survirec.data 0

