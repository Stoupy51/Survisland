
#> survirec:v1.3.2/release/add
#
# @executed	at @s
#
# @within	survirec:v1.3.2/release/keep
#			survirec:v1.3.2/use/press_button
#

execute store result storage survirec:playback release.instance_id int 1 run scoreboard players get @s survirec.instance_id
function survirec:v1.3.2/release/add_to_instance with storage survirec:playback release
execute if score @s survirec.next_release_tick matches -1 run scoreboard players operation @s survirec.next_release_tick = #release_tick survirec.data
execute if score #release_tick survirec.data < @s survirec.next_release_tick run scoreboard players operation @s survirec.next_release_tick = #release_tick survirec.data

