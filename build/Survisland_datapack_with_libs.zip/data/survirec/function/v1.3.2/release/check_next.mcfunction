
#> survirec:v1.3.2/release/check_next
#
# @executed	at @s
#
# @within	survirec:v1.3.2/release/run_due [ at @s ]
#			survirec:v1.3.2/release/check_next
#

execute store result score #release_tick survirec.data run data get storage survirec:playback due_releases[0].tick
execute if score #release_all survirec.data matches 1 run scoreboard players set #release_tick survirec.data -1
execute if score #release_tick survirec.data <= #game_time survirec.data run function survirec:v1.3.2/release/release_button with storage survirec:playback due_releases[0]
execute if score #release_tick survirec.data > #game_time survirec.data run function survirec:v1.3.2/release/keep
data remove storage survirec:playback due_releases[0]
execute if data storage survirec:playback due_releases[0] run function survirec:v1.3.2/release/check_next

