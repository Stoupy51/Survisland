
#> survirec:v1.3.2/release/pull_list
#
# @within	survirec:v1.3.2/release/run_due with storage survirec:playback
#
# @args		instance_id (unknown)
#

data modify storage survirec:playback due_releases set value []
$data modify storage survirec:playback due_releases set from storage survirec:instances i$(instance_id).releases
$data modify storage survirec:instances i$(instance_id).releases set value []

