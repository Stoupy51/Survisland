
#> survirec:v1.3.2/release/keep
#
# @executed	at @s
#
# @within	survirec:v1.3.2/release/check_next
#

data modify storage survirec:playback release set from storage survirec:playback due_releases[0]
function survirec:v1.3.2/release/add

