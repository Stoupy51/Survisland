
#> survirec:v1.3.2/release/release_button
#
# @executed	at @s
#
# @within	survirec:v1.3.2/release/check_next with storage survirec:playback due_releases[0]
#
# @args		x (unknown)
#			y (unknown)
#			z (unknown)
#			block (unknown)
#			support_x (unknown)
#			support_y (unknown)
#			support_z (unknown)
#

$setblock $(x) $(y) $(z) $(block)
$execute positioned $(support_x) $(support_y) $(support_z) run function survirec:v1.3.2/block/update_support
$playsound minecraft:block.stone_button.click_off block @a[distance=..24] $(x) $(y) $(z)

