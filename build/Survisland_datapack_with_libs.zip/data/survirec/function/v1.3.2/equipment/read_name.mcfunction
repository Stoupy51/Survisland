
#> survirec:v1.3.2/equipment/read_name
#
# @within	survirec:v1.3.2/equipment/load_next with storage survirec:playback
#
# @args		instance_id (unknown)
#

$data modify storage survirec:playback name set from storage survirec:instances i$(instance_id).name
function survirec:v1.3.2/equipment/apply with storage survirec:playback

