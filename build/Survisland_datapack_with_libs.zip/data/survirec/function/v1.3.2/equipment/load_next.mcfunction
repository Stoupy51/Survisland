
#> survirec:v1.3.2/equipment/load_next
#
# @within	survirec:v1.3.2/equipment/load_next
#			survirec:v1.3.2/playback/load_keyframe
#

execute store result storage survirec:playback instance_id int 1 run scoreboard players get @s survirec.instance_id
execute store result storage survirec:playback equipment_index int 1 run scoreboard players get @s survirec.equipment_index
scoreboard players add @s survirec.equipment_index 1
execute store result storage survirec:playback next_equipment_index int 1 run scoreboard players get @s survirec.equipment_index
scoreboard players set @s survirec.next_equipment_keyframe 999999999
function survirec:v1.3.2/equipment/read_name with storage survirec:playback
execute if score @s survirec.keyframe_index >= @s survirec.next_equipment_keyframe run function survirec:v1.3.2/equipment/load_next

