
#> survirec:v1.3.2/equipment/apply
#
# @within	survirec:v1.3.2/equipment/read_name with storage survirec:playback
#
# @args		name (unknown)
#			equipment_index (unknown)
#			next_equipment_index (unknown)
#

$data modify entity @s equipment set from storage survirec:data seqs.$(name).e[$(equipment_index)].v
$execute if data storage survirec:data seqs.$(name).e[$(next_equipment_index)] store result score @s survirec.next_equipment_keyframe run data get storage survirec:data seqs.$(name).e[$(next_equipment_index)].k

