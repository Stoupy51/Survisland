
#> survirec:v1.3.2/kill/by_tag
#
# @within	survirec:v1.3.2/api/kill with storage survirec:call options
#			survirec:v1.3.2/spawn/summon with storage survirec:call spawn
#
# @args		tag (unknown)
#

scoreboard players set #restore_on_kill survirec.data 1
$execute as @e[tag=survirec.tag.$(tag)] run function survirec:v1.3.2/playback/delete
scoreboard players set #restore_on_kill survirec.data 0

