
#> survirec:v1.3.2/kill/all
#
# @within	survirec:v1.3.2/api/kill_all
#

scoreboard players set #restore_on_kill survirec.data 1
execute as @e[tag=survirec.entity] run function survirec:v1.3.2/playback/delete
scoreboard players set #restore_on_kill survirec.data 0
execute if data storage survirec:config are_blocks_ready in survirec:vault if loaded 0 0 0 run function survirec:v1.3.2/vault/wipe

