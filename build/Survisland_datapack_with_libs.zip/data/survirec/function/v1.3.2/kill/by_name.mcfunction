
#> survirec:v1.3.2/kill/by_name
#
# @within	survirec:v1.3.2/api/kill with storage survirec:call options
#
# @args		name (unknown)
#

scoreboard players set #restore_on_kill survirec.data 1
$execute as @e[tag=survirec.sequence.$(name)] run function survirec:v1.3.2/playback/delete
scoreboard players set #restore_on_kill survirec.data 0

