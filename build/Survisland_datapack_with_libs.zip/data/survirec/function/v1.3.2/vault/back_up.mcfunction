
#> survirec:v1.3.2/vault/back_up
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/vault/back_up_here
#

# as the entity, at the block; survirec:playback block_copy = {x,y,z,mode}, mode: "strict" or "replace" when it is put back
# only the first copy of a block is kept: it is the original state, restored at every loop
execute unless score @s survirec.restore_mode matches 1.. run return 0
execute unless data storage survirec:config are_blocks_ready run return 0
execute store result storage survirec:playback block_copy.instance_id int 1 run scoreboard players get @s survirec.instance_id
scoreboard players set #has_copy survirec.data 0
function survirec:v1.3.2/vault/has_copy with storage survirec:playback block_copy
execute if score #has_copy survirec.data matches 1 run return 0
execute if data storage survirec:config free_block_slots[0] run return run function survirec:v1.3.2/vault/reuse_slot
scoreboard players operation #slot_index survirec.data = #next_block_slot survirec.data
scoreboard players operation #slot_index survirec.data %= #7 survirec.data
scoreboard players operation #slot_index survirec.data *= #2 survirec.data
execute store result storage survirec:playback block_copy.vault_x int 1 run scoreboard players add #slot_index survirec.data 1
scoreboard players operation #slot_index survirec.data = #next_block_slot survirec.data
scoreboard players operation #slot_index survirec.data /= #7 survirec.data
scoreboard players operation #slot_index survirec.data %= #7 survirec.data
scoreboard players operation #slot_index survirec.data *= #2 survirec.data
execute store result storage survirec:playback block_copy.vault_z int 1 run scoreboard players add #slot_index survirec.data 1
scoreboard players operation #slot_index survirec.data = #next_block_slot survirec.data
scoreboard players operation #slot_index survirec.data /= #49 survirec.data
scoreboard players operation #slot_index survirec.data *= #2 survirec.data
execute store result storage survirec:playback block_copy.vault_y int 1 run scoreboard players remove #slot_index survirec.data 63
scoreboard players add #next_block_slot survirec.data 1
execute if score #next_block_slot survirec.data matches 9359.. run scoreboard players set #next_block_slot survirec.data 0
function survirec:v1.3.2/vault/copy_block with storage survirec:playback block_copy

