
#> survirec:v1.3.2/vault/free_slot
#
# @within	survirec:v1.3.2/vault/free_next with storage survirec:playback block_copies[-1]
#
# @args		vault_x (unknown)
#			vault_y (unknown)
#			vault_z (unknown)
#

$execute in survirec:vault run setblock $(vault_x) $(vault_y) $(vault_z) minecraft:barrier strict
$data modify storage survirec:config free_block_slots append value {vault_x:$(vault_x),vault_y:$(vault_y),vault_z:$(vault_z)}

