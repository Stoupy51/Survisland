
#> survirec:v1.3.2/vault/prepare_blocks
#
# @executed	in survirec:vault
#
# @within	survirec:v1.3.2/vault/try_prepare [ in survirec:vault ]
#

execute in survirec:vault run fill 0 -64 0 15 31 15 minecraft:barrier strict
execute in survirec:vault run fill 0 32 0 15 127 15 minecraft:barrier strict
execute in survirec:vault run fill 0 128 0 15 223 15 minecraft:barrier strict
execute in survirec:vault run fill 0 224 0 15 319 15 minecraft:barrier strict
data modify storage survirec:config are_blocks_ready set value 1b

