
#> survirec:v1.3.2/vault/free_next
#
# @within	survirec:v1.3.2/vault/free
#			survirec:v1.3.2/vault/free_next
#

function survirec:v1.3.2/vault/free_slot with storage survirec:playback block_copies[-1]
data remove storage survirec:playback block_copies[-1]
execute if data storage survirec:playback block_copies[0] run function survirec:v1.3.2/vault/free_next

