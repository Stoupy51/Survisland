
#> survirec:v1.3.2/vault/store_position
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/vault/back_up_here
#

execute store result storage survirec:playback block_copy.x int 1 run data get entity @s Pos[0]
execute store result storage survirec:playback block_copy.y int 1 run data get entity @s Pos[1]
execute store result storage survirec:playback block_copy.z int 1 run data get entity @s Pos[2]
kill @s

