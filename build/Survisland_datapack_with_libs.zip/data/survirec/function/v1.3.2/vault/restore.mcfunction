
#> survirec:v1.3.2/vault/restore
#
# @within	survirec:v1.3.2/playback/delete
#			survirec:v1.3.2/playback/freeze
#			survirec:v1.3.2/group/mark_if_finished [ as @e[tag=survirec.instance] ]
#			survirec:v1.3.2/group/walk_back
#			survirec:v1.3.2/playback/restart
#

# blocks changed by this entity, put back in reverse order
execute store result storage survirec:playback instance_id int 1 run scoreboard players get @s survirec.instance_id
function survirec:v1.3.2/vault/pull_copies with storage survirec:playback
execute if data storage survirec:playback block_copies[0] at @s run function survirec:v1.3.2/vault/restore_next

