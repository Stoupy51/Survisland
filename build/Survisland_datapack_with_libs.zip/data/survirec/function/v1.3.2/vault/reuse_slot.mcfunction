
#> survirec:v1.3.2/vault/reuse_slot
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/vault/back_up
#

data modify storage survirec:playback block_copy.vault_x set from storage survirec:config free_block_slots[-1].vault_x
data modify storage survirec:playback block_copy.vault_y set from storage survirec:config free_block_slots[-1].vault_y
data modify storage survirec:playback block_copy.vault_z set from storage survirec:config free_block_slots[-1].vault_z
data remove storage survirec:config free_block_slots[-1]
function survirec:v1.3.2/vault/copy_block with storage survirec:playback block_copy

