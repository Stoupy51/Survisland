
#> survirec:v1.3.2/vault/back_up_here
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/back_up_other_half_at
#			survirec:v1.3.2/action/break_block
#			survirec:v1.3.2/action/place_block
#			survirec:v1.3.2/action/place_other_half_at
#			survirec:v1.3.2/use/press_button
#			survirec:v1.3.2/use/toggle_door
#			survirec:v1.3.2/use/toggle_door_half
#			survirec:v1.3.2/use/toggle_lever
#			survirec:v1.3.2/use/toggle_open
#

# #restore_strict 1: put back without block updates (both halves of a door or bed)
data modify storage survirec:playback block_copy set value {x:0,y:0,z:0,mode:"replace"}
execute if score #restore_strict survirec.data matches 1 run data modify storage survirec:playback block_copy.mode set value "strict"
execute summon minecraft:marker run function survirec:v1.3.2/vault/store_position
function survirec:v1.3.2/vault/back_up

