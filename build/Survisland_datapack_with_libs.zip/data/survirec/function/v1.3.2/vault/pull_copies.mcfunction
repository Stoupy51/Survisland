
#> survirec:v1.3.2/vault/pull_copies
#
# @within	survirec:v1.3.2/vault/free with storage survirec:playback
#			survirec:v1.3.2/vault/restore with storage survirec:playback
#
# @args		instance_id (unknown)
#

data modify storage survirec:playback block_copies set value []
$data modify storage survirec:playback block_copies set from storage survirec:instances i$(instance_id).block_copies

