
#> survirec:v1.3.2/vault/wipe
#
# @executed	in survirec:vault
#
# @within	survirec:v1.3.2/kill/all [ in survirec:vault ]
#

execute in survirec:vault run fill 0 -64 0 15 31 15 minecraft:barrier strict
execute in survirec:vault run fill 0 32 0 15 127 15 minecraft:barrier strict
execute in survirec:vault run fill 0 128 0 15 223 15 minecraft:barrier strict
execute in survirec:vault run fill 0 224 0 15 319 15 minecraft:barrier strict
data modify storage survirec:config free_block_slots set value []
scoreboard players set #next_block_slot survirec.data 0

