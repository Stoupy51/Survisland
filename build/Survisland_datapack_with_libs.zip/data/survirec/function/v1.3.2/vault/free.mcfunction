
#> survirec:v1.3.2/vault/free
#
# @within	survirec:v1.3.2/playback/delete
#

# the entity is removed: its slots become barriers again, free for the next copies
execute store result storage survirec:playback instance_id int 1 run scoreboard players get @s survirec.instance_id
function survirec:v1.3.2/vault/pull_copies with storage survirec:playback
execute if data storage survirec:playback block_copies[0] run function survirec:v1.3.2/vault/free_next

