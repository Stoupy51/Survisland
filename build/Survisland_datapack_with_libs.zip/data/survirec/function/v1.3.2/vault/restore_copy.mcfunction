
#> survirec:v1.3.2/vault/restore_copy
#
# @executed	at @s
#
# @within	survirec:v1.3.2/vault/restore_next with storage survirec:playback block_copies[-1]
#
# @args		vault_x (unknown)
#			vault_y (unknown)
#			vault_z (unknown)
#			x (unknown)
#			y (unknown)
#			z (unknown)
#			mode (unknown)
#

$clone from survirec:vault $(vault_x) $(vault_y) $(vault_z) $(vault_x) $(vault_y) $(vault_z) $(x) $(y) $(z) $(mode)

