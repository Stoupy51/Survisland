
#> survirec:v1.3.2/vault/restore_next
#
# @executed	at @s
#
# @within	survirec:v1.3.2/vault/restore [ at @s ]
#			survirec:v1.3.2/vault/restore_next
#

function survirec:v1.3.2/vault/restore_copy with storage survirec:playback block_copies[-1]
data remove storage survirec:playback block_copies[-1]
execute if data storage survirec:playback block_copies[0] run function survirec:v1.3.2/vault/restore_next

