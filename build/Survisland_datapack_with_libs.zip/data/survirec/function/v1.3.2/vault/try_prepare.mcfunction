
#> survirec:v1.3.2/vault/try_prepare
#
# @within	survirec:v1.3.2/tick
#

# the dimension is only loaded some ticks after the world starts
execute unless data storage survirec:config are_blocks_ready in survirec:vault if loaded 0 0 0 run function survirec:v1.3.2/vault/prepare_blocks
execute unless data storage survirec:config are_cubes_ready in survirec:vault if loaded 16 0 0 if loaded 32 0 0 run function survirec:v1.3.2/vault/prepare_cubes

