
#> survirec:v1.3.2/vault/prepare_cubes
#
# @executed	in survirec:vault
#
# @within	survirec:v1.3.2/vault/try_prepare [ in survirec:vault ]
#

execute in survirec:vault run fill 16 -64 0 31 31 15 minecraft:barrier strict
execute in survirec:vault run fill 16 32 0 31 127 15 minecraft:barrier strict
execute in survirec:vault run fill 16 128 0 31 223 15 minecraft:barrier strict
execute in survirec:vault run fill 16 224 0 31 319 15 minecraft:barrier strict
execute in survirec:vault run fill 32 -64 0 47 31 15 minecraft:barrier strict
execute in survirec:vault run fill 32 32 0 47 127 15 minecraft:barrier strict
execute in survirec:vault run fill 32 128 0 47 223 15 minecraft:barrier strict
execute in survirec:vault run fill 32 224 0 47 319 15 minecraft:barrier strict
data modify storage survirec:config are_cubes_ready set value 1b

