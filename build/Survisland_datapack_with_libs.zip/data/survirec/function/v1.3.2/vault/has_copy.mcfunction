
#> survirec:v1.3.2/vault/has_copy
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/vault/back_up with storage survirec:playback block_copy
#
# @args		instance_id (unknown)
#			x (unknown)
#			y (unknown)
#			z (unknown)
#

$execute if data storage survirec:instances i$(instance_id).block_copies[{x:$(x),y:$(y),z:$(z)}] run scoreboard players set #has_copy survirec.data 1

