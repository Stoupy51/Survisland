
#> survirec:v1.3.2/vault/copy_block
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/vault/back_up with storage survirec:playback block_copy
#			survirec:v1.3.2/vault/reuse_slot with storage survirec:playback block_copy
#
# @args		x (unknown)
#			y (unknown)
#			z (unknown)
#			vault_x (unknown)
#			vault_y (unknown)
#			vault_z (unknown)
#			instance_id (unknown)
#

$clone $(x) $(y) $(z) $(x) $(y) $(z) to survirec:vault $(vault_x) $(vault_y) $(vault_z) strict
$data modify storage survirec:instances i$(instance_id).block_copies append from storage survirec:playback block_copy

