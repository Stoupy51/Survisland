
#> survirec:v1.3.2/unload
#
# @within	#survirec:unload
#

execute in survirec:vault run forceload remove 0 0 47 15

# Kill entities with custom tags
execute as @e[tag=survirec.entity] at @s run function survirec:v1.3.2/unload/safe_kill
execute as @e[tag=survirec.instance] at @s run function survirec:v1.3.2/unload/safe_kill
execute as @e[tag=survirec.look_marker] at @s run function survirec:v1.3.2/unload/safe_kill
execute as @e[tag=survirec.new] at @s run function survirec:v1.3.2/unload/safe_kill
execute as @e[tag=survirec.new_recorder_marker] at @s run function survirec:v1.3.2/unload/safe_kill
execute as @e[tag=survirec.new_start_marker] at @s run function survirec:v1.3.2/unload/safe_kill
execute as @e[tag=survirec.ray_marker] at @s run function survirec:v1.3.2/unload/safe_kill
execute as @e[tag=survirec.recorder_marker] at @s run function survirec:v1.3.2/unload/safe_kill
execute as @e[tag=survirec.start_marker] at @s run function survirec:v1.3.2/unload/safe_kill

# Remove scoreboard objectives
scoreboard objectives remove load.status
scoreboard objectives remove survirec.action_index
scoreboard objectives remove survirec.armed_kind
scoreboard objectives remove survirec.challenge_ticks
scoreboard objectives remove survirec.chunk_keyframes
scoreboard objectives remove survirec.command_block_x
scoreboard objectives remove survirec.command_block_y
scoreboard objectives remove survirec.command_block_z
scoreboard objectives remove survirec.data
scoreboard objectives remove survirec.delta_pitch
scoreboard objectives remove survirec.delta_x
scoreboard objectives remove survirec.delta_y
scoreboard objectives remove survirec.delta_yaw
scoreboard objectives remove survirec.delta_z
scoreboard objectives remove survirec.equipment_index
scoreboard objectives remove survirec.glide_distance
scoreboard objectives remove survirec.group_id
scoreboard objectives remove survirec.group_loop
scoreboard objectives remove survirec.group_start_tick
scoreboard objectives remove survirec.has_actions
scoreboard objectives remove survirec.has_pending_use
scoreboard objectives remove survirec.has_placed
scoreboard objectives remove survirec.has_swings
scoreboard objectives remove survirec.hit_players
scoreboard objectives remove survirec.instance_id
scoreboard objectives remove survirec.is_challenge
scoreboard objectives remove survirec.is_equipment_forced
scoreboard objectives remove survirec.is_looking_at_block
scoreboard objectives remove survirec.is_near
scoreboard objectives remove survirec.is_pose_fixed
scoreboard objectives remove survirec.is_still
scoreboard objectives remove survirec.is_still_placed
scoreboard objectives remove survirec.item_uses
scoreboard objectives remove survirec.keyframe_count
scoreboard objectives remove survirec.keyframe_divisor
scoreboard objectives remove survirec.keyframe_index
scoreboard objectives remove survirec.keyframe_pitch
scoreboard objectives remove survirec.keyframe_progress
scoreboard objectives remove survirec.keyframe_step
scoreboard objectives remove survirec.keyframe_ticks
scoreboard objectives remove survirec.keyframe_x
scoreboard objectives remove survirec.keyframe_y
scoreboard objectives remove survirec.keyframe_yaw
scoreboard objectives remove survirec.keyframe_z
scoreboard objectives remove survirec.last_hit_tick
scoreboard objectives remove survirec.last_swing_tick
scoreboard objectives remove survirec.left_game
scoreboard objectives remove survirec.look_cube_x
scoreboard objectives remove survirec.look_cube_y
scoreboard objectives remove survirec.look_cube_z
scoreboard objectives remove survirec.loop_mode
scoreboard objectives remove survirec.next_action_tick
scoreboard objectives remove survirec.next_equipment_keyframe
scoreboard objectives remove survirec.next_pose_flags
scoreboard objectives remove survirec.next_release_tick
scoreboard objectives remove survirec.next_swing_tick
scoreboard objectives remove survirec.own_range
scoreboard objectives remove survirec.play_state
scoreboard objectives remove survirec.player_id
scoreboard objectives remove survirec.pose_flags
scoreboard objectives remove survirec.previous_glide_distance
scoreboard objectives remove survirec.previous_sneak_time
scoreboard objectives remove survirec.previous_swim_distance
scoreboard objectives remove survirec.pulse_end_tick
scoreboard objectives remove survirec.record_block_x
scoreboard objectives remove survirec.record_block_y
scoreboard objectives remove survirec.record_block_z
scoreboard objectives remove survirec.record_start_pitch
scoreboard objectives remove survirec.record_start_x
scoreboard objectives remove survirec.record_start_y
scoreboard objectives remove survirec.record_start_yaw
scoreboard objectives remove survirec.record_start_z
scoreboard objectives remove survirec.record_tick
scoreboard objectives remove survirec.recorded_keyframes
scoreboard objectives remove survirec.recorded_pitch
scoreboard objectives remove survirec.recorded_x
scoreboard objectives remove survirec.recorded_y
scoreboard objectives remove survirec.recorded_yaw
scoreboard objectives remove survirec.recorded_z
scoreboard objectives remove survirec.redstone
scoreboard objectives remove survirec.restart_pending
scoreboard objectives remove survirec.restore_mode
scoreboard objectives remove survirec.sneak_time
scoreboard objectives remove survirec.speed
scoreboard objectives remove survirec.start_block_x
scoreboard objectives remove survirec.start_block_y
scoreboard objectives remove survirec.start_block_z
scoreboard objectives remove survirec.start_pitch
scoreboard objectives remove survirec.start_x
scoreboard objectives remove survirec.start_y
scoreboard objectives remove survirec.start_yaw
scoreboard objectives remove survirec.start_z
scoreboard objectives remove survirec.swim_distance
scoreboard objectives remove survirec.swing_index
scoreboard objectives remove survirec.ticks_since_keyframe
scoreboard objectives remove survirec.turns_body
scoreboard objectives remove survirec.used_block_x
scoreboard objectives remove survirec.used_block_y
scoreboard objectives remove survirec.used_block_z
scoreboard objectives remove survirec.used_tick
scoreboard objectives remove survirec.waited_group

# Clear storages
data remove storage survirec:block id
data remove storage survirec:block state
data remove storage survirec:call options
data remove storage survirec:call part
data remove storage survirec:call profile
data remove storage survirec:call sequence
data remove storage survirec:call slot_override
data remove storage survirec:call spawn
data remove storage survirec:challenge group
data remove storage survirec:challenge id
data remove storage survirec:challenge sync
data remove storage survirec:challenge time
data remove storage survirec:challenge tp_back
data remove storage survirec:config are_blocks_ready
data remove storage survirec:config are_cubes_ready
data remove storage survirec:config free_block_slots
data remove storage survirec:config menu
data remove storage survirec:config range
data remove storage survirec:import actions
data remove storage survirec:import equipment
data remove storage survirec:import keyframes
data remove storage survirec:import swings
data remove storage survirec:name_check request
data remove storage survirec:playback action_position
data remove storage survirec:playback block_copies
data remove storage survirec:playback block_copy
data remove storage survirec:playback due_releases
data remove storage survirec:playback other_half
data remove storage survirec:playback pair_offset
data remove storage survirec:playback release
data remove storage survirec:playback support_offset
data remove storage survirec:recording a
data remove storage survirec:recording chunks
data remove storage survirec:recording equipment
data remove storage survirec:recording event
data remove storage survirec:recording export
data remove storage survirec:recording keyframe
data remove storage survirec:recording keyframes
data remove storage survirec:recording meta
data remove storage survirec:recording names_left
data remove storage survirec:recording saved
data remove storage survirec:recording sequence
data remove storage survirec:recording snapshot
data remove storage survirec:recording world_backups

