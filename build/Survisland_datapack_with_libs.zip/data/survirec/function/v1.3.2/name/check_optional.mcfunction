
#> survirec:v1.3.2/name/check_optional
#
# @within	survirec:v1.3.2/api/start with storage survirec:name_check request
#			survirec:v1.3.2/api/play with storage survirec:name_check request
#
# @args		field (string)
#

# an empty optional field is valid
$execute unless data storage survirec:call options{$(field):""} run function survirec:v1.3.2/name/check_required with storage survirec:name_check request

