
#> survirec:v1.3.2/name/check_required
#
# @within	survirec:v1.3.2/api/start with storage survirec:name_check request
#			survirec:v1.3.2/api/play with storage survirec:name_check request
#			survirec:v1.3.2/api/challenge with storage survirec:name_check request
#			survirec:v1.3.2/api/challenge_cmd with storage survirec:name_check request
#			survirec:v1.3.2/api/kill with storage survirec:name_check request
#			survirec:v1.3.2/api/forget with storage survirec:name_check request
#			survirec:v1.3.2/api/export with storage survirec:name_check request
#			survirec:v1.3.2/name/check_optional with storage survirec:name_check request
#
# @args		field (string)
#

data remove storage survirec:name_check text
$data modify storage survirec:name_check text set from storage survirec:call options.$(field)
function survirec:v1.3.2/name/validate
execute if score #is_valid_name survirec.data matches 0 run scoreboard players set #has_bad_name survirec.data 1

