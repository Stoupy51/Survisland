
#> survirec:v1.3.2/name/check_next_character
#
# @within	survirec:v1.3.2/name/validate
#			survirec:v1.3.2/name/check_next_character
#

execute store result storage survirec:name_check bounds.start int 1 run scoreboard players get #character_index survirec.data
scoreboard players add #character_index survirec.data 1
execute store result storage survirec:name_check bounds.end int 1 run scoreboard players get #character_index survirec.data
function survirec:v1.3.2/name/check_character with storage survirec:name_check bounds
execute if score #is_valid_name survirec.data matches 1 if score #character_index survirec.data < #name_length survirec.data run function survirec:v1.3.2/name/check_next_character

