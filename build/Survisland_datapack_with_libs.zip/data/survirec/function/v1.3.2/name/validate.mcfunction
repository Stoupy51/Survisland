
#> survirec:v1.3.2/name/validate
#
# @within	survirec:v1.3.2/name/check_required
#

# checks survirec:name_check text, #is_valid_name 1 or 0
scoreboard players set #is_valid_name survirec.data 1
scoreboard players set #name_length survirec.data 0
execute store result score #name_length survirec.data run data get storage survirec:name_check text
execute unless score #name_length survirec.data matches 1..32 run return run scoreboard players set #is_valid_name survirec.data 0
scoreboard players set #character_index survirec.data 0
function survirec:v1.3.2/name/check_next_character

