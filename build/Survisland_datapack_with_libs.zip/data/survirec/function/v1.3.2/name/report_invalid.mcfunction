
#> survirec:v1.3.2/name/report_invalid
#
# @within	survirec:v1.3.2/api/start
#			survirec:v1.3.2/api/play
#			survirec:v1.3.2/api/challenge
#			survirec:v1.3.2/api/challenge_cmd
#			survirec:v1.3.2/api/kill
#			survirec:v1.3.2/api/forget
#			survirec:v1.3.2/api/export
#

tellraw @s [{text:"🎥 "},{text:"Nom invalide : ",color:"red"},{text:"lettres, chiffres et _ uniquement",color:"gold",bold:true},{text:" (1 à 32 caractères).",color:"red"}]

