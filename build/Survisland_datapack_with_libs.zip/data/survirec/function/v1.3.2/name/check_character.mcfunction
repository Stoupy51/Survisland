
#> survirec:v1.3.2/name/check_character
#
# @within	survirec:v1.3.2/name/check_next_character with storage survirec:name_check bounds
#
# @args		start (unknown)
#			end (unknown)
#

data remove storage survirec:name_check character
$data modify storage survirec:name_check character set string storage survirec:name_check text $(start) $(end)
scoreboard players set #is_allowed_character survirec.data 0
execute if data storage survirec:name_check {character:"a"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"b"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"c"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"d"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"e"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"f"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"g"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"h"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"i"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"j"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"k"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"l"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"m"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"n"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"o"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"p"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"q"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"r"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"s"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"t"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"u"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"v"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"w"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"x"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"y"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"z"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"A"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"B"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"C"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"D"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"E"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"F"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"G"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"H"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"I"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"J"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"K"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"L"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"M"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"N"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"O"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"P"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"Q"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"R"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"S"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"T"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"U"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"V"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"W"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"X"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"Y"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"Z"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"0"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"1"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"2"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"3"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"4"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"5"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"6"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"7"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"8"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"9"} run scoreboard players set #is_allowed_character survirec.data 1
execute if data storage survirec:name_check {character:"_"} run scoreboard players set #is_allowed_character survirec.data 1
execute if score #is_allowed_character survirec.data matches 0 run scoreboard players set #is_valid_name survirec.data 0

