
#> survirec:v1.3.2/help/open_page
#
# @within	survirec:v1.3.2/api/help_page with storage survirec:call options
#
# @args		page (int)
#

execute unless entity @s[type=minecraft:player] run return fail
$dialog show @s survirec:help/page_$(page)

