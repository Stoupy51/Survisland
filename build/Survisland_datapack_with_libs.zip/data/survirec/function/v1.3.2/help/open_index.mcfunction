
#> survirec:v1.3.2/help/open_index
#
# @within	survirec:v1.3.2/api/help
#			survirec:v1.3.2/api/help_page
#

execute unless entity @s[type=minecraft:player] run return fail
dialog show @s survirec:help

