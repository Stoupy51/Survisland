
#> survirec:v1.3.2/pulse/stop
#
# @executed	at @s
#
# @within	survirec:v1.3.2/tick [ at @s ]
#			survirec:v1.3.2/reset [ at @s ]
#

execute if block ~ ~ ~ minecraft:redstone_block run setblock ~ ~ ~ minecraft:air
scoreboard players remove #pulse_count survirec.data 1
kill @s

