
#> survirec:v1.3.2/pulse/place
#
# @within	survirec:v1.3.2/pulse/start_at
#

execute unless block ~ ~ ~ #minecraft:air run return 0
setblock ~ ~ ~ minecraft:redstone_block
execute align xyz positioned ~0.5 ~0.5 ~0.5 summon minecraft:marker run function survirec:v1.3.2/pulse/register

