
#> survirec:v1.3.2/pulse/register
#
# @executed	align xyz & positioned ~0.5 ~0.5 ~0.5
#
# @within	survirec:v1.3.2/pulse/place [ align xyz & positioned ~0.5 ~0.5 ~0.5 ]
#

tag @s add survirec.pulse_marker
tag @s add smithed.entity
tag @s add smithed.strict
scoreboard players operation @s survirec.pulse_end_tick = #game_time survirec.data
scoreboard players add @s survirec.pulse_end_tick 4
scoreboard players add #pulse_count survirec.data 1

