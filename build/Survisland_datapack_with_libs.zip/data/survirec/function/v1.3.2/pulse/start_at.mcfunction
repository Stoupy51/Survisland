
#> survirec:v1.3.2/pulse/start_at
#
# @within	survirec:v1.3.2/pulse/start with storage survirec:playback pulse_position
#
# @args		x (unknown)
#			y (unknown)
#			z (unknown)
#

$execute at @s positioned $(x) $(y) $(z) positioned ~ ~2 ~ run function survirec:v1.3.2/pulse/place

