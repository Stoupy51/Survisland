
#> survirec:v1.3.2/pulse/start
#
# @within	survirec:v1.3.2/playback/on_sequence_end
#			survirec:v1.3.2/group/mark_if_finished [ as @e[tag=survirec.instance] ]
#

execute store result storage survirec:playback pulse_position.x int 1 run scoreboard players get @s survirec.command_block_x
execute store result storage survirec:playback pulse_position.y int 1 run scoreboard players get @s survirec.command_block_y
execute store result storage survirec:playback pulse_position.z int 1 run scoreboard players get @s survirec.command_block_z
function survirec:v1.3.2/pulse/start_at with storage survirec:playback pulse_position

