
#> survirec:v1.3.2/load/enumerate
#
# @within	#survirec:enumerate
#

# If current major is too low, set it to the current major
execute unless score #survirec.major load.status matches 1.. run scoreboard players set #survirec.major load.status 1

# If current minor is too low, set it to the current minor (only if major is correct)
execute if score #survirec.major load.status matches 1 unless score #survirec.minor load.status matches 3.. run scoreboard players set #survirec.minor load.status 3

# If current patch is too low, set it to the current patch (only if major and minor are correct)
execute if score #survirec.major load.status matches 1 if score #survirec.minor load.status matches 3 unless score #survirec.patch load.status matches 2.. run scoreboard players set #survirec.patch load.status 2

