
#> survirec:v1.3.2/load/check_dependencies
#
# @within	survirec:v1.3.2/load/secondary
#

## Check if Survirec is loadable (dependencies)
scoreboard players set #dependency_error survirec.data 0
execute if score #dependency_error survirec.data matches 0 unless score $bs.block.major load.status matches 4.. run scoreboard players set #dependency_error survirec.data 1
execute if score #dependency_error survirec.data matches 0 if score $bs.block.major load.status matches 4 unless score $bs.block.minor load.status matches 1.. run scoreboard players set #dependency_error survirec.data 1
execute if score #dependency_error survirec.data matches 0 if score $bs.block.major load.status matches 4 if score $bs.block.minor load.status matches 1 unless score $bs.block.patch load.status matches 1.. run scoreboard players set #dependency_error survirec.data 1

