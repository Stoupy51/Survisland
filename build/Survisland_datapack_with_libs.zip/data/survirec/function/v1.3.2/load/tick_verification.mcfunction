
#> survirec:v1.3.2/load/tick_verification
#
# @within	#minecraft:tick
#

execute if score #survirec.major load.status matches 1 if score #survirec.minor load.status matches 3 if score #survirec.patch load.status matches 2 run function survirec:v1.3.2/tick

