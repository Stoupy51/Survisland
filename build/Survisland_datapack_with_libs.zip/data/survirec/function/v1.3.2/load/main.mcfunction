
#> survirec:v1.3.2/load/main
#
# @within	survirec:v1.3.2/load/resolve
#

# Avoiding multiple executions of the same load function
execute unless score #survirec.loaded load.status matches 1 run function survirec:v1.3.2/load/secondary

