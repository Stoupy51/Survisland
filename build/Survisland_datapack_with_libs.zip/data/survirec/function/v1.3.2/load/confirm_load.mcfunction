
#> survirec:v1.3.2/load/confirm_load
#
# @within	survirec:v1.3.2/load/valid_dependencies
#

# Confirm load
tellraw @a[tag=convention.debug] {"text":"[Loaded Survirec v1.3.2]","color":"green"}
scoreboard players set #survirec.loaded load.status 1

# Objectives
scoreboard objectives add survirec.instance_id dummy
scoreboard objectives add survirec.play_state dummy
scoreboard objectives add survirec.loop_mode dummy
scoreboard objectives add survirec.speed dummy
scoreboard objectives add survirec.keyframe_index dummy
scoreboard objectives add survirec.keyframe_count dummy
scoreboard objectives add survirec.keyframe_ticks dummy
scoreboard objectives add survirec.keyframe_progress dummy
scoreboard objectives add survirec.keyframe_divisor dummy
scoreboard objectives add survirec.start_x dummy
scoreboard objectives add survirec.start_y dummy
scoreboard objectives add survirec.start_z dummy
scoreboard objectives add survirec.start_yaw dummy
scoreboard objectives add survirec.start_pitch dummy
scoreboard objectives add survirec.keyframe_x dummy
scoreboard objectives add survirec.keyframe_y dummy
scoreboard objectives add survirec.keyframe_z dummy
scoreboard objectives add survirec.keyframe_yaw dummy
scoreboard objectives add survirec.keyframe_pitch dummy
scoreboard objectives add survirec.delta_x dummy
scoreboard objectives add survirec.delta_y dummy
scoreboard objectives add survirec.delta_z dummy
scoreboard objectives add survirec.delta_yaw dummy
scoreboard objectives add survirec.delta_pitch dummy
scoreboard objectives add survirec.pose_flags dummy
scoreboard objectives add survirec.next_pose_flags dummy
scoreboard objectives add survirec.is_pose_fixed dummy
scoreboard objectives add survirec.turns_body dummy
scoreboard objectives add survirec.is_still dummy
scoreboard objectives add survirec.is_still_placed dummy
scoreboard objectives add survirec.is_near dummy
scoreboard objectives add survirec.own_range dummy
scoreboard objectives add survirec.equipment_index dummy
scoreboard objectives add survirec.next_equipment_keyframe dummy
scoreboard objectives add survirec.is_equipment_forced dummy
scoreboard objectives add survirec.has_swings dummy
scoreboard objectives add survirec.swing_index dummy
scoreboard objectives add survirec.next_swing_tick dummy
scoreboard objectives add survirec.group_id dummy
scoreboard objectives add survirec.group_loop dummy
scoreboard objectives add survirec.group_start_tick dummy
scoreboard objectives add survirec.restart_pending dummy
scoreboard objectives add survirec.has_actions dummy
scoreboard objectives add survirec.action_index dummy
scoreboard objectives add survirec.next_action_tick dummy
scoreboard objectives add survirec.restore_mode dummy
scoreboard objectives add survirec.hit_players dummy
scoreboard objectives add survirec.next_release_tick dummy
scoreboard objectives add survirec.redstone dummy
scoreboard objectives add survirec.pulse_end_tick dummy
scoreboard objectives add survirec.start_block_x dummy
scoreboard objectives add survirec.start_block_y dummy
scoreboard objectives add survirec.start_block_z dummy
scoreboard objectives add survirec.command_block_x dummy
scoreboard objectives add survirec.command_block_y dummy
scoreboard objectives add survirec.command_block_z dummy
scoreboard objectives add survirec.player_id dummy
scoreboard objectives add survirec.record_tick dummy
scoreboard objectives add survirec.keyframe_step dummy
scoreboard objectives add survirec.ticks_since_keyframe dummy
scoreboard objectives add survirec.recorded_keyframes dummy
scoreboard objectives add survirec.chunk_keyframes dummy
scoreboard objectives add survirec.last_swing_tick dummy
scoreboard objectives add survirec.is_challenge dummy
scoreboard objectives add survirec.challenge_ticks dummy
scoreboard objectives add survirec.waited_group dummy
scoreboard objectives add survirec.armed_kind dummy
scoreboard objectives add survirec.recorded_x dummy
scoreboard objectives add survirec.recorded_y dummy
scoreboard objectives add survirec.recorded_z dummy
scoreboard objectives add survirec.recorded_yaw dummy
scoreboard objectives add survirec.recorded_pitch dummy
scoreboard objectives add survirec.record_start_x dummy
scoreboard objectives add survirec.record_start_y dummy
scoreboard objectives add survirec.record_start_z dummy
scoreboard objectives add survirec.record_start_yaw dummy
scoreboard objectives add survirec.record_start_pitch dummy
scoreboard objectives add survirec.previous_sneak_time dummy
scoreboard objectives add survirec.previous_swim_distance dummy
scoreboard objectives add survirec.previous_glide_distance dummy
scoreboard objectives add survirec.record_block_x dummy
scoreboard objectives add survirec.record_block_y dummy
scoreboard objectives add survirec.record_block_z dummy
scoreboard objectives add survirec.is_looking_at_block dummy
scoreboard objectives add survirec.look_cube_x dummy
scoreboard objectives add survirec.look_cube_y dummy
scoreboard objectives add survirec.look_cube_z dummy
scoreboard objectives add survirec.has_pending_use dummy
scoreboard objectives add survirec.has_placed dummy
scoreboard objectives add survirec.used_block_x dummy
scoreboard objectives add survirec.used_block_y dummy
scoreboard objectives add survirec.used_block_z dummy
scoreboard objectives add survirec.used_tick dummy
scoreboard objectives add survirec.last_hit_tick dummy
scoreboard objectives add survirec.sneak_time minecraft.custom:minecraft.sneak_time
scoreboard objectives add survirec.swim_distance minecraft.custom:minecraft.swim_one_cm
scoreboard objectives add survirec.glide_distance minecraft.custom:minecraft.aviate_one_cm
scoreboard objectives add survirec.item_uses minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add survirec.left_game minecraft.custom:minecraft.leave_game

# World state defaults
execute unless score #next_instance_id survirec.data = #next_instance_id survirec.data run scoreboard players set #next_instance_id survirec.data 0
execute unless score #next_player_id survirec.data = #next_player_id survirec.data run scoreboard players set #next_player_id survirec.data 0
execute unless score #next_group_id survirec.data = #next_group_id survirec.data run scoreboard players set #next_group_id survirec.data 0
execute unless score #tick survirec.data = #tick survirec.data run scoreboard players set #tick survirec.data 0
execute unless score #has_pending_group survirec.data = #has_pending_group survirec.data run scoreboard players set #has_pending_group survirec.data 0
execute unless score #next_block_slot survirec.data = #next_block_slot survirec.data run scoreboard players set #next_block_slot survirec.data 0
execute unless score #next_cube_slot survirec.data = #next_cube_slot survirec.data run scoreboard players set #next_cube_slot survirec.data 0
execute unless score #pulse_count survirec.data = #pulse_count survirec.data run scoreboard players set #pulse_count survirec.data 0
execute unless score #move_every survirec.data = #move_every survirec.data run scoreboard players set #move_every survirec.data 2
execute unless data storage survirec:config range run data modify storage survirec:config range set value 128
function survirec:v1.3.2/menu/set_head_texture
execute store result score #instance_count survirec.data if entity @e[tag=survirec.instance]

# Hidden dimension holding the block copies
execute in survirec:vault run forceload add 0 0 47 15

# Set scoreboard constants for survirec.data
scoreboard players set #-1 survirec.data -1
scoreboard players set #2 survirec.data 2
scoreboard players set #4 survirec.data 4
scoreboard players set #5 survirec.data 5
scoreboard players set #7 survirec.data 7
scoreboard players set #10 survirec.data 10
scoreboard players set #16 survirec.data 16
scoreboard players set #20 survirec.data 20
scoreboard players set #49 survirec.data 49
scoreboard players set #60 survirec.data 60
scoreboard players set #1536 survirec.data 1536

