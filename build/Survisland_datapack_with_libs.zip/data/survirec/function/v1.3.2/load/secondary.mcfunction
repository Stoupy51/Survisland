
#> survirec:v1.3.2/load/secondary
#
# @within	survirec:v1.3.2/load/main
#

# Survirec
scoreboard objectives add survirec.data dummy
tag Artyu24 add convention.debug

# Check dependencies and wait for a player to connect (to get server version)
function survirec:v1.3.2/load/check_dependencies
function survirec:v1.3.2/load/valid_dependencies

