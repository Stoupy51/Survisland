
#> survirec:v1.3.2/load/valid_dependencies
#
# @within	survirec:v1.3.2/load/secondary
#			survirec:v1.3.2/load/valid_dependencies 1t replace [ scheduled ]
#

# Waiting for a player to get the game version, but stop function if no player found
execute unless entity @p run return run schedule function survirec:v1.3.2/load/valid_dependencies 1t replace
execute store result score #game_version survirec.data run data get entity @p DataVersion

# Check if the game version is supported
scoreboard players set #mcload_error survirec.data 0
execute unless score #game_version survirec.data matches 4903.. run scoreboard players set #mcload_error survirec.data 1

# Decode errors
execute if score #mcload_error survirec.data matches 1 run tellraw @a {"text":"Survirec Error: This version is made for Minecraft 26.2+.","color":"red"}
execute if score #dependency_error survirec.data matches 1 run tellraw @a {"text":"Survirec Error: Libraries are missing\nplease download the right Survirec datapack\nor download each of these libraries one by one:","color":"red"}
execute if score #dependency_error survirec.data matches 1 unless score $bs.block.major load.status matches 4.. run tellraw @a {"text":"- [Bookshelf Block (v4.1.1+)]","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}
execute if score #dependency_error survirec.data matches 1 if score $bs.block.major load.status matches 4 unless score $bs.block.minor load.status matches 1.. run tellraw @a {"text":"- [Bookshelf Block (v4.1.1+)]","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}
execute if score #dependency_error survirec.data matches 1 if score $bs.block.major load.status matches 4 if score $bs.block.minor load.status matches 1 unless score $bs.block.patch load.status matches 1.. run tellraw @a {"text":"- [Bookshelf Block (v4.1.1+)]","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}

# Load Survirec
execute if score #game_version survirec.data matches 1.. if score #mcload_error survirec.data matches 0 if score #dependency_error survirec.data matches 0 run function survirec:v1.3.2/load/confirm_load

