
#> survirec:v1.3.2/load/resolve
#
# @within	#survirec:resolve
#

# If correct version, load the datapack
execute if score #survirec.major load.status matches 1 if score #survirec.minor load.status matches 3 if score #survirec.patch load.status matches 2 run function survirec:v1.3.2/load/main

