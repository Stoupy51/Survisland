
#> survirec:v1.3.2/range/check_own
#
# @executed	as @e[tag=...] & at @s
#
# @within	survirec:v1.3.2/tick [ as @e[tag=...] & at @s ]
#

execute store result storage survirec:playback range int 1 run scoreboard players get @s survirec.own_range
function survirec:v1.3.2/range/check_own_distance with storage survirec:playback

