
#> survirec:v1.3.2/range/check_global
#
# @within	survirec:v1.3.2/tick with storage survirec:config
#
# @args		range (unknown)
#

$execute as @e[tag=survirec.instance,tag=!survirec.has_own_range] at @s store success score @s survirec.is_near if entity @a[distance=..$(range)]

