
#> survirec:v1.3.2/range/set_global
#
# @within	survirec:v1.3.2/api/range with storage survirec:call options
#
# @args		r (int)
#

$data modify storage survirec:config range set value $(r)

