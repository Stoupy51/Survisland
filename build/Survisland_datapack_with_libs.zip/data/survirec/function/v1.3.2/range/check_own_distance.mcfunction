
#> survirec:v1.3.2/range/check_own_distance
#
# @executed	as @e[tag=...] & at @s
#
# @within	survirec:v1.3.2/range/check_own with storage survirec:playback
#
# @args		range (unknown)
#

$execute store success score @s survirec.is_near if entity @a[distance=..$(range)]

