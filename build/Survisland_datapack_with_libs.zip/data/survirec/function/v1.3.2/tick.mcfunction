
#> survirec:v1.3.2/tick
#
# @within	survirec:v1.3.2/load/tick_verification
#

execute store result score #game_time survirec.data run time query gametime
execute unless data storage survirec:config are_cubes_ready run function survirec:v1.3.2/vault/try_prepare
scoreboard players add #tick survirec.data 1
execute if score #tick survirec.data matches 1000000.. run scoreboard players set #tick survirec.data 0

# Players: rejoin, menu item, recordings
execute as @a[scores={survirec.left_game=1..}] run function survirec:v1.3.2/record/on_rejoin
execute as @a[scores={survirec.item_uses=1..}] if items entity @s weapon.* minecraft:carrot_on_a_stick[minecraft:custom_data~{survirec:{menu:1b}}] run function survirec:v1.3.2/menu/open
execute as @a[tag=survirec.recording] at @s run function survirec:v1.3.2/record/tick

# Every 10 ticks: players near the entities, armed recordings, entity count (corrects kills and chunk loads)
scoreboard players operation #tick_mod_10 survirec.data = #tick survirec.data
scoreboard players operation #tick_mod_10 survirec.data %= #10 survirec.data
execute if score #tick_mod_10 survirec.data matches 0 store result score #instance_count survirec.data if entity @e[tag=survirec.instance]
execute if score #tick_mod_10 survirec.data matches 0 if score #instance_count survirec.data matches 1.. run function survirec:v1.3.2/range/check_global with storage survirec:config
execute if score #tick_mod_10 survirec.data matches 0 as @a[tag=survirec.armed] run function survirec:v1.3.2/challenge/check_armed

# Every 4 ticks: entities with their own range
scoreboard players operation #tick_mod_4 survirec.data = #tick survirec.data
scoreboard players operation #tick_mod_4 survirec.data %= #4 survirec.data
execute if score #tick_mod_4 survirec.data matches 0 if score #instance_count survirec.data matches 1.. as @e[tag=survirec.instance,tag=survirec.has_own_range] at @s run function survirec:v1.3.2/range/check_own

# Every 5 ticks: start markers, only while someone records
scoreboard players operation #tick_mod_5 survirec.data = #tick survirec.data
scoreboard players operation #tick_mod_5 survirec.data %= #5 survirec.data
execute if score #tick_mod_5 survirec.data matches 0 if entity @a[tag=survirec.recording,limit=1] as @e[type=minecraft:text_display,tag=survirec.start_marker] at @s run function survirec:v1.3.2/record/show_start_marker

# Playback
execute if score #pulse_count survirec.data matches 1.. as @e[type=minecraft:marker,tag=survirec.pulse_marker] if score #game_time survirec.data >= @s survirec.pulse_end_tick at @s run function survirec:v1.3.2/pulse/stop
execute if score #instance_count survirec.data matches 1.. as @e[tag=survirec.instance] run function survirec:v1.3.2/playback/tick
execute if score #has_pending_group survirec.data matches 1 run function survirec:v1.3.2/group/restart_pending

