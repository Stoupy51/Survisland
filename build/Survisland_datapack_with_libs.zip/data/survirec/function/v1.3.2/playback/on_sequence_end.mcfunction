
#> survirec:v1.3.2/playback/on_sequence_end
#
# @within	survirec:v1.3.2/playback/advance_keyframe
#

execute if score @s survirec.redstone matches 1 if score @s survirec.group_id matches 0 run function survirec:v1.3.2/pulse/start
execute if score @s survirec.loop_mode matches 1 run function survirec:v1.3.2/playback/restart
execute unless score @s survirec.loop_mode matches 0..2 run function survirec:v1.3.2/playback/restart
execute if score @s survirec.loop_mode matches 0 run function survirec:v1.3.2/playback/freeze
execute if score @s survirec.loop_mode matches 2 run function survirec:v1.3.2/playback/delete

