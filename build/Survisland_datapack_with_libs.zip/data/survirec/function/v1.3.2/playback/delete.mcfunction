
#> survirec:v1.3.2/playback/delete
#
# @within	survirec:v1.3.2/kill/by_tag
#			survirec:v1.3.2/kill/by_name
#			survirec:v1.3.2/kill/all [ as @e[tag=survirec.entity] ]
#			survirec:v1.3.2/playback/on_sequence_end
#			survirec:v1.3.2/group/mark_if_finished [ as @e[tag=survirec.instance] ]
#			survirec:v1.3.2/challenge/kill_previous_double
#

scoreboard players set @s survirec.play_state 0
function survirec:v1.3.2/release/run_all
execute if score @s survirec.restore_mode matches 2 run function survirec:v1.3.2/vault/restore
execute if score @s survirec.restore_mode matches 1 if score #restore_on_kill survirec.data matches 1 run function survirec:v1.3.2/vault/restore
function survirec:v1.3.2/vault/free
execute store result storage survirec:playback instance_id int 1 run scoreboard players get @s survirec.instance_id
function survirec:v1.3.2/playback/unregister with storage survirec:playback
tag @s remove survirec.instance
scoreboard players remove #instance_count survirec.data 1
# nothing may show nor drop: equipment emptied, entity sent below the world before it is removed
item replace entity @s armor.head with minecraft:air
item replace entity @s armor.chest with minecraft:air
item replace entity @s armor.legs with minecraft:air
item replace entity @s armor.feet with minecraft:air
item replace entity @s weapon.mainhand with minecraft:air
item replace entity @s weapon.offhand with minecraft:air
effect give @s minecraft:invisibility infinite 0 true
tp @s ~ -1000 ~
kill @s

