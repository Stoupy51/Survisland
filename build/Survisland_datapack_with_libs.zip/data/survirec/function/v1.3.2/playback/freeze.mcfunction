
#> survirec:v1.3.2/playback/freeze
#
# @within	survirec:v1.3.2/playback/on_sequence_end
#

scoreboard players set @s survirec.delta_x 0
scoreboard players set @s survirec.delta_y 0
scoreboard players set @s survirec.delta_z 0
scoreboard players set @s survirec.delta_yaw 0
scoreboard players set @s survirec.delta_pitch 0
scoreboard players set @s survirec.keyframe_progress 0
scoreboard players set @s survirec.play_state 0
execute if score @s survirec.group_id matches 0 if score @s survirec.restore_mode matches 2 run function survirec:v1.3.2/vault/restore
function survirec:v1.3.2/playback/move
execute if score @s survirec.group_id matches 1.. run function survirec:v1.3.2/group/on_member_frozen

