
#> survirec:v1.3.2/playback/walk_back_tick
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/playback/tick
#

execute unless score @s survirec.is_near matches 1 run return 0
scoreboard players add @s survirec.keyframe_progress 1
execute if score @s survirec.keyframe_progress >= @s survirec.keyframe_divisor run return run function survirec:v1.3.2/playback/finish_walk_back
execute if function survirec:v1.3.2/playback/is_turn_to_move run function survirec:v1.3.2/playback/move

