
#> survirec:v1.3.2/playback/turn_body
#
# @within	survirec:v1.3.2/playback/move with storage survirec:playback teleport
#
# @args		yaw (unknown)
#			pitch (unknown)
#

$data modify entity @s Rotation set value [$(yaw)f,$(pitch)f]
execute if score @s survirec.delta_yaw matches 0 run scoreboard players set @s survirec.turns_body 0

