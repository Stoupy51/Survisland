
#> survirec:v1.3.2/playback/restart
#
# @within	survirec:v1.3.2/playback/on_sequence_end
#			survirec:v1.3.2/playback/finish_walk_back
#

execute if score @s survirec.restore_mode matches 1.. run function survirec:v1.3.2/vault/restore
scoreboard players set @s survirec.keyframe_index 0
scoreboard players operation @s survirec.keyframe_x = @s survirec.start_x
scoreboard players operation @s survirec.keyframe_y = @s survirec.start_y
scoreboard players operation @s survirec.keyframe_z = @s survirec.start_z
scoreboard players operation @s survirec.keyframe_yaw = @s survirec.start_yaw
scoreboard players operation @s survirec.keyframe_pitch = @s survirec.start_pitch
scoreboard players set @s survirec.is_still 0
scoreboard players set @s survirec.equipment_index 0
scoreboard players set @s survirec.next_equipment_keyframe 0
execute if score @s survirec.has_swings matches 1 run scoreboard players set @s survirec.swing_index 0
execute if score @s survirec.has_swings matches 1 run function survirec:v1.3.2/swing/load_next
execute if score @s survirec.has_actions matches 1 run scoreboard players set @s survirec.action_index 0
execute if score @s survirec.has_actions matches 1 run function survirec:v1.3.2/action/load_next

