
#> survirec:v1.3.2/playback/apply_pose
#
# @executed	as @e[tag=survirec.instance,scores={survirec.restart_pending=1}]
#
# @within	survirec:v1.3.2/group/walk_back
#			survirec:v1.3.2/playback/read_keyframe
#

scoreboard players operation @s survirec.pose_flags = @s survirec.next_pose_flags
execute if score @s survirec.pose_flags matches 0 run data modify entity @s pose set value "standing"
execute if score @s survirec.pose_flags matches 1 run data modify entity @s pose set value "crouching"
execute if score @s survirec.pose_flags matches 2..3 run data modify entity @s pose set value "swimming"
execute if score @s survirec.pose_flags matches 4..7 run data modify entity @s pose set value "fall_flying"
execute if score @s survirec.pose_flags matches 4..7 run data modify entity @s OnGround set value 0b
execute if score @s survirec.pose_flags matches 4..7 run data modify entity @s FallFlying set value 1b
execute unless score @s survirec.pose_flags matches 4..7 run data modify entity @s FallFlying set value 0b

