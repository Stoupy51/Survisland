
#> survirec:v1.3.2/playback/unregister
#
# @within	survirec:v1.3.2/playback/delete with storage survirec:playback
#
# @args		instance_id (unknown)
#

$data remove storage survirec:instances i$(instance_id)

