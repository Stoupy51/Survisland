
#> survirec:v1.3.2/playback/read_keyframe_name
#
# @within	survirec:v1.3.2/playback/load_keyframe with storage survirec:playback
#
# @args		instance_id (unknown)
#

$data modify storage survirec:playback name set from storage survirec:instances i$(instance_id).name
function survirec:v1.3.2/playback/read_keyframe with storage survirec:playback

