
#> survirec:v1.3.2/playback/advance_keyframe
#
# @within	survirec:v1.3.2/playback/advance_keyframe
#			survirec:v1.3.2/playback/tick
#			survirec:v1.3.2/spawn/init_start
#

scoreboard players operation @s survirec.keyframe_progress -= @s survirec.keyframe_ticks
scoreboard players operation @s survirec.keyframe_x += @s survirec.delta_x
scoreboard players operation @s survirec.keyframe_y += @s survirec.delta_y
scoreboard players operation @s survirec.keyframe_z += @s survirec.delta_z
scoreboard players operation @s survirec.keyframe_yaw += @s survirec.delta_yaw
scoreboard players operation @s survirec.keyframe_pitch += @s survirec.delta_pitch
scoreboard players add @s survirec.keyframe_index 1
execute if score @s survirec.keyframe_index >= @s survirec.keyframe_count run function survirec:v1.3.2/playback/on_sequence_end
execute if score @s survirec.play_state matches 1 run function survirec:v1.3.2/playback/load_keyframe
execute if score @s survirec.play_state matches 1 if score @s survirec.keyframe_progress >= @s survirec.keyframe_ticks run function survirec:v1.3.2/playback/advance_keyframe

