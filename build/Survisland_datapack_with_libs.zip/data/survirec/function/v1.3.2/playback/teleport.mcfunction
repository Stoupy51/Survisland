
#> survirec:v1.3.2/playback/teleport
#
# @within	survirec:v1.3.2/playback/move with storage survirec:playback teleport
#			survirec:v1.3.2/challenge/teleport_back with storage survirec:recording start_point
#
# @args		x (unknown)
#			y (unknown)
#			z (unknown)
#			yaw (unknown)
#			pitch (unknown)
#

$tp @s $(x) $(y) $(z) $(yaw) $(pitch)

