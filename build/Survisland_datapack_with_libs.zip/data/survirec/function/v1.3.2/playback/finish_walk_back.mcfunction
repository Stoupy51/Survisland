
#> survirec:v1.3.2/playback/finish_walk_back
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/playback/walk_back_tick
#

scoreboard players operation @s survirec.group_start_tick = #tick survirec.data
scoreboard players operation @s survirec.keyframe_divisor = @s survirec.keyframe_ticks
scoreboard players set @s survirec.keyframe_progress 0
scoreboard players set @s survirec.pose_flags -1
scoreboard players set @s survirec.is_still_placed 0
function survirec:v1.3.2/playback/restart
scoreboard players set @s survirec.play_state 1
function survirec:v1.3.2/playback/load_keyframe
function survirec:v1.3.2/playback/move
scoreboard players operation #restarted_group survirec.data = @s survirec.group_id
execute as @a[tag=survirec.armed] if score @s survirec.waited_group = #restarted_group survirec.data run function survirec:v1.3.2/challenge/launch

