
#> survirec:v1.3.2/playback/read_keyframe
#
# @within	survirec:v1.3.2/playback/read_keyframe_name with storage survirec:playback
#
# @args		name (unknown)
#			keyframe_index (unknown)
#

$data modify storage survirec:playback keyframe set from storage survirec:data seqs.$(name).d[$(keyframe_index)]
execute store result score @s survirec.delta_x run data get storage survirec:playback keyframe[0]
execute store result score @s survirec.delta_y run data get storage survirec:playback keyframe[1]
execute store result score @s survirec.delta_z run data get storage survirec:playback keyframe[2]
execute store result score @s survirec.delta_yaw run data get storage survirec:playback keyframe[3]
execute store result score @s survirec.delta_pitch run data get storage survirec:playback keyframe[4]
execute store result score @s survirec.next_pose_flags run data get storage survirec:playback keyframe[5]
scoreboard players operation #was_still survirec.data = @s survirec.is_still
scoreboard players set @s survirec.is_still 0
execute if score @s survirec.delta_x matches 0 if score @s survirec.delta_y matches 0 if score @s survirec.delta_z matches 0 if score @s survirec.delta_yaw matches 0 if score @s survirec.delta_pitch matches 0 run scoreboard players set @s survirec.is_still 1
execute unless score @s survirec.is_still matches 1 run scoreboard players set @s survirec.is_still_placed 0
execute unless score #was_still survirec.data matches 1 run scoreboard players set @s survirec.is_still_placed 0
# a swimming or gliding pose turns the body with the head
scoreboard players set @s survirec.turns_body 0
execute if score @s survirec.is_pose_fixed matches 0 if score @s survirec.next_pose_flags matches 2..7 unless score @s survirec.delta_yaw matches 0 run scoreboard players set @s survirec.turns_body 1
execute if score @s survirec.is_pose_fixed matches 0 if score @s survirec.next_pose_flags matches 2..7 unless score @s survirec.next_pose_flags = @s survirec.pose_flags run scoreboard players set @s survirec.turns_body 1
execute if score @s survirec.turns_body matches 1 run scoreboard players set @s survirec.is_still_placed 0
execute if score @s survirec.is_pose_fixed matches 0 unless score @s survirec.next_pose_flags = @s survirec.pose_flags run function survirec:v1.3.2/playback/apply_pose

