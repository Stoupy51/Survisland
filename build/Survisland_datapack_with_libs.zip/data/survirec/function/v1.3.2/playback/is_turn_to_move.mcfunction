
#> survirec:v1.3.2/playback/is_turn_to_move
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/playback/walk_back_tick
#			survirec:v1.3.2/playback/tick
#

# one entity in #move_every moves on each tick, in turns
scoreboard players operation #turn_phase survirec.data = @s survirec.instance_id
scoreboard players operation #turn_phase survirec.data += #tick survirec.data
scoreboard players operation #turn_phase survirec.data %= #move_every survirec.data
execute if score #turn_phase survirec.data matches 0 run return 1
return fail

