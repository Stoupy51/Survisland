
#> survirec:v1.3.2/playback/move
#
# @within	survirec:v1.3.2/playback/freeze
#			survirec:v1.3.2/playback/finish_walk_back
#			survirec:v1.3.2/playback/walk_back_tick
#			survirec:v1.3.2/playback/tick
#			survirec:v1.3.2/spawn/init_start
#

scoreboard players operation #interpolated survirec.data = @s survirec.delta_x
scoreboard players operation #interpolated survirec.data *= @s survirec.keyframe_progress
scoreboard players operation #interpolated survirec.data /= @s survirec.keyframe_divisor
scoreboard players operation #interpolated survirec.data += @s survirec.keyframe_x
execute store result storage survirec:playback teleport.x double 0.001 run scoreboard players get #interpolated survirec.data
scoreboard players operation #interpolated survirec.data = @s survirec.delta_y
scoreboard players operation #interpolated survirec.data *= @s survirec.keyframe_progress
scoreboard players operation #interpolated survirec.data /= @s survirec.keyframe_divisor
scoreboard players operation #interpolated survirec.data += @s survirec.keyframe_y
execute store result storage survirec:playback teleport.y double 0.001 run scoreboard players get #interpolated survirec.data
scoreboard players operation #interpolated survirec.data = @s survirec.delta_z
scoreboard players operation #interpolated survirec.data *= @s survirec.keyframe_progress
scoreboard players operation #interpolated survirec.data /= @s survirec.keyframe_divisor
scoreboard players operation #interpolated survirec.data += @s survirec.keyframe_z
execute store result storage survirec:playback teleport.z double 0.001 run scoreboard players get #interpolated survirec.data
scoreboard players operation #interpolated survirec.data = @s survirec.delta_yaw
scoreboard players operation #interpolated survirec.data *= @s survirec.keyframe_progress
scoreboard players operation #interpolated survirec.data /= @s survirec.keyframe_divisor
scoreboard players operation #interpolated survirec.data += @s survirec.keyframe_yaw
execute store result storage survirec:playback teleport.yaw double 0.01 run scoreboard players get #interpolated survirec.data
scoreboard players operation #interpolated survirec.data = @s survirec.delta_pitch
scoreboard players operation #interpolated survirec.data *= @s survirec.keyframe_progress
scoreboard players operation #interpolated survirec.data /= @s survirec.keyframe_divisor
scoreboard players operation #interpolated survirec.data += @s survirec.keyframe_pitch
execute if score #interpolated survirec.data matches 9001.. run scoreboard players set #interpolated survirec.data 9000
execute if score #interpolated survirec.data matches ..-9001 run scoreboard players set #interpolated survirec.data -9000
execute store result storage survirec:playback teleport.pitch double 0.01 run scoreboard players get #interpolated survirec.data
function survirec:v1.3.2/playback/teleport with storage survirec:playback teleport
execute if score @s survirec.turns_body matches 1 run function survirec:v1.3.2/playback/turn_body with storage survirec:playback teleport
execute if score @s survirec.is_still matches 1 run scoreboard players set @s survirec.is_still_placed 1

