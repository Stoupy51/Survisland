
#> survirec:v1.3.2/playback/load_keyframe
#
# @within	survirec:v1.3.2/playback/advance_keyframe
#			survirec:v1.3.2/playback/finish_walk_back
#			survirec:v1.3.2/spawn/init_sequence
#

execute store result storage survirec:playback instance_id int 1 run scoreboard players get @s survirec.instance_id
execute store result storage survirec:playback keyframe_index int 1 run scoreboard players get @s survirec.keyframe_index
function survirec:v1.3.2/playback/read_keyframe_name with storage survirec:playback
execute if score @s survirec.is_equipment_forced matches 0 if score @s survirec.keyframe_index >= @s survirec.next_equipment_keyframe run function survirec:v1.3.2/equipment/load_next

