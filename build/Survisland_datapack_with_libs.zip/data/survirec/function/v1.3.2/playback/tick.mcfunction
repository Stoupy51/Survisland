
#> survirec:v1.3.2/playback/tick
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/tick [ as @e[tag=survirec.instance] ]
#

execute if score @s survirec.next_release_tick matches 0.. if score #game_time survirec.data >= @s survirec.next_release_tick run function survirec:v1.3.2/release/run_due
execute if score @s survirec.play_state matches 2 run return run function survirec:v1.3.2/playback/walk_back_tick
execute unless score @s survirec.play_state matches 1 run return 0
execute unless score @s survirec.is_near matches 1 run return 0
scoreboard players operation @s survirec.keyframe_progress += @s survirec.speed
execute if score @s survirec.keyframe_progress >= @s survirec.keyframe_ticks run function survirec:v1.3.2/playback/advance_keyframe
execute unless score @s survirec.play_state matches 1 run return 0
execute if score @s survirec.has_swings matches 1 run function survirec:v1.3.2/swing/run_due
execute if score @s survirec.has_actions matches 1 run function survirec:v1.3.2/action/run_due
execute if score @s survirec.is_still matches 1 if score @s survirec.is_still_placed matches 1 run return 0
execute if function survirec:v1.3.2/playback/is_turn_to_move run function survirec:v1.3.2/playback/move

