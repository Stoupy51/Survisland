
#> survirec:v1.3.2/menu/list_next_record
#
# @within	survirec:v1.3.2/menu/list_records
#			survirec:v1.3.2/menu/list_next_record
#

# only the recordings of this player
scoreboard players set #entry_player survirec.data -1
execute store result score #entry_player survirec.data run data get storage survirec:recording names_left[0].player_id
execute if score #entry_player survirec.data = #player_id survirec.data run function survirec:v1.3.2/menu/show_record with storage survirec:recording names_left[0]
data remove storage survirec:recording names_left[0]
execute if data storage survirec:recording names_left[0] run function survirec:v1.3.2/menu/list_next_record

