
#> survirec:v1.3.2/menu/give_head_item
#
# @within	survirec:v1.3.2/menu/give_item with storage survirec:config menu
#
# @args		texture (unknown)
#

$give @s minecraft:carrot_on_a_stick[minecraft:custom_data={survirec:{menu:1b},smithed:{ignore:{functionality:1b,crafting:1b}}},minecraft:item_name={text:"Survirec",color:"gold",bold:true},minecraft:lore=[{text:"Clic droit : ouvrir le menu",color:"gray",italic:false}],minecraft:item_model="minecraft:player_head",minecraft:profile={properties:[{name:"textures",value:"$(texture)"}]}]

