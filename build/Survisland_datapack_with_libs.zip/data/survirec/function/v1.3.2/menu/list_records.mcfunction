
#> survirec:v1.3.2/menu/list_records
#
# @within	survirec:v1.3.2/api/records
#

tellraw @s {text:"══ Enregistrements ══",color:"gold"}
scoreboard players operation #player_id survirec.data = @s survirec.player_id
scoreboard players set #record_count survirec.data 0
data modify storage survirec:recording names_left set value []
data modify storage survirec:recording names_left set from storage survirec:library names
execute if data storage survirec:recording names_left[0] run function survirec:v1.3.2/menu/list_next_record
execute if score #record_count survirec.data matches 0 run tellraw @s {text:"   Aucun enregistrement pour l'instant.",color:"gray"}

