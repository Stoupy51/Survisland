
#> survirec:v1.3.2/menu/show_commands
#
# @within	survirec:v1.3.2/api/commands
#

tellraw @s {text:"══ Commandes à copier ══",color:"gold"}
tellraw @s [{text:"   Enregistrer  ",color:"gray"},{text:"[Copier]",color:"yellow",click_event:{action:"copy_to_clipboard",value:'/function #survirec:v1/start {with:{name:"walk",every:4}}'},hover_event:{action:"show_text",value:'/function #survirec:v1/start {with:{name:"walk",every:4}}'}}]
tellraw @s [{text:"   Rejouer ici  ",color:"gray"},{text:"[Copier]",color:"yellow",click_event:{action:"copy_to_clipboard",value:'/function #survirec:v1/play {with:{name:"walk"}}'},hover_event:{action:"show_text",value:'/function #survirec:v1/play {with:{name:"walk"}}'}}]
tellraw @s [{text:"   Épreuve (command block)  ",color:"gray"},{text:"[Copier]",color:"yellow",click_event:{action:"copy_to_clipboard",value:'execute as @p run function #survirec:v1/challenge {with:{id:"epreuve1",time:30,group:"salle1"}}'},hover_event:{action:"show_text",value:'execute as @p run function #survirec:v1/challenge {with:{id:"epreuve1",time:30,group:"salle1"}}'}}]
tellraw @s [{text:"   Donner le menu (command block)  ",color:"gray"},{text:"[Copier]",color:"yellow",click_event:{action:"copy_to_clipboard",value:'execute as @p run function #survirec:v1/menu_item'},hover_event:{action:"show_text",value:'execute as @p run function #survirec:v1/menu_item'}}]
tellraw @s [{text:"   Ouvrir le menu  ",color:"gray"},{text:"[Copier]",color:"yellow",click_event:{action:"copy_to_clipboard",value:'/function #survirec:v1/menu'},hover_event:{action:"show_text",value:'/function #survirec:v1/menu'}}]
tellraw @s [{text:"   Mes enregistrements  ",color:"gray"},{text:"[Copier]",color:"yellow",click_event:{action:"copy_to_clipboard",value:'/function #survirec:v1/records'},hover_event:{action:"show_text",value:'/function #survirec:v1/records'}}]
tellraw @s [{text:"   Tout supprimer  ",color:"gray"},{text:"[Copier]",color:"yellow",click_event:{action:"copy_to_clipboard",value:'/function #survirec:v1/kill_all'},hover_event:{action:"show_text",value:'/function #survirec:v1/kill_all'}}]

