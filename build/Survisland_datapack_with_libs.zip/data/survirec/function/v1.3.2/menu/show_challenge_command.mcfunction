
#> survirec:v1.3.2/menu/show_challenge_command
#
# @within	survirec:v1.3.2/menu/check_challenge_time with storage survirec:call options
#
# @args		id (unknown)
#			time (unknown)
#			group (unknown)
#			sync (unknown)
#			tp_back (unknown)
#

tellraw @s {text:"------------------------------------------------",color:"dark_gray"}
$tellraw @s [{text:"🎥 "},{text:"Épreuve ",color:"green"},{text:"$(id)",color:"gold"},{text:" · $(time) s · groupe ",color:"green"},{text:"$(group)",color:"gold"}]
$tellraw @s [{text:"🎥 "},{text:"[Copier la commande]",color:"yellow",bold:true,click_event:{action:"copy_to_clipboard",value:'execute as @p run function #survirec:v1/challenge {with:{id:"$(id)",time:$(time),group:"$(group)",sync:$(sync),tp_back:$(tp_back)}}'},hover_event:{action:"show_text",value:"Colle-la dans un command block impulsion, derrière un bouton ou une plaque"}},{text:"  -> command block ",color:"gray"},{text:"impulsion",color:"gold"}]
tellraw @s {text:"------------------------------------------------",color:"dark_gray"}

