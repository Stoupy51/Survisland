
#> survirec:v1.3.2/menu/give_spyglass_item
#
# @within	survirec:v1.3.2/menu/give_item
#

give @s minecraft:carrot_on_a_stick[minecraft:custom_data={survirec:{menu:1b},smithed:{ignore:{functionality:1b,crafting:1b}}},minecraft:item_name={text:"Survirec",color:"gold",bold:true},minecraft:lore=[{text:"Clic droit : ouvrir le menu",color:"gray",italic:false}],minecraft:item_model="minecraft:spyglass"]

