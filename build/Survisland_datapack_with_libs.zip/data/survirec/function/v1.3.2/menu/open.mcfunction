
#> survirec:v1.3.2/menu/open
#
# @executed	as @a[scores={survirec.item_uses=1..}]
#
# @within	survirec:v1.3.2/tick [ as @a[scores={survirec.item_uses=1..}] ]
#

scoreboard players set @s survirec.item_uses 0
dialog show @s survirec:menu

