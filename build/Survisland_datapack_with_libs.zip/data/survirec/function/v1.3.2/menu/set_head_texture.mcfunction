
#> survirec:v1.3.2/menu/set_head_texture
#
# @within	survirec:v1.3.2/load/confirm_load
#

data modify storage survirec:config menu.texture set value "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMWI0MWQwZmZjOTg4MjVkYWM2MzZhZmJjZjYxMzU3MmRmZTBkMTg0MGYyZDA2OGZlNDNhMjViMGQzYjYwOTA4YSJ9fX0="

