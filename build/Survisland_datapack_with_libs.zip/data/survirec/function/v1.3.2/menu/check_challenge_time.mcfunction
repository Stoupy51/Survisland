
#> survirec:v1.3.2/menu/check_challenge_time
#
# @within	survirec:v1.3.2/api/challenge_cmd with storage survirec:call options
#
# @args		time (unknown)
#

# the duration must be a whole number of seconds
$scoreboard players set #challenge_time survirec.data $(time)
execute unless score #challenge_time survirec.data matches 1.. run return run tellraw @s [{text:"🎥 "},{text:"La durée doit être un nombre de secondes (1 ou plus).",color:"red"}]
execute store result storage survirec:call options.time int 1 run scoreboard players get #challenge_time survirec.data
function survirec:v1.3.2/menu/show_challenge_command with storage survirec:call options

