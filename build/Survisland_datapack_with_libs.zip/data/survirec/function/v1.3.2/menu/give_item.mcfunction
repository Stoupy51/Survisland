
#> survirec:v1.3.2/menu/give_item
#
# @within	survirec:v1.3.2/api/menu_item
#

execute unless entity @s[type=minecraft:player] run return fail
clear @s minecraft:carrot_on_a_stick[minecraft:custom_data~{survirec:{menu:1b}}]
execute if data storage survirec:config menu{texture:""} run return run function survirec:v1.3.2/menu/give_spyglass_item
function survirec:v1.3.2/menu/give_head_item with storage survirec:config menu

