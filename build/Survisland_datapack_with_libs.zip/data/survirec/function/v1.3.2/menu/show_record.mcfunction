
#> survirec:v1.3.2/menu/show_record
#
# @within	survirec:v1.3.2/menu/list_next_record with storage survirec:recording names_left[0]
#
# @args		name (unknown)
#

scoreboard players add #record_count survirec.data 1
$tellraw @s [{text:"   • ",color:"gray"},{text:"$(name)",color:"aqua",bold:true},{text:"   "},{text:"[Jouer ici]",color:"green",bold:true,click_event:{action:"run_command",command:'/function #survirec:v1/play {with:{name:"$(name)"}}'},hover_event:{action:"show_text",value:"Fait apparaître un mannequin à ta position"}},{text:"  "},{text:"[📋 Copier]",color:"yellow",bold:true,click_event:{action:"run_command",command:'/function #survirec:v1/export {with:{name:"$(name)"}}'},hover_event:{action:"show_text",value:"Réaffiche les boutons de copie pour un command block"}},{text:"  "},{text:"[🗑]",color:"red",bold:true,click_event:{action:"suggest_command",command:'/function #survirec:v1/forget {with:{name:"$(name)"}}'},hover_event:{action:"show_text",value:"Supprimer (appuie sur Entrée pour confirmer)"}}]

