
#> survirec:v1.3.2/block/find_support
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/use/press_button
#			survirec:v1.3.2/use/toggle_lever
#

# at a button or lever read by block/read: offset to the block it is attached to
data modify storage survirec:playback support_offset set value {x:0,y:0,z:0}
execute if score #block_face survirec.data matches 1 run data modify storage survirec:playback support_offset.y set value -1
execute if score #block_face survirec.data matches 2 run data modify storage survirec:playback support_offset.y set value 1
execute if score #block_face survirec.data matches 3 if score #block_facing survirec.data matches 1 run data modify storage survirec:playback support_offset.z set value 1
execute if score #block_face survirec.data matches 3 if score #block_facing survirec.data matches 2 run data modify storage survirec:playback support_offset.z set value -1
execute if score #block_face survirec.data matches 3 if score #block_facing survirec.data matches 3 run data modify storage survirec:playback support_offset.x set value -1
execute if score #block_face survirec.data matches 3 if score #block_facing survirec.data matches 4 run data modify storage survirec:playback support_offset.x set value 1

