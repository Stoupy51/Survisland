
#> survirec:v1.3.2/block/store_support_position
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/block/mark_support
#

execute store result storage survirec:playback release.support_x int 1 run data get entity @s Pos[0]
execute store result storage survirec:playback release.support_y int 1 run data get entity @s Pos[1]
execute store result storage survirec:playback release.support_z int 1 run data get entity @s Pos[2]
kill @s

