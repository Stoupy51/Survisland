
#> survirec:v1.3.2/block/update_support
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/block/update_support_at
#			survirec:v1.3.2/release/release_button
#

execute unless data storage survirec:config are_blocks_ready run return 0
clone ~ ~ ~ ~ ~ ~ to survirec:vault 15 319 15 strict
setblock ~ ~ ~ minecraft:barrier strict
clone from survirec:vault 15 319 15 15 319 15 ~ ~ ~

