
#> survirec:v1.3.2/block/set_state_strict
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/use/toggle_door with storage survirec:block
#			survirec:v1.3.2/use/toggle_door_half with storage survirec:block
#
# @args		state (unknown)
#

$setblock ~ ~ ~ $(state) strict

