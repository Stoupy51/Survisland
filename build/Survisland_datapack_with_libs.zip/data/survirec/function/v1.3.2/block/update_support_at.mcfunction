
#> survirec:v1.3.2/block/update_support_at
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/use/press_button with storage survirec:playback support_offset
#			survirec:v1.3.2/use/toggle_lever with storage survirec:playback support_offset
#
# @args		x (int)
#			y (int)
#			z (int)
#

$execute positioned ~$(x) ~$(y) ~$(z) run function survirec:v1.3.2/block/update_support

