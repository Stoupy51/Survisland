
#> survirec:v1.3.2/block/set_state
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/use/press_button with storage survirec:block
#			survirec:v1.3.2/use/toggle_lever with storage survirec:block
#			survirec:v1.3.2/use/toggle_open with storage survirec:block
#
# @args		state (unknown)
#

$setblock ~ ~ ~ $(state)

