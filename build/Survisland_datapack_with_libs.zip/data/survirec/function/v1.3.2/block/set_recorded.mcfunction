
#> survirec:v1.3.2/block/set_recorded
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/place_block with storage survirec:playback event
#
# @args		b (unknown)
#

$setblock ~ ~ ~ $(b)

