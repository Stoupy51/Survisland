
#> survirec:v1.3.2/block/mark_support
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/use/press_button with storage survirec:playback support_offset
#
# @args		x (int)
#			y (int)
#			z (int)
#

$execute positioned ~$(x) ~$(y) ~$(z) summon minecraft:marker run function survirec:v1.3.2/block/store_support_position

