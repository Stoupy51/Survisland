
#> survirec:v1.3.2/block/find_other_half
#
# @executed	at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1]
#
# @within	survirec:v1.3.2/record/note_placed_block
#			survirec:v1.3.2/action/break_block
#			survirec:v1.3.2/use/toggle_door
#

# door, bed or tall plant: #is_pair 1 and the offset to the other half in #pair_x #pair_y #pair_z
scoreboard players set #is_pair survirec.data 0
scoreboard players set #pair_x survirec.data 0
scoreboard players set #pair_y survirec.data 0
scoreboard players set #pair_z survirec.data 0
execute if score #block_half survirec.data matches 2 run scoreboard players set #pair_y survirec.data 1
execute if score #block_half survirec.data matches 1 run scoreboard players set #pair_y survirec.data -1
execute if score #block_half survirec.data matches 1..2 run scoreboard players set #is_pair survirec.data 1
execute if score #block_part survirec.data matches 1..2 run scoreboard players set #is_pair survirec.data 1
execute if score #block_part survirec.data matches 1..2 if score #block_facing survirec.data matches 1 run scoreboard players set #pair_z survirec.data -1
execute if score #block_part survirec.data matches 1..2 if score #block_facing survirec.data matches 2 run scoreboard players set #pair_z survirec.data 1
execute if score #block_part survirec.data matches 1..2 if score #block_facing survirec.data matches 3 run scoreboard players set #pair_x survirec.data 1
execute if score #block_part survirec.data matches 1..2 if score #block_facing survirec.data matches 4 run scoreboard players set #pair_x survirec.data -1
execute if score #block_part survirec.data matches 1 run scoreboard players operation #pair_x survirec.data *= #-1 survirec.data
execute if score #block_part survirec.data matches 1 run scoreboard players operation #pair_z survirec.data *= #-1 survirec.data

