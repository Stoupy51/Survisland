
#> survirec:v1.3.2/block/read
#
# @executed	at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1]
#
# @within	survirec:v1.3.2/record/note_placed_block
#			survirec:v1.3.2/record/read_other_half
#			survirec:v1.3.2/action/break_block
#			survirec:v1.3.2/action/use_block
#			survirec:v1.3.2/use/toggle_door_half
#

# survirec:block id is "" for air; bs:out block keeps the full block, editable with #bs.block:replace_properties
data modify storage survirec:block id set value ""
scoreboard players set #block_facing survirec.data 0
scoreboard players set #block_half survirec.data 0
scoreboard players set #block_part survirec.data 0
scoreboard players set #block_face survirec.data 0
scoreboard players set #block_open survirec.data 0
scoreboard players set #block_powered survirec.data 0
execute if block ~ ~ ~ #minecraft:air run return fail
function #bs.block:get_block
data modify storage survirec:block id set from storage bs:out block.type
execute if data storage bs:out block.properties{facing:"north"} run scoreboard players set #block_facing survirec.data 1
execute if data storage bs:out block.properties{facing:"south"} run scoreboard players set #block_facing survirec.data 2
execute if data storage bs:out block.properties{facing:"east"} run scoreboard players set #block_facing survirec.data 3
execute if data storage bs:out block.properties{facing:"west"} run scoreboard players set #block_facing survirec.data 4
execute if data storage bs:out block.properties{facing:"up"} run scoreboard players set #block_facing survirec.data 5
execute if data storage bs:out block.properties{facing:"down"} run scoreboard players set #block_facing survirec.data 6
execute if data storage bs:out block.properties{half:"upper"} run scoreboard players set #block_half survirec.data 1
execute if data storage bs:out block.properties{half:"lower"} run scoreboard players set #block_half survirec.data 2
execute if data storage bs:out block.properties{part:"head"} run scoreboard players set #block_part survirec.data 1
execute if data storage bs:out block.properties{part:"foot"} run scoreboard players set #block_part survirec.data 2
execute if data storage bs:out block.properties{face:"floor"} run scoreboard players set #block_face survirec.data 1
execute if data storage bs:out block.properties{face:"ceiling"} run scoreboard players set #block_face survirec.data 2
execute if data storage bs:out block.properties{face:"wall"} run scoreboard players set #block_face survirec.data 3
execute if data storage bs:out block.properties{open:"true"} run scoreboard players set #block_open survirec.data 1
execute if data storage bs:out block.properties{powered:"true"} run scoreboard players set #block_powered survirec.data 1

