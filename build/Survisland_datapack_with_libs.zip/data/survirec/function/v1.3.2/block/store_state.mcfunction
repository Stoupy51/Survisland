
#> survirec:v1.3.2/block/store_state
#
# @executed	at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1]
#
# @within	survirec:v1.3.2/record/note_placed_block
#			survirec:v1.3.2/record/read_other_half
#			survirec:v1.3.2/use/press_button
#			survirec:v1.3.2/use/toggle_door
#			survirec:v1.3.2/use/toggle_door_half
#			survirec:v1.3.2/use/toggle_lever
#			survirec:v1.3.2/use/toggle_open
#

# "id[state]" without NBT, ready for setblock
data modify storage survirec:block state set from storage bs:out block.block

