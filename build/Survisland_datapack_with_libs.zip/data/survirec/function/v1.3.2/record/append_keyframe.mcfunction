
#> survirec:v1.3.2/record/append_keyframe
#
# @within	survirec:v1.3.2/record/walk_back_step
#			survirec:v1.3.2/record/capture_keyframe
#

data modify storage survirec:recording keyframe set value [0,0,0,0,0,0]
execute unless score #delta_x survirec.data matches 0 store result storage survirec:recording keyframe[0] int 1 run scoreboard players get #delta_x survirec.data
execute unless score #delta_y survirec.data matches 0 store result storage survirec:recording keyframe[1] int 1 run scoreboard players get #delta_y survirec.data
execute unless score #delta_z survirec.data matches 0 store result storage survirec:recording keyframe[2] int 1 run scoreboard players get #delta_z survirec.data
execute unless score #delta_yaw survirec.data matches 0 store result storage survirec:recording keyframe[3] int 1 run scoreboard players get #delta_yaw survirec.data
execute unless score #delta_pitch survirec.data matches 0 store result storage survirec:recording keyframe[4] int 1 run scoreboard players get #delta_pitch survirec.data
execute unless score #flags survirec.data matches 0 store result storage survirec:recording keyframe[5] int 1 run scoreboard players get #flags survirec.data
function survirec:v1.3.2/record/push_keyframe with storage survirec:recorder
scoreboard players add @s survirec.recorded_keyframes 1
scoreboard players add @s survirec.chunk_keyframes 1
execute if score @s survirec.chunk_keyframes matches 300.. run function survirec:v1.3.2/record/store_keyframe_chunk with storage survirec:recorder

