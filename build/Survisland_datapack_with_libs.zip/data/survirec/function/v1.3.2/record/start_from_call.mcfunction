
#> survirec:v1.3.2/record/start_from_call
#
# @within	survirec:v1.3.2/api/start with storage survirec:call options
#
# @args		every (unknown)
#			name (unknown)
#			group (unknown)
#			group_radius (unknown)
#

execute unless entity @s[type=minecraft:player] run return fail
execute if entity @s[tag=survirec.recording] run return run tellraw @s [{text:"🎥 "},{text:"Tu es déjà en train d'enregistrer (",color:"red"},{text:"#survirec:v1/stop",color:"gold"},{text:").",color:"red"}]
execute if entity @s[tag=survirec.armed] run return run tellraw @s [{text:"🎥 "},{text:"Ton enregistrement est déjà armé (",color:"red"},{text:"#survirec:v1/abort",color:"gold"},{text:" pour l'annuler).",color:"red"}]
$scoreboard players set #keyframe_step survirec.data $(every)
execute unless score #keyframe_step survirec.data matches 1..100 run return run tellraw @s [{text:"🎥 "},{text:"every doit être entre 1 et 100.",color:"red"}]
$data modify storage survirec:recording meta set value {name:"$(name)",keyframe_step:$(every),group:"$(group)",group_radius:$(group_radius)}
execute if data storage survirec:call options{group:""} run return run function survirec:v1.3.2/record/begin
function survirec:v1.3.2/record/arm_with_nearest_group with storage survirec:call options

