
#> survirec:v1.3.2/record/on_stop_item_click
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/tick
#

scoreboard players set @s survirec.item_uses 0
execute if score #is_sneaking survirec.data matches 1 run return run function survirec:v1.3.2/record/stop_with_walk_back
function survirec:v1.3.2/record/finish

