
#> survirec:v1.3.2/record/give_stop_item_in
#
# @within	survirec:v1.3.2/record/give_stop_item {slot:"weapon.mainhand"}
#			survirec:v1.3.2/record/give_stop_item {slot:"hotbar.0"}
#			survirec:v1.3.2/record/give_stop_item {slot:"hotbar.1"}
#			survirec:v1.3.2/record/give_stop_item {slot:"hotbar.2"}
#			survirec:v1.3.2/record/give_stop_item {slot:"hotbar.3"}
#			survirec:v1.3.2/record/give_stop_item {slot:"hotbar.4"}
#			survirec:v1.3.2/record/give_stop_item {slot:"hotbar.5"}
#			survirec:v1.3.2/record/give_stop_item {slot:"hotbar.6"}
#			survirec:v1.3.2/record/give_stop_item {slot:"hotbar.7"}
#			survirec:v1.3.2/record/give_stop_item {slot:"hotbar.8"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.0"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.1"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.2"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.3"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.4"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.5"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.6"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.7"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.8"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.9"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.10"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.11"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.12"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.13"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.14"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.15"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.16"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.17"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.18"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.19"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.20"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.21"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.22"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.23"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.24"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.25"}
#			survirec:v1.3.2/record/give_stop_item {slot:"inventory.26"}
#
# @args		slot (string)
#

$item replace entity @s $(slot) with minecraft:carrot_on_a_stick[minecraft:custom_data={survirec:{stop:1b},smithed:{ignore:{everything:1b}}},minecraft:item_name={text:"Arrêter l'enregistrement",color:"red"},minecraft:item_model="minecraft:barrier"]
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{survirec:{stop:1b}}] run return run tellraw @s [{text:"🎥 "},{text:"Barrière en main : clic droit = stop.",color:"green"}]
tellraw @s [{text:"🎥 "},{text:"Barrière ajoutée à ton inventaire : prends-la en main, clic droit = stop.",color:"green"}]

