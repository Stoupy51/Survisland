
#> survirec:v1.3.2/record/note_place
#
# @executed	as the player & at current position
#
# @within	survirec:v1.3.2/record/trigger/place
#

scoreboard players set @s survirec.has_placed 1
function survirec:v1.3.2/record/store_player_id
function survirec:v1.3.2/record/snapshot_looked_cube
function survirec:v1.3.2/record/cast_from_eyes
execute if score #ray_hit survirec.data matches 1 at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] run function survirec:v1.3.2/record/note_placed_block
tag @e[type=minecraft:marker,tag=survirec.ray_cursor] remove survirec.ray_cursor

