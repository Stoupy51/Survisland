
#> survirec:v1.3.2/record/look
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/tick
#

# a block looked at last tick that is now air was broken by the player
scoreboard players operation #player_id survirec.data = @s survirec.player_id
execute as @e[type=minecraft:marker,tag=survirec.look_marker] if score @s survirec.player_id = #player_id survirec.data run tag @s add survirec.ray_cursor
scoreboard players set #has_broken survirec.data 0
execute if score @s survirec.is_looking_at_block matches 1 at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] if block ~ ~ ~ #minecraft:air run scoreboard players set #has_broken survirec.data 1
execute if score #has_broken survirec.data matches 1 run function survirec:v1.3.2/record/note_break
scoreboard players set @s survirec.is_looking_at_block 0
scoreboard players set #ray_steps survirec.data 0
scoreboard players set #ray_hit survirec.data 0
execute anchored eyes positioned ^ ^ ^ run function survirec:v1.3.2/record/ray_step
execute if score #ray_hit survirec.data matches 1 run scoreboard players set @s survirec.is_looking_at_block 1
execute if score #ray_hit survirec.data matches 1 if data storage survirec:config are_cubes_ready run function survirec:v1.3.2/record/copy_looked_cube
tag @e[type=minecraft:marker,tag=survirec.ray_cursor] remove survirec.ray_cursor

