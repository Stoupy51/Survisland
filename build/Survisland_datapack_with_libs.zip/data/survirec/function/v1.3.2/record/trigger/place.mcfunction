
#> survirec:v1.3.2/record/trigger/place
#
# @executed	as the player & at current position
#
# @within	advancement survirec:v1.3.2/record/trigger/place
#

advancement revoke @s only survirec:v1.3.2/record/trigger/place
execute if score #survirec.major load.status matches 1 if score #survirec.minor load.status matches 3 if score #survirec.patch load.status matches 2 if entity @s[tag=survirec.recording] run function survirec:v1.3.2/record/note_place

