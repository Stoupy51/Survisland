
#> survirec:v1.3.2/record/export_last_part
#
# @within	survirec:v1.3.2/record/export_block
#

data modify storage survirec:recording export.keyframes set from storage survirec:recording chunks[0]
data remove storage survirec:recording chunks[0]
data modify storage survirec:recording export.equipment set value []
data modify storage survirec:recording export.swings set value []
data modify storage survirec:recording export.actions set value []
execute if score #is_split survirec.data matches 0 run data modify storage survirec:recording export.equipment set from storage survirec:recording e
execute if score #is_split survirec.data matches 0 run data modify storage survirec:recording export.swings set from storage survirec:recording s
execute if score #is_split survirec.data matches 0 run data modify storage survirec:recording export.actions set from storage survirec:recording a
function survirec:v1.3.2/record/show_playback_button with storage survirec:recording export

