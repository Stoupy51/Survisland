
#> survirec:v1.3.2/record/launch_armed
#
# @executed	as @a[tag=survirec.armed]
#
# @within	survirec:v1.3.2/challenge/launch
#

tag @s remove survirec.armed
title @s actionbar {text:""}
function survirec:v1.3.2/record/store_player_id
function survirec:v1.3.2/record/load_armed_info with storage survirec:recorder
function survirec:v1.3.2/record/begin

