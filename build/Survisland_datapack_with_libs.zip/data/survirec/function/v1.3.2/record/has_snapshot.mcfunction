
#> survirec:v1.3.2/record/has_snapshot
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/snapshot_looked_cube with storage survirec:recording snapshot
#
# @args		player_id (unknown)
#			x (unknown)
#			y (unknown)
#			z (unknown)
#

$execute if data storage survirec:in_progress players.p$(player_id).world_backups[{x:$(x),y:$(y),z:$(z)}] run scoreboard players set #has_snapshot survirec.data 1

