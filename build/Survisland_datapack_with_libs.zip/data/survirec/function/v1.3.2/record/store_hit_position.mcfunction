
#> survirec:v1.3.2/record/store_hit_position
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/note_break
#			survirec:v1.3.2/record/note_placed_block
#

# block hit by the ray, relative to the start block of the recording
execute store result score #hit_x survirec.data run data get entity @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] Pos[0]
scoreboard players operation #hit_x survirec.data -= @s survirec.record_block_x
execute store result storage survirec:recording event.x int 1 run scoreboard players get #hit_x survirec.data
execute store result score #hit_y survirec.data run data get entity @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] Pos[1]
scoreboard players operation #hit_y survirec.data -= @s survirec.record_block_y
execute store result storage survirec:recording event.y int 1 run scoreboard players get #hit_y survirec.data
execute store result score #hit_z survirec.data run data get entity @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] Pos[2]
scoreboard players operation #hit_z survirec.data -= @s survirec.record_block_z
execute store result storage survirec:recording event.z int 1 run scoreboard players get #hit_z survirec.data

