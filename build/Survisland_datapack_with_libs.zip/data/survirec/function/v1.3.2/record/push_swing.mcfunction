
#> survirec:v1.3.2/record/push_swing
#
# @executed	as the player & at current position
#
# @within	survirec:v1.3.2/record/note_swing with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data modify storage survirec:in_progress players.p$(player_id).s append value 0
$execute store result storage survirec:in_progress players.p$(player_id).s[-1] int 1 run scoreboard players get @s survirec.record_tick

