
#> survirec:v1.3.2/record/store_player_id
#
# @within	survirec:v1.3.2/record/abort
#			survirec:v1.3.2/record/arm
#			survirec:v1.3.2/record/note_hit
#			survirec:v1.3.2/record/prepare_walk_back
#			survirec:v1.3.2/record/init
#			survirec:v1.3.2/record/launch_armed
#			survirec:v1.3.2/record/note_place
#			survirec:v1.3.2/record/pull_state
#			survirec:v1.3.2/record/note_swing
#			survirec:v1.3.2/record/tick
#			survirec:v1.3.2/record/restore_world
#			survirec:v1.3.2/challenge/start
#

execute store result storage survirec:recorder player_id int 1 run scoreboard players get @s survirec.player_id

