
#> survirec:v1.3.2/record/copy_looked_cube
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/look
#

execute store result storage survirec:recording looked_cube.x int 1 run scoreboard players get @s survirec.look_cube_x
execute store result storage survirec:recording looked_cube.y int 1 run scoreboard players get @s survirec.look_cube_y
execute store result storage survirec:recording looked_cube.z int 1 run scoreboard players get @s survirec.look_cube_z
function survirec:v1.3.2/record/copy_looked_cube_to with storage survirec:recording looked_cube

