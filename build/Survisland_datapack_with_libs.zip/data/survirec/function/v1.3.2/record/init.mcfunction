
#> survirec:v1.3.2/record/init
#
# @within	survirec:v1.3.2/record/begin
#			survirec:v1.3.2/challenge/begin
#

# starts a recording for @s; survirec:recording meta = {name, n} set by the caller
execute unless score @s survirec.player_id matches 1.. run function survirec:v1.3.2/player/new_id
function survirec:v1.3.2/record/store_player_id
tag @s add survirec.recording
scoreboard players set @s survirec.is_challenge 0
execute store result score @s survirec.keyframe_step run data get storage survirec:recording meta.keyframe_step
scoreboard players set @s survirec.chunk_keyframes 0
scoreboard players set @s survirec.recorded_keyframes 0
scoreboard players set @s survirec.ticks_since_keyframe 0
scoreboard players set @s survirec.record_tick 0
scoreboard players set @s survirec.last_swing_tick -1
# read on a marker in the place of the player: reading the player itself would serialize its whole inventory, 5 times
tag @s add survirec.position_being_read
execute at @s summon minecraft:marker run function survirec:v1.3.2/record/read_player_position
tag @s remove survirec.position_being_read
scoreboard players operation @s survirec.recorded_x = #current_x survirec.data
scoreboard players operation @s survirec.recorded_y = #current_y survirec.data
scoreboard players operation @s survirec.recorded_z = #current_z survirec.data
scoreboard players operation @s survirec.recorded_yaw = #current_yaw survirec.data
scoreboard players operation @s survirec.recorded_pitch = #current_pitch survirec.data
scoreboard players operation @s survirec.record_start_x = @s survirec.recorded_x
scoreboard players operation @s survirec.record_start_y = @s survirec.recorded_y
scoreboard players operation @s survirec.record_start_z = @s survirec.recorded_z
scoreboard players operation @s survirec.record_start_yaw = @s survirec.recorded_yaw
scoreboard players operation @s survirec.record_start_pitch = @s survirec.recorded_pitch
execute store result storage survirec:recording meta.yaw int 1 run scoreboard players get @s survirec.recorded_yaw
execute store result storage survirec:recording meta.pitch int 1 run scoreboard players get @s survirec.recorded_pitch
execute store result storage survirec:recording meta.start_x double 0.001 run scoreboard players get @s survirec.recorded_x
execute store result storage survirec:recording meta.start_y double 0.001 run scoreboard players get @s survirec.recorded_y
execute store result storage survirec:recording meta.start_z double 0.001 run scoreboard players get @s survirec.recorded_z
function survirec:v1.3.2/record/init_state with storage survirec:recorder
function survirec:v1.3.2/record/init_actions
scoreboard players set @s survirec.item_uses 0
function survirec:v1.3.2/record/capture_equipment

