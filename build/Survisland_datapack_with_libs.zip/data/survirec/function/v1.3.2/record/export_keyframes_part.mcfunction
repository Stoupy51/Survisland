
#> survirec:v1.3.2/record/export_keyframes_part
#
# @within	survirec:v1.3.2/record/export_block
#

data modify storage survirec:recording export.keyframes set from storage survirec:recording chunks[0]
data remove storage survirec:recording chunks[0]
function survirec:v1.3.2/record/show_part_button with storage survirec:recording export

