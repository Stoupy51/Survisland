
#> survirec:v1.3.2/record/capture_keyframe
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/tick
#

scoreboard players set @s survirec.ticks_since_keyframe 0
# read on a marker in the place of the player: reading the player itself would serialize its whole inventory, 5 times
tag @s add survirec.position_being_read
execute at @s summon minecraft:marker run function survirec:v1.3.2/record/read_player_position
tag @s remove survirec.position_being_read
scoreboard players operation #delta_x survirec.data = #current_x survirec.data
scoreboard players operation #delta_x survirec.data -= @s survirec.recorded_x
scoreboard players operation #delta_y survirec.data = #current_y survirec.data
scoreboard players operation #delta_y survirec.data -= @s survirec.recorded_y
scoreboard players operation #delta_z survirec.data = #current_z survirec.data
scoreboard players operation #delta_z survirec.data -= @s survirec.recorded_z
scoreboard players operation #delta_yaw survirec.data = #current_yaw survirec.data
scoreboard players operation #delta_yaw survirec.data -= @s survirec.recorded_yaw
execute if score #delta_yaw survirec.data matches 18001.. run scoreboard players remove #delta_yaw survirec.data 36000
execute if score #delta_yaw survirec.data matches ..-18001 run scoreboard players add #delta_yaw survirec.data 36000
scoreboard players operation #delta_pitch survirec.data = #current_pitch survirec.data
scoreboard players operation #delta_pitch survirec.data -= @s survirec.recorded_pitch
scoreboard players operation @s survirec.recorded_x = #current_x survirec.data
scoreboard players operation @s survirec.recorded_y = #current_y survirec.data
scoreboard players operation @s survirec.recorded_z = #current_z survirec.data
scoreboard players operation @s survirec.recorded_yaw = #current_yaw survirec.data
scoreboard players operation @s survirec.recorded_pitch = #current_pitch survirec.data
function survirec:v1.3.2/record/append_keyframe

