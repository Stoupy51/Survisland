
#> survirec:v1.3.2/record/push_event
#
# @executed	as the player & at current position
#
# @within	survirec:v1.3.2/record/note_hit with storage survirec:recorder
#			survirec:v1.3.2/record/note_break with storage survirec:recorder
#			survirec:v1.3.2/record/note_placed_block with storage survirec:recorder
#			survirec:v1.3.2/record/push_use with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data modify storage survirec:in_progress players.p$(player_id).a append from storage survirec:recording event

