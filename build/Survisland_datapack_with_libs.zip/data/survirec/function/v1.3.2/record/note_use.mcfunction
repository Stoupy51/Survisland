
#> survirec:v1.3.2/record/note_use
#
# @executed	as the player & at current position
#
# @within	survirec:v1.3.2/record/trigger/use
#

function survirec:v1.3.2/record/cast_from_eyes
execute if score #ray_hit survirec.data matches 1 at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] if block ~ ~ ~ #survirec:interactive run function survirec:v1.3.2/record/note_used_block
tag @e[type=minecraft:marker,tag=survirec.ray_cursor] remove survirec.ray_cursor

