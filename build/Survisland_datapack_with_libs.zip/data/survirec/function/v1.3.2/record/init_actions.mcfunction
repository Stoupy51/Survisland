
#> survirec:v1.3.2/record/init_actions
#
# @within	survirec:v1.3.2/record/init
#

# markers of the look ray, start block, and the vault cube (chunk 2) holding what the player looks at
scoreboard players operation #player_id survirec.data = @s survirec.player_id
function survirec:v1.3.2/record/kill_markers
execute at @s run summon minecraft:marker ~ ~ ~ {Tags:["survirec.recorder_marker","survirec.look_marker","survirec.new_recorder_marker","smithed.entity","smithed.strict"]}
execute at @s run summon minecraft:marker ~ ~ ~ {Tags:["survirec.recorder_marker","survirec.ray_marker","survirec.new_recorder_marker","smithed.entity","smithed.strict"]}
scoreboard players operation @e[type=minecraft:marker,tag=survirec.new_recorder_marker] survirec.player_id = #player_id survirec.data
tag @e[type=minecraft:marker,tag=survirec.new_recorder_marker] remove survirec.new_recorder_marker
execute store result score @s survirec.record_block_x run data get entity @s Pos[0]
execute store result score @s survirec.record_block_y run data get entity @s Pos[1]
execute store result score @s survirec.record_block_z run data get entity @s Pos[2]
scoreboard players set @s survirec.is_looking_at_block 0
scoreboard players set @s survirec.has_pending_use 0
scoreboard players set @s survirec.has_placed 0
scoreboard players set @s survirec.last_hit_tick -1
scoreboard players operation #cube_index survirec.data = @s survirec.player_id
scoreboard players operation #cube_index survirec.data %= #1536 survirec.data
function survirec:v1.3.2/record/find_cube_corner
scoreboard players operation @s survirec.look_cube_x = #cube_x survirec.data
scoreboard players add @s survirec.look_cube_x 16
scoreboard players operation @s survirec.look_cube_y = #cube_y survirec.data
scoreboard players operation @s survirec.look_cube_z = #cube_z survirec.data
scoreboard players add @s survirec.sneak_time 0
scoreboard players operation @s survirec.previous_sneak_time = @s survirec.sneak_time
scoreboard players add @s survirec.swim_distance 0
scoreboard players operation @s survirec.previous_swim_distance = @s survirec.swim_distance
scoreboard players add @s survirec.glide_distance 0
scoreboard players operation @s survirec.previous_glide_distance = @s survirec.glide_distance

