
#> survirec:v1.3.2/record/pull_state_of
#
# @within	survirec:v1.3.2/record/pull_state with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data modify storage survirec:recording meta set from storage survirec:in_progress players.p$(player_id).meta
$data modify storage survirec:recording d set from storage survirec:in_progress players.p$(player_id).d
$data modify storage survirec:recording chunks set from storage survirec:in_progress players.p$(player_id).chunks
$data modify storage survirec:recording e set from storage survirec:in_progress players.p$(player_id).e
$data modify storage survirec:recording s set from storage survirec:in_progress players.p$(player_id).s
$data modify storage survirec:recording a set from storage survirec:in_progress players.p$(player_id).a
$data modify storage survirec:challenge id set from storage survirec:in_progress players.p$(player_id).challenge.id
$data modify storage survirec:challenge time set from storage survirec:in_progress players.p$(player_id).challenge.time
$data modify storage survirec:challenge group set from storage survirec:in_progress players.p$(player_id).challenge.group
$data modify storage survirec:challenge sync set from storage survirec:in_progress players.p$(player_id).challenge.sync
$data modify storage survirec:challenge tp_back set from storage survirec:in_progress players.p$(player_id).challenge.tp_back
$data modify storage survirec:challenge player_id set from storage survirec:in_progress players.p$(player_id).challenge.player_id
$data modify storage survirec:challenge group_id set from storage survirec:in_progress players.p$(player_id).challenge.group_id

