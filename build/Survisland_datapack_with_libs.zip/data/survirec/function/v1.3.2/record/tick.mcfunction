
#> survirec:v1.3.2/record/tick
#
# @executed	at @s
#
# @within	survirec:v1.3.2/tick [ at @s ]
#

function survirec:v1.3.2/record/store_player_id
execute if score @s survirec.has_pending_use matches 1 run function survirec:v1.3.2/record/push_use
scoreboard players set @s survirec.has_placed 0
function survirec:v1.3.2/record/look
scoreboard players set #flags survirec.data 0
scoreboard players set #is_sneaking survirec.data 0
execute if score @s survirec.sneak_time > @s survirec.previous_sneak_time run scoreboard players set #is_sneaking survirec.data 1
execute if score #is_sneaking survirec.data matches 1 run scoreboard players add #flags survirec.data 1
execute if score @s survirec.swim_distance > @s survirec.previous_swim_distance run scoreboard players add #flags survirec.data 2
execute if score @s survirec.glide_distance > @s survirec.previous_glide_distance run scoreboard players add #flags survirec.data 4
scoreboard players operation @s survirec.previous_sneak_time = @s survirec.sneak_time
scoreboard players operation @s survirec.previous_swim_distance = @s survirec.swim_distance
scoreboard players operation @s survirec.previous_glide_distance = @s survirec.glide_distance
execute unless score @s survirec.is_challenge matches 1 if score @s survirec.item_uses matches 1.. if items entity @s weapon.* minecraft:carrot_on_a_stick[minecraft:custom_data~{survirec:{stop:1b}}] run return run function survirec:v1.3.2/record/on_stop_item_click
scoreboard players set @s survirec.item_uses 0
scoreboard players add @s survirec.record_tick 1
execute if score @s survirec.is_challenge matches 1 if score @s survirec.record_tick >= @s survirec.challenge_ticks run return run function survirec:v1.3.2/challenge/end
scoreboard players operation #tick_mod survirec.data = @s survirec.record_tick
scoreboard players operation #tick_mod survirec.data %= #10 survirec.data
execute if score #tick_mod survirec.data matches 0 run function survirec:v1.3.2/record/show_hud
scoreboard players operation #tick_mod survirec.data = @s survirec.record_tick
scoreboard players operation #tick_mod survirec.data %= #20 survirec.data
execute if score #tick_mod survirec.data matches 0 run function survirec:v1.3.2/record/capture_equipment
scoreboard players add @s survirec.ticks_since_keyframe 1
execute if score @s survirec.ticks_since_keyframe >= @s survirec.keyframe_step run function survirec:v1.3.2/record/capture_keyframe

