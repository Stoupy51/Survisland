
#> survirec:v1.3.2/record/note_hit
#
# @executed	as the player & at current position
#
# @within	survirec:v1.3.2/record/trigger/attack
#

execute if score @s survirec.last_hit_tick = @s survirec.record_tick run return 0
scoreboard players operation @s survirec.last_hit_tick = @s survirec.record_tick
function survirec:v1.3.2/record/store_player_id
data modify storage survirec:recording event set value {t:0,k:1}
execute store result storage survirec:recording event.t int 1 run scoreboard players get @s survirec.record_tick
function survirec:v1.3.2/record/push_event with storage survirec:recorder

