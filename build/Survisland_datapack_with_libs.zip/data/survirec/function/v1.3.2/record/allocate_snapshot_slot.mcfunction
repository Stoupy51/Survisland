
#> survirec:v1.3.2/record/allocate_snapshot_slot
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/snapshot_looked_cube
#

scoreboard players operation #cube_index survirec.data = #next_cube_slot survirec.data
function survirec:v1.3.2/record/find_cube_corner
scoreboard players add #next_cube_slot survirec.data 1
execute if score #next_cube_slot survirec.data matches 1536.. run scoreboard players set #next_cube_slot survirec.data 0
execute store result storage survirec:recording snapshot.cube_x int 1 run scoreboard players get #cube_x survirec.data
execute store result storage survirec:recording snapshot.cube_y int 1 run scoreboard players get #cube_y survirec.data
execute store result storage survirec:recording snapshot.cube_z int 1 run scoreboard players get #cube_z survirec.data
execute store result storage survirec:recording snapshot.cube_end_x int 1 run scoreboard players add #cube_x survirec.data 2
execute store result storage survirec:recording snapshot.cube_end_y int 1 run scoreboard players add #cube_y survirec.data 2
execute store result storage survirec:recording snapshot.cube_end_z int 1 run scoreboard players add #cube_z survirec.data 2

