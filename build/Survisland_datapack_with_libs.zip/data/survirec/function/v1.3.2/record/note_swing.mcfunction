
#> survirec:v1.3.2/record/note_swing
#
# @executed	as the player & at current position
#
# @within	survirec:v1.3.2/record/trigger/swing
#

execute if score @s survirec.last_swing_tick = @s survirec.record_tick run return 0
scoreboard players operation @s survirec.last_swing_tick = @s survirec.record_tick
function survirec:v1.3.2/record/store_player_id
function survirec:v1.3.2/record/push_swing with storage survirec:recorder

