
#> survirec:v1.3.2/record/pull_world_backups
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/restore_world with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data modify storage survirec:recording world_backups set from storage survirec:in_progress players.p$(player_id).world_backups
$data modify storage survirec:in_progress players.p$(player_id).world_backups set value []

