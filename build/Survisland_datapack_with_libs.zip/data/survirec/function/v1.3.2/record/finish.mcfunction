
#> survirec:v1.3.2/record/finish
#
# @within	survirec:v1.3.2/record/stop_player
#			survirec:v1.3.2/record/on_stop_item_click
#			survirec:v1.3.2/record/stop_with_walk_back
#

tag @s remove survirec.recording
function survirec:v1.3.2/record/restore_world
function survirec:v1.3.2/record/pull_state
function survirec:v1.3.2/record/drop_state with storage survirec:recorder
function survirec:v1.3.2/record/cleanup
function #survirec:v1/signals/on_record_stop
execute if score #keyframe_count survirec.data matches 0 run return run tellraw @s [{text:"🎥 "},{text:"Séquence vide, rien à exporter.",color:"red"}]
execute if score #chunk_keyframes survirec.data matches 1.. run data modify storage survirec:recording chunks append from storage survirec:recording d
function survirec:v1.3.2/record/save
function survirec:v1.3.2/record/export

