
#> survirec:v1.3.2/record/push_keyframe
#
# @within	survirec:v1.3.2/record/append_keyframe with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data modify storage survirec:in_progress players.p$(player_id).d append from storage survirec:recording keyframe

