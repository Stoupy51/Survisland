
#> survirec:v1.3.2/record/restore_backup
#
# @within	survirec:v1.3.2/record/restore_next_backup with storage survirec:recording world_backups[-1]
#
# @args		cube_x (unknown)
#			cube_y (unknown)
#			cube_z (unknown)
#			cube_end_x (unknown)
#			cube_end_y (unknown)
#			cube_end_z (unknown)
#			x (unknown)
#			y (unknown)
#			z (unknown)
#

$clone from survirec:vault $(cube_x) $(cube_y) $(cube_z) $(cube_end_x) $(cube_end_y) $(cube_end_z) $(x) $(y) $(z)
$execute in survirec:vault run fill $(cube_x) $(cube_y) $(cube_z) $(cube_end_x) $(cube_end_y) $(cube_end_z) minecraft:barrier strict
$data modify storage survirec:config free_cube_slots append value {cube_x:$(cube_x),cube_y:$(cube_y),cube_z:$(cube_z),cube_end_x:$(cube_end_x),cube_end_y:$(cube_end_y),cube_end_z:$(cube_end_z)}

