
#> survirec:v1.3.2/record/show_playback_button
#
# @within	survirec:v1.3.2/record/export_last_part with storage survirec:recording export
#
# @args		block_number (unknown)
#			block_kind (unknown)
#			block_color (unknown)
#			name (unknown)
#			start_x (unknown)
#			start_y (unknown)
#			start_z (unknown)
#			group (unknown)
#			group_radius (unknown)
#			is_first (unknown)
#			keyframe_step (unknown)
#			yaw (unknown)
#			pitch (unknown)
#			keyframes (unknown)
#			equipment (unknown)
#			swings (unknown)
#			actions (unknown)
#

$tellraw @s [{text:"🎥 "},{text:"command block $(block_number) · ",color:"gray"},{text:"$(block_kind)",color:"$(block_color)"},{text:" · lecture, choisis l'entité qui rejoue :",color:"gray"}]
$tellraw @s [{text:"🎥 "},{text:"[Copier $(block_number) · Mannequin]",color:"yellow",bold:true,click_event:{action:"copy_to_clipboard",value:'function #survirec:v1/play {with:{name:"$(name)",pos:"$(start_x) $(start_y) $(start_z)",entity:"minecraft:mannequin",nbt:{},range:0,size:1,loop:1,redstone:0,restore:1,hit_players:0,speed:100,delay:0,tag:"",group:"$(group)",group_radius:$(group_radius),pose:"",skin:"",texture:"",head:"",chest:"",legs:"",feet:"",mainhand:"",offhand:"",data:{f:$(is_first),n:$(keyframe_step),y:$(yaw),p:$(pitch),d:$(keyframes),e:$(equipment),s:$(swings),a:$(actions)}}}'},hover_event:{action:"show_text",value:"Clique pour copier, puis colle dans un command block"}}]
$tellraw @s [{text:"🎥 "},{text:"[Copier $(block_number) · Mob]",color:"yellow",bold:true,click_event:{action:"copy_to_clipboard",value:'function #survirec:v1/play {with:{name:"$(name)",pos:"$(start_x) $(start_y) $(start_z)",entity:"minecraft:zombie",nbt:{},range:0,size:1,loop:1,redstone:0,restore:1,hit_players:0,speed:100,delay:0,tag:"",group:"$(group)",group_radius:$(group_radius),head:"",chest:"",legs:"",feet:"",mainhand:"",offhand:"",data:{f:$(is_first),n:$(keyframe_step),y:$(yaw),p:$(pitch),d:$(keyframes),e:$(equipment),s:$(swings),a:$(actions)}}}'},hover_event:{action:"show_text",value:"Clique pour copier, puis colle dans un command block"}}]
$tellraw @s [{text:"🎥 "},{text:"[Copier $(block_number) · Objet]",color:"yellow",bold:true,click_event:{action:"copy_to_clipboard",value:'function #survirec:v1/play {with:{name:"$(name)",pos:"$(start_x) $(start_y) $(start_z)",entity:"minecraft:item_display",nbt:{item:{id:"minecraft:diamond_sword"}},range:0,size:1,loop:1,redstone:0,restore:1,speed:100,delay:0,tag:"",group:"$(group)",group_radius:$(group_radius),data:{f:$(is_first),n:$(keyframe_step),y:$(yaw),p:$(pitch),d:$(keyframes),e:$(equipment),s:$(swings),a:$(actions)}}}'},hover_event:{action:"show_text",value:"Clique pour copier, puis colle dans un command block"}},{text:"  item_display",color:"gray"}]
$tellraw @s [{text:"🎥 "},{text:"[Copier $(block_number) · Bloc]",color:"yellow",bold:true,click_event:{action:"copy_to_clipboard",value:'function #survirec:v1/play {with:{name:"$(name)",pos:"$(start_x) $(start_y) $(start_z)",entity:"minecraft:block_display",nbt:{block_state:{Name:"minecraft:stone"}},range:0,size:1,loop:1,redstone:0,restore:1,speed:100,delay:0,tag:"",group:"$(group)",group_radius:$(group_radius),data:{f:$(is_first),n:$(keyframe_step),y:$(yaw),p:$(pitch),d:$(keyframes),e:$(equipment),s:$(swings),a:$(actions)}}}'},hover_event:{action:"show_text",value:"Clique pour copier, puis colle dans un command block"}},{text:"  block_display",color:"gray"}]
$tellraw @s [{text:"🎥 "},{text:"[Copier $(block_number) · Texte]",color:"yellow",bold:true,click_event:{action:"copy_to_clipboard",value:'function #survirec:v1/play {with:{name:"$(name)",pos:"$(start_x) $(start_y) $(start_z)",entity:"minecraft:text_display",nbt:{text:"Bonjour",billboard:"center"},range:0,size:1,loop:1,redstone:0,restore:1,speed:100,delay:0,tag:"",group:"$(group)",group_radius:$(group_radius),data:{f:$(is_first),n:$(keyframe_step),y:$(yaw),p:$(pitch),d:$(keyframes),e:$(equipment),s:$(swings),a:$(actions)}}}'},hover_event:{action:"show_text",value:"Clique pour copier, puis colle dans un command block"}},{text:"  text_display",color:"gray"}]

