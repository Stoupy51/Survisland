
#> survirec:v1.3.2/record/cast_from_eyes
#
# @executed	as the player & at current position
#
# @within	survirec:v1.3.2/record/note_place
#			survirec:v1.3.2/record/note_use
#

# the ray uses the event marker of the player (@s, at their position)
scoreboard players operation #player_id survirec.data = @s survirec.player_id
execute as @e[type=minecraft:marker,tag=survirec.ray_marker] if score @s survirec.player_id = #player_id survirec.data run tag @s add survirec.ray_cursor
scoreboard players set #ray_steps survirec.data 0
scoreboard players set #ray_hit survirec.data 0
execute anchored eyes positioned ^ ^ ^ run function survirec:v1.3.2/record/ray_step

