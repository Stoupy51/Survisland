
#> survirec:v1.3.2/record/snapshot_position
#
# @executed	as @e[type=minecraft:marker,tag=survirec.look_marker]
#
# @within	survirec:v1.3.2/record/snapshot_looked_cube [ as @e[type=minecraft:marker,tag=survirec.look_marker] ]
#

execute store result score #snapshot_x survirec.data run data get entity @s Pos[0]
execute store result storage survirec:recording snapshot.x int 1 run scoreboard players remove #snapshot_x survirec.data 1
execute store result score #snapshot_y survirec.data run data get entity @s Pos[1]
execute store result storage survirec:recording snapshot.y int 1 run scoreboard players remove #snapshot_y survirec.data 1
execute store result score #snapshot_z survirec.data run data get entity @s Pos[2]
execute store result storage survirec:recording snapshot.z int 1 run scoreboard players remove #snapshot_z survirec.data 1

