
#> survirec:v1.3.2/record/restore_next_backup
#
# @within	survirec:v1.3.2/record/restore_next_backup
#			survirec:v1.3.2/record/restore_world [ at @s ]
#

function survirec:v1.3.2/record/restore_backup with storage survirec:recording world_backups[-1]
data remove storage survirec:recording world_backups[-1]
execute if data storage survirec:recording world_backups[0] run function survirec:v1.3.2/record/restore_next_backup

