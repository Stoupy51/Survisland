
#> survirec:v1.3.2/record/copy_looked_cube_to
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/copy_looked_cube with storage survirec:recording looked_cube
#
# @args		x (unknown)
#			y (unknown)
#			z (unknown)
#

$execute at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] run clone ~-1 ~-1 ~-1 ~1 ~1 ~1 to survirec:vault $(x) $(y) $(z) strict

