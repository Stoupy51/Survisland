
#> survirec:v1.3.2/record/save
#
# @within	survirec:v1.3.2/record/finish
#

# kept in the world: played by its name, exported again from the menu
data modify storage survirec:recording saved set value {}
data modify storage survirec:recording saved.meta set from storage survirec:recording meta
data modify storage survirec:recording saved.chunks set from storage survirec:recording chunks
data modify storage survirec:recording saved.e set from storage survirec:recording e
data modify storage survirec:recording saved.s set from storage survirec:recording s
data modify storage survirec:recording saved.a set from storage survirec:recording a
data modify storage survirec:recording keyframes set value []
data modify storage survirec:recording keyframes append from storage survirec:recording chunks[][]
data modify storage survirec:recording sequence set value {}
data modify storage survirec:recording sequence.n set from storage survirec:recording meta.keyframe_step
data modify storage survirec:recording sequence.y set from storage survirec:recording meta.yaw
data modify storage survirec:recording sequence.p set from storage survirec:recording meta.pitch
data modify storage survirec:recording sequence.e set from storage survirec:recording e
data modify storage survirec:recording sequence.s set from storage survirec:recording s
data modify storage survirec:recording sequence.a set from storage survirec:recording a
data modify storage survirec:recording sequence.d set from storage survirec:recording keyframes
data remove storage survirec:recording keyframes
function survirec:v1.3.2/record/save_named with storage survirec:recording meta
execute store result storage survirec:library names[-1].player_id int 1 run scoreboard players get @s survirec.player_id

