
#> survirec:v1.3.2/record/ray_hit
#
# @executed	anchored eyes & positioned ^ ^ ^
#
# @within	survirec:v1.3.2/record/ray_step
#

execute align xyz run tp @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] ~ ~ ~
scoreboard players set #ray_hit survirec.data 1

