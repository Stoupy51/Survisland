
#> survirec:v1.3.2/record/stop_player
#
# @within	survirec:v1.3.2/record/stop_from_call
#			survirec:v1.3.2/record/stop_from_call [ as @a[tag=survirec.recording] ]
#

# a challenge is not stopped by hand, it is cancelled
execute if score @s survirec.is_challenge matches 1 run return run function survirec:v1.3.2/record/abort
function survirec:v1.3.2/record/finish

