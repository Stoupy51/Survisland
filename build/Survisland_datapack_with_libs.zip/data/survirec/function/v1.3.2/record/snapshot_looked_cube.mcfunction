
#> survirec:v1.3.2/record/snapshot_looked_cube
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/note_break
#			survirec:v1.3.2/record/note_place
#			survirec:v1.3.2/record/push_use
#

# the player has just broken, placed or used a block: keep the state before, the cube copied last tick
execute unless data storage survirec:config are_cubes_ready run return 0
execute unless score @s survirec.is_looking_at_block matches 1 run return 0
data modify storage survirec:recording snapshot set value {}
scoreboard players operation #player_id survirec.data = @s survirec.player_id
execute as @e[type=minecraft:marker,tag=survirec.look_marker] if score @s survirec.player_id = #player_id survirec.data run function survirec:v1.3.2/record/snapshot_position
execute unless data storage survirec:recording snapshot.x run return 0
execute store result storage survirec:recording snapshot.player_id int 1 run scoreboard players get @s survirec.player_id
# the first copy of a cube during this recording is the one to restore
scoreboard players set #has_snapshot survirec.data 0
function survirec:v1.3.2/record/has_snapshot with storage survirec:recording snapshot
execute if score #has_snapshot survirec.data matches 1 run return 0
execute if data storage survirec:config free_cube_slots[0] run function survirec:v1.3.2/record/reuse_snapshot_slot
execute unless data storage survirec:recording snapshot.cube_x run function survirec:v1.3.2/record/allocate_snapshot_slot
execute store result storage survirec:recording snapshot.look_x int 1 run scoreboard players get @s survirec.look_cube_x
scoreboard players operation #cube_index survirec.data = @s survirec.look_cube_x
execute store result storage survirec:recording snapshot.look_end_x int 1 run scoreboard players add #cube_index survirec.data 2
execute store result storage survirec:recording snapshot.look_y int 1 run scoreboard players get @s survirec.look_cube_y
scoreboard players operation #cube_index survirec.data = @s survirec.look_cube_y
execute store result storage survirec:recording snapshot.look_end_y int 1 run scoreboard players add #cube_index survirec.data 2
execute store result storage survirec:recording snapshot.look_z int 1 run scoreboard players get @s survirec.look_cube_z
scoreboard players operation #cube_index survirec.data = @s survirec.look_cube_z
execute store result storage survirec:recording snapshot.look_end_z int 1 run scoreboard players add #cube_index survirec.data 2
function survirec:v1.3.2/record/store_snapshot with storage survirec:recording snapshot

