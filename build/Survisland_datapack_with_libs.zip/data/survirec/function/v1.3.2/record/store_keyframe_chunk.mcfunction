
#> survirec:v1.3.2/record/store_keyframe_chunk
#
# @within	survirec:v1.3.2/record/append_keyframe with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data modify storage survirec:in_progress players.p$(player_id).chunks append from storage survirec:in_progress players.p$(player_id).d
$data modify storage survirec:in_progress players.p$(player_id).d set value []
scoreboard players set @s survirec.chunk_keyframes 0

