
#> survirec:v1.3.2/record/save_named
#
# @within	survirec:v1.3.2/record/save with storage survirec:recording meta
#
# @args		name (unknown)
#

$data modify storage survirec:library recordings.$(name) set from storage survirec:recording saved
$data modify storage survirec:data seqs.$(name) set from storage survirec:recording sequence
$data remove storage survirec:library names[{name:"$(name)"}]
$data modify storage survirec:library names append value {name:"$(name)",player_id:0}

