
#> survirec:v1.3.2/record/arm_with_nearest_group
#
# @within	survirec:v1.3.2/record/start_from_call with storage survirec:call options
#
# @args		group (string)
#			group_radius (unknown)
#

# no group of that name near the player: the recording starts at once
scoreboard players set #found_group survirec.data 0
$execute at @s as @e[tag=survirec.instance,tag=survirec.group.$(group),distance=..$(group_radius),sort=nearest,limit=1] run scoreboard players operation #found_group survirec.data = @s survirec.group_id
execute if score #found_group survirec.data matches ..0 run return run function survirec:v1.3.2/record/begin
execute store result storage survirec:call options.group_id int 1 run scoreboard players get #found_group survirec.data
function survirec:v1.3.2/record/arm

