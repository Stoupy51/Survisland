
#> survirec:v1.3.2/record/pull_state
#
# @within	survirec:v1.3.2/record/finish
#			survirec:v1.3.2/challenge/end
#

# copies the recording of the player to survirec:recording (and survirec:challenge for a challenge) before the export
function survirec:v1.3.2/record/store_player_id
data modify storage survirec:recording a set value []
function survirec:v1.3.2/record/pull_state_of with storage survirec:recorder
scoreboard players operation #keyframe_count survirec.data = @s survirec.recorded_keyframes
scoreboard players operation #chunk_keyframes survirec.data = @s survirec.chunk_keyframes

