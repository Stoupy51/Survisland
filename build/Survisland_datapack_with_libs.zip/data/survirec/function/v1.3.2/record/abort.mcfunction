
#> survirec:v1.3.2/record/abort
#
# @within	survirec:v1.3.2/record/abort_from_call
#			survirec:v1.3.2/record/abort_from_call [ as @a[tag=survirec.recording] ]
#			survirec:v1.3.2/record/abort_from_call [ as @a[tag=survirec.armed] ]
#			survirec:v1.3.2/record/stop_player
#			survirec:v1.3.2/record/stop_loop_player
#			survirec:v1.3.2/record/on_rejoin
#

execute if entity @s[tag=survirec.recording] run function #survirec:v1/signals/on_record_stop
execute if entity @s[tag=survirec.recording] run tag @s add survirec.was_recording
tag @s remove survirec.recording
tag @s remove survirec.armed
scoreboard players set @s survirec.is_challenge 0
function survirec:v1.3.2/record/cleanup
execute if entity @s[tag=survirec.was_recording] run function survirec:v1.3.2/record/restore_world
tag @s remove survirec.was_recording
function survirec:v1.3.2/record/store_player_id
function survirec:v1.3.2/record/drop_state with storage survirec:recorder

