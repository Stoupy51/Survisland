
#> survirec:v1.3.2/record/stop_loop_from_call
#
# @within	survirec:v1.3.2/api/stop_loop
#

# a player stops their own recording, a command block or the console stops them all
execute if entity @s[type=minecraft:player,tag=survirec.recording] run return run function survirec:v1.3.2/record/stop_loop_player
execute if entity @s[type=minecraft:player] run return run tellraw @s [{text:"🎥 "},{text:"Tu n'as aucun enregistrement en cours.",color:"red"}]
execute as @a[tag=survirec.recording] run function survirec:v1.3.2/record/stop_loop_player

