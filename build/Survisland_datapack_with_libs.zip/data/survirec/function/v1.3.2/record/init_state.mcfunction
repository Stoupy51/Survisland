
#> survirec:v1.3.2/record/init_state
#
# @within	survirec:v1.3.2/record/init with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data modify storage survirec:in_progress players.p$(player_id).meta set from storage survirec:recording meta
$data remove storage survirec:in_progress players.p$(player_id).equipment
$data modify storage survirec:in_progress players.p$(player_id).d set value []
$data modify storage survirec:in_progress players.p$(player_id).chunks set value []
$data modify storage survirec:in_progress players.p$(player_id).e set value []
$data modify storage survirec:in_progress players.p$(player_id).s set value []
$data modify storage survirec:in_progress players.p$(player_id).a set value []
$data modify storage survirec:in_progress players.p$(player_id).world_backups set value []

