
#> survirec:v1.3.2/record/export_events_part
#
# @within	survirec:v1.3.2/record/export_block
#

data modify storage survirec:recording export.equipment set from storage survirec:recording e
data modify storage survirec:recording export.swings set from storage survirec:recording s
data modify storage survirec:recording export.actions set from storage survirec:recording a
function survirec:v1.3.2/record/show_events_button with storage survirec:recording export

