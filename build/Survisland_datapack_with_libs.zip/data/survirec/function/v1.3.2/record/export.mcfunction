
#> survirec:v1.3.2/record/export
#
# @within	survirec:v1.3.2/record/export_saved
#			survirec:v1.3.2/record/finish
#

tellraw @s {text:"------------------------------------------------",color:"dark_gray"}
tellraw @s [{text:"🎥 "},{text:"Séquence ",color:"green"},{storage:"survirec:recording",nbt:"meta.name",color:"gold"},{text:" prête à copier :",color:"green"}]
execute store result score #chunk_count survirec.data run data get storage survirec:recording chunks
scoreboard players set #equipment_count survirec.data 0
scoreboard players set #swing_count survirec.data 0
execute store result score #equipment_count survirec.data run data get storage survirec:recording e
execute store result score #swing_count survirec.data run data get storage survirec:recording s
scoreboard players set #action_count survirec.data 0
execute store result score #action_count survirec.data run data get storage survirec:recording a
# many events get a command block of their own, so the playback command stays under the size limit
scoreboard players set #is_split survirec.data 0
execute if score #action_count survirec.data matches 30.. run scoreboard players set #is_split survirec.data 1
execute if score #equipment_count survirec.data matches 4.. run scoreboard players set #is_split survirec.data 1
execute if score #swing_count survirec.data matches 150.. run scoreboard players set #is_split survirec.data 1
scoreboard players operation #block_count survirec.data = #chunk_count survirec.data
scoreboard players operation #block_count survirec.data += #is_split survirec.data
scoreboard players set #block_number survirec.data 1
function survirec:v1.3.2/record/export_block
execute if score #block_count survirec.data matches 1 run tellraw @s [{text:"🎥 "},{text:"Colle-la dans un command block ",color:"green"},{text:"impulsion",color:"gold"},{text:".",color:"green"}]
execute if score #block_count survirec.data matches 2.. run tellraw @s [{text:"🎥 "},{text:"Colle les blocs dans l'ordre : le 1 en ",color:"green"},{text:"impulsion",color:"gold"},{text:", les suivants en ",color:"green"},{text:"chaîne",color:"green",underlined:true},{text:" (toujours actif).",color:"green"}]
tellraw @s {text:"------------------------------------------------",color:"dark_gray"}

