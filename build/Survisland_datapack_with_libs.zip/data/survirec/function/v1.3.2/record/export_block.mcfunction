
#> survirec:v1.3.2/record/export_block
#
# @within	survirec:v1.3.2/record/export_block
#			survirec:v1.3.2/record/export
#

data modify storage survirec:recording export set value {}
data modify storage survirec:recording export.name set from storage survirec:recording meta.name
data modify storage survirec:recording export.keyframe_step set from storage survirec:recording meta.keyframe_step
data modify storage survirec:recording export.yaw set from storage survirec:recording meta.yaw
data modify storage survirec:recording export.pitch set from storage survirec:recording meta.pitch
data modify storage survirec:recording export.start_x set from storage survirec:recording meta.start_x
data modify storage survirec:recording export.start_y set from storage survirec:recording meta.start_y
data modify storage survirec:recording export.start_z set from storage survirec:recording meta.start_z
data modify storage survirec:recording export.group set value ""
data modify storage survirec:recording export.group_radius set value 50
data modify storage survirec:recording export.group set from storage survirec:recording meta.group
data modify storage survirec:recording export.group_radius set from storage survirec:recording meta.group_radius
execute store result storage survirec:recording export.block_number int 1 run scoreboard players get #block_number survirec.data
data modify storage survirec:recording export.block_kind set value "chaîne"
data modify storage survirec:recording export.block_color set value "green"
execute if score #block_number survirec.data matches 1 run data modify storage survirec:recording export.block_kind set value "impulsion"
execute if score #block_number survirec.data matches 1 run data modify storage survirec:recording export.block_color set value "gold"
scoreboard players set #is_first survirec.data 0
execute if score #block_number survirec.data matches 1 run scoreboard players set #is_first survirec.data 1
execute store result storage survirec:recording export.is_first int 1 run scoreboard players get #is_first survirec.data
scoreboard players set #is_events_block survirec.data 0
execute if score #is_split survirec.data matches 1 if score #block_number survirec.data = #chunk_count survirec.data run scoreboard players set #is_events_block survirec.data 1
execute if score #is_events_block survirec.data matches 1 run function survirec:v1.3.2/record/export_events_part
execute if score #is_events_block survirec.data matches 0 if score #block_number survirec.data < #block_count survirec.data run function survirec:v1.3.2/record/export_keyframes_part
execute if score #is_events_block survirec.data matches 0 if score #block_number survirec.data >= #block_count survirec.data run function survirec:v1.3.2/record/export_last_part
scoreboard players add #block_number survirec.data 1
execute if score #block_number survirec.data <= #block_count survirec.data run function survirec:v1.3.2/record/export_block

