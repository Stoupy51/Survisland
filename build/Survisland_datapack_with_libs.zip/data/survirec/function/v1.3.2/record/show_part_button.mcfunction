
#> survirec:v1.3.2/record/show_part_button
#
# @within	survirec:v1.3.2/record/export_keyframes_part with storage survirec:recording export
#
# @args		block_number (unknown)
#			is_first (unknown)
#			keyframes (unknown)
#			block_kind (unknown)
#			block_color (unknown)
#

$tellraw @s [{text:"🎥 "},{text:"[Copier $(block_number)]",color:"yellow",bold:true,click_event:{action:"copy_to_clipboard",value:'function #survirec:v1/part {with:{f:$(is_first),d:$(keyframes)}}'},hover_event:{action:"show_text",value:"Clique pour copier, puis colle dans un command block"}},{text:"  -> ",color:"gray"},{text:"command block $(block_number) · ",color:"gray"},{text:"$(block_kind)",color:"$(block_color)"}]

