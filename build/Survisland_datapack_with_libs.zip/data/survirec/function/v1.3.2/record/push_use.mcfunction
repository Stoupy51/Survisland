
#> survirec:v1.3.2/record/push_use
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/tick
#

scoreboard players set @s survirec.has_pending_use 0
execute if score @s survirec.has_placed matches 1 run return 0
function survirec:v1.3.2/record/snapshot_looked_cube
data modify storage survirec:recording event set value {t:0,k:2,x:0,y:0,z:0}
execute store result storage survirec:recording event.t int 1 run scoreboard players get @s survirec.used_tick
scoreboard players operation #hit_x survirec.data = @s survirec.used_block_x
scoreboard players operation #hit_x survirec.data -= @s survirec.record_block_x
execute store result storage survirec:recording event.x int 1 run scoreboard players get #hit_x survirec.data
scoreboard players operation #hit_y survirec.data = @s survirec.used_block_y
scoreboard players operation #hit_y survirec.data -= @s survirec.record_block_y
execute store result storage survirec:recording event.y int 1 run scoreboard players get #hit_y survirec.data
scoreboard players operation #hit_z survirec.data = @s survirec.used_block_z
scoreboard players operation #hit_z survirec.data -= @s survirec.record_block_z
execute store result storage survirec:recording event.z int 1 run scoreboard players get #hit_z survirec.data
function survirec:v1.3.2/record/push_event with storage survirec:recorder

