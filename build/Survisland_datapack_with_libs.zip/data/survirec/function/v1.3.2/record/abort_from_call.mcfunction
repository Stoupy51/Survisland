
#> survirec:v1.3.2/record/abort_from_call
#
# @within	survirec:v1.3.2/api/abort
#

# a player cancels their own recording, a command block or the console cancels them all
execute if entity @s[type=minecraft:player] unless entity @s[tag=survirec.recording] unless entity @s[tag=survirec.armed] run return run tellraw @s [{text:"🎥 "},{text:"Tu n'as aucun enregistrement en cours.",color:"red"}]
execute if entity @s[type=minecraft:player] run function survirec:v1.3.2/record/abort
execute if entity @s[type=minecraft:player] run return run tellraw @s [{text:"🎥 "},{text:"Enregistrement annulé.",color:"yellow"}]
execute as @a[tag=survirec.recording] run function survirec:v1.3.2/record/abort
execute as @a[tag=survirec.armed] run function survirec:v1.3.2/record/abort

