
#> survirec:v1.3.2/record/begin
#
# @within	survirec:v1.3.2/record/start_from_call
#			survirec:v1.3.2/record/arm
#			survirec:v1.3.2/record/arm_with_nearest_group
#			survirec:v1.3.2/record/launch_armed
#

function survirec:v1.3.2/record/init
scoreboard players operation #player_id survirec.data = @s survirec.player_id
execute as @e[type=minecraft:text_display,tag=survirec.start_marker] if score @s survirec.player_id = #player_id survirec.data run kill @s
execute at @s run summon minecraft:text_display ~ ~1.3 ~ {Tags:["survirec.start_marker","survirec.new_start_marker","smithed.entity","smithed.strict"],text:{text:"Départ",color:"green"},billboard:"center"}
scoreboard players operation @e[type=minecraft:text_display,tag=survirec.new_start_marker] survirec.player_id = #player_id survirec.data
tag @e[type=minecraft:text_display,tag=survirec.new_start_marker] remove survirec.new_start_marker
tellraw @s {text:"------------------------------------------------",color:"dark_gray"}
tellraw @s [{text:"🎥 "},{text:"Enregistrement ",color:"green"},{storage:"survirec:recording",nbt:"meta.name",color:"gold"},{text:" démarré.",color:"green"}]
function survirec:v1.3.2/record/give_stop_item
tellraw @s [{text:"🎥 "},{text:"[■ STOP]",color:"red",bold:true,click_event:{action:"run_command",command:"/function #survirec:v1/stop"},hover_event:{action:"show_text",value:"Arrêter l'enregistrement"}},{text:"   "},{text:"[STOP + retour au départ]",color:"red",click_event:{action:"run_command",command:"/function #survirec:v1/stop_loop"},hover_event:{action:"show_text",value:"Arrêter et ramener au point de départ (boucle propre)"}}]
tellraw @s {text:"------------------------------------------------",color:"dark_gray"}
function #survirec:v1/signals/on_record_start

