
#> survirec:v1.3.2/record/read_other_half
#
# @executed	at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1]
#
# @within	survirec:v1.3.2/record/read_other_half_at
#

function survirec:v1.3.2/block/read
execute if data storage survirec:block {id:""} run return run data remove storage survirec:recording event.p
function survirec:v1.3.2/block/store_state
data modify storage survirec:recording event.p.b set from storage survirec:block state

