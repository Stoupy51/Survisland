
#> survirec:v1.3.2/record/arm
#
# @within	survirec:v1.3.2/record/arm_with_nearest_group
#

execute store result score @s survirec.waited_group run data get storage survirec:call options.group_id
scoreboard players operation #waited_group survirec.data = @s survirec.waited_group
scoreboard players set #group_alive survirec.data 0
execute as @e[tag=survirec.instance] if score @s survirec.group_id = #waited_group survirec.data run scoreboard players set #group_alive survirec.data 1
execute if score #group_alive survirec.data matches 0 run return run function survirec:v1.3.2/record/begin
execute unless score @s survirec.player_id matches 1.. run function survirec:v1.3.2/player/new_id
function survirec:v1.3.2/record/store_player_id
function survirec:v1.3.2/record/save_armed_info with storage survirec:recorder
scoreboard players set @s survirec.armed_kind 1
tag @s add survirec.armed
tellraw @s [{text:"🎥 "},{text:"Enregistrement armé : il démarre au prochain cycle du groupe.",color:"green"}]

