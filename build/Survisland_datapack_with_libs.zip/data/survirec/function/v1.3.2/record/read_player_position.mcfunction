
#> survirec:v1.3.2/record/read_player_position
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/init [ at @s ]
#			survirec:v1.3.2/record/capture_keyframe [ at @s ]
#

tp @s @a[tag=survirec.position_being_read,limit=1]
execute store result score #current_x survirec.data run data get entity @s Pos[0] 1000
execute store result score #current_y survirec.data run data get entity @s Pos[1] 1000
execute store result score #current_z survirec.data run data get entity @s Pos[2] 1000
execute store result score #current_yaw survirec.data run data get entity @s Rotation[0] 100
execute store result score #current_pitch survirec.data run data get entity @s Rotation[1] 100
kill @s

