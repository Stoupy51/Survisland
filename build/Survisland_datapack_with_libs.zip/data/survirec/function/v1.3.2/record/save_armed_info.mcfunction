
#> survirec:v1.3.2/record/save_armed_info
#
# @within	survirec:v1.3.2/record/arm with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data modify storage survirec:in_progress players.p$(player_id).meta set from storage survirec:recording meta

