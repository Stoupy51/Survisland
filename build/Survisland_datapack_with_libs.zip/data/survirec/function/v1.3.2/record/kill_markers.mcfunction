
#> survirec:v1.3.2/record/kill_markers
#
# @executed	as @a
#
# @within	survirec:v1.3.2/record/cleanup
#			survirec:v1.3.2/record/init_actions
#			survirec:v1.3.2/challenge/end
#

execute as @e[type=minecraft:marker,tag=survirec.recorder_marker] if score @s survirec.player_id = #player_id survirec.data run kill @s

