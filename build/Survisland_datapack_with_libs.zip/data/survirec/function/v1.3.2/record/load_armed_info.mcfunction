
#> survirec:v1.3.2/record/load_armed_info
#
# @executed	as @a[tag=survirec.armed]
#
# @within	survirec:v1.3.2/record/launch_armed with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data modify storage survirec:recording meta set from storage survirec:in_progress players.p$(player_id).meta

