
#> survirec:v1.3.2/record/read_other_half_at
#
# @executed	at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1]
#
# @within	survirec:v1.3.2/record/note_other_half with storage survirec:recording pair_offset
#
# @args		x (int)
#			y (int)
#			z (int)
#

$execute positioned ~$(x) ~$(y) ~$(z) run function survirec:v1.3.2/record/read_other_half

