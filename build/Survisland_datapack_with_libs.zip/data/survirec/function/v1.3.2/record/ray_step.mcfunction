
#> survirec:v1.3.2/record/ray_step
#
# @executed	anchored eyes & positioned ^ ^ ^
#
# @within	survirec:v1.3.2/record/cast_from_eyes [ anchored eyes & positioned ^ ^ ^ ]
#			survirec:v1.3.2/record/look [ anchored eyes & positioned ^ ^ ^ ]
#			survirec:v1.3.2/record/ray_step [ positioned ^ ^ ^0.2 ]
#

# steps of 0.2 block, 5 blocks at most; the survirec.ray_cursor marker goes to the block hit
scoreboard players add #ray_steps survirec.data 1
execute unless block ~ ~ ~ #survirec:ray_pass run return run function survirec:v1.3.2/record/ray_hit
execute if score #ray_steps survirec.data matches 26.. run return 0
execute positioned ^ ^ ^0.2 run function survirec:v1.3.2/record/ray_step

