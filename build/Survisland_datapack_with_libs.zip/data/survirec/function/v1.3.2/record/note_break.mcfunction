
#> survirec:v1.3.2/record/note_break
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/look
#

function survirec:v1.3.2/record/snapshot_looked_cube
data modify storage survirec:recording event set value {t:0,k:4,x:0,y:0,z:0}
execute store result storage survirec:recording event.t int 1 run scoreboard players get @s survirec.record_tick
function survirec:v1.3.2/record/store_hit_position
function survirec:v1.3.2/record/push_event with storage survirec:recorder

