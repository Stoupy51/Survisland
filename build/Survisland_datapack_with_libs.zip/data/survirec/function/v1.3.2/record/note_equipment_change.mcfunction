
#> survirec:v1.3.2/record/note_equipment_change
#
# @within	survirec:v1.3.2/record/capture_equipment with storage survirec:recorder
#
# @args		player_id (unknown)
#

$execute store success score #equipment_changed survirec.data run data modify storage survirec:in_progress players.p$(player_id).equipment set from storage survirec:recording equipment
$execute if score #equipment_changed survirec.data matches 1 run data modify storage survirec:in_progress players.p$(player_id).e append value {k:0,v:{}}
$execute if score #equipment_changed survirec.data matches 1 store result storage survirec:in_progress players.p$(player_id).e[-1].k int 1 run scoreboard players get @s survirec.recorded_keyframes
$execute if score #equipment_changed survirec.data matches 1 run data modify storage survirec:in_progress players.p$(player_id).e[-1].v set from storage survirec:recording equipment

