
#> survirec:v1.3.2/record/walk_back_step
#
# @within	survirec:v1.3.2/record/walk_back_step
#			survirec:v1.3.2/record/prepare_walk_back
#

scoreboard players operation #delta_x survirec.data = #remaining_x survirec.data
scoreboard players operation #delta_x survirec.data /= #walk_back_steps survirec.data
scoreboard players operation #delta_y survirec.data = #remaining_y survirec.data
scoreboard players operation #delta_y survirec.data /= #walk_back_steps survirec.data
scoreboard players operation #delta_z survirec.data = #remaining_z survirec.data
scoreboard players operation #delta_z survirec.data /= #walk_back_steps survirec.data
scoreboard players operation #delta_yaw survirec.data = #remaining_yaw survirec.data
scoreboard players operation #delta_yaw survirec.data /= #walk_back_steps survirec.data
scoreboard players operation #delta_pitch survirec.data = #remaining_pitch survirec.data
scoreboard players operation #delta_pitch survirec.data /= #walk_back_steps survirec.data
scoreboard players operation #remaining_x survirec.data -= #delta_x survirec.data
scoreboard players operation #remaining_y survirec.data -= #delta_y survirec.data
scoreboard players operation #remaining_z survirec.data -= #delta_z survirec.data
scoreboard players operation #remaining_yaw survirec.data -= #delta_yaw survirec.data
scoreboard players operation #remaining_pitch survirec.data -= #delta_pitch survirec.data
function survirec:v1.3.2/record/append_keyframe
scoreboard players remove #walk_back_steps survirec.data 1
execute if score #walk_back_steps survirec.data matches 1.. run function survirec:v1.3.2/record/walk_back_step

