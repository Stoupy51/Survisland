
#> survirec:v1.3.2/record/reuse_snapshot_slot
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/snapshot_looked_cube
#

data modify storage survirec:recording snapshot.cube_x set from storage survirec:config free_cube_slots[-1].cube_x
data modify storage survirec:recording snapshot.cube_y set from storage survirec:config free_cube_slots[-1].cube_y
data modify storage survirec:recording snapshot.cube_z set from storage survirec:config free_cube_slots[-1].cube_z
data modify storage survirec:recording snapshot.cube_end_x set from storage survirec:config free_cube_slots[-1].cube_end_x
data modify storage survirec:recording snapshot.cube_end_y set from storage survirec:config free_cube_slots[-1].cube_end_y
data modify storage survirec:recording snapshot.cube_end_z set from storage survirec:config free_cube_slots[-1].cube_end_z
data remove storage survirec:config free_cube_slots[-1]

