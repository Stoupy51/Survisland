
#> survirec:v1.3.2/record/capture_equipment
#
# @within	survirec:v1.3.2/record/init
#			survirec:v1.3.2/record/tick
#

data modify storage survirec:recording equipment set value {}
data modify storage survirec:recording equipment set from entity @s equipment
data modify storage survirec:recording equipment.mainhand set from entity @s SelectedItem
execute if data storage survirec:recording equipment.mainhand.components."minecraft:custom_data"{survirec:{stop:1b}} run data remove storage survirec:recording equipment.mainhand
execute if data storage survirec:recording equipment.offhand.components."minecraft:custom_data"{survirec:{stop:1b}} run data remove storage survirec:recording equipment.offhand
execute if data storage survirec:recording equipment.mainhand.components."minecraft:custom_data"{survirec:{menu:1b}} run data remove storage survirec:recording equipment.mainhand
execute if data storage survirec:recording equipment.offhand.components."minecraft:custom_data"{survirec:{menu:1b}} run data remove storage survirec:recording equipment.offhand
data remove storage survirec:recording equipment.head.components."minecraft:custom_name"
data remove storage survirec:recording equipment.head.components."minecraft:item_name"
data remove storage survirec:recording equipment.head.components."minecraft:lore"
data remove storage survirec:recording equipment.head.components."minecraft:written_book_content"
data remove storage survirec:recording equipment.head.components."minecraft:writable_book_content"
data remove storage survirec:recording equipment.head.components."minecraft:container"
data remove storage survirec:recording equipment.head.components."minecraft:bundle_contents"
data remove storage survirec:recording equipment.head.components."minecraft:custom_data"
data remove storage survirec:recording equipment.chest.components."minecraft:custom_name"
data remove storage survirec:recording equipment.chest.components."minecraft:item_name"
data remove storage survirec:recording equipment.chest.components."minecraft:lore"
data remove storage survirec:recording equipment.chest.components."minecraft:written_book_content"
data remove storage survirec:recording equipment.chest.components."minecraft:writable_book_content"
data remove storage survirec:recording equipment.chest.components."minecraft:container"
data remove storage survirec:recording equipment.chest.components."minecraft:bundle_contents"
data remove storage survirec:recording equipment.chest.components."minecraft:custom_data"
data remove storage survirec:recording equipment.legs.components."minecraft:custom_name"
data remove storage survirec:recording equipment.legs.components."minecraft:item_name"
data remove storage survirec:recording equipment.legs.components."minecraft:lore"
data remove storage survirec:recording equipment.legs.components."minecraft:written_book_content"
data remove storage survirec:recording equipment.legs.components."minecraft:writable_book_content"
data remove storage survirec:recording equipment.legs.components."minecraft:container"
data remove storage survirec:recording equipment.legs.components."minecraft:bundle_contents"
data remove storage survirec:recording equipment.legs.components."minecraft:custom_data"
data remove storage survirec:recording equipment.feet.components."minecraft:custom_name"
data remove storage survirec:recording equipment.feet.components."minecraft:item_name"
data remove storage survirec:recording equipment.feet.components."minecraft:lore"
data remove storage survirec:recording equipment.feet.components."minecraft:written_book_content"
data remove storage survirec:recording equipment.feet.components."minecraft:writable_book_content"
data remove storage survirec:recording equipment.feet.components."minecraft:container"
data remove storage survirec:recording equipment.feet.components."minecraft:bundle_contents"
data remove storage survirec:recording equipment.feet.components."minecraft:custom_data"
data remove storage survirec:recording equipment.mainhand.components."minecraft:custom_name"
data remove storage survirec:recording equipment.mainhand.components."minecraft:item_name"
data remove storage survirec:recording equipment.mainhand.components."minecraft:lore"
data remove storage survirec:recording equipment.mainhand.components."minecraft:written_book_content"
data remove storage survirec:recording equipment.mainhand.components."minecraft:writable_book_content"
data remove storage survirec:recording equipment.mainhand.components."minecraft:container"
data remove storage survirec:recording equipment.mainhand.components."minecraft:bundle_contents"
data remove storage survirec:recording equipment.mainhand.components."minecraft:custom_data"
data remove storage survirec:recording equipment.offhand.components."minecraft:custom_name"
data remove storage survirec:recording equipment.offhand.components."minecraft:item_name"
data remove storage survirec:recording equipment.offhand.components."minecraft:lore"
data remove storage survirec:recording equipment.offhand.components."minecraft:written_book_content"
data remove storage survirec:recording equipment.offhand.components."minecraft:writable_book_content"
data remove storage survirec:recording equipment.offhand.components."minecraft:container"
data remove storage survirec:recording equipment.offhand.components."minecraft:bundle_contents"
data remove storage survirec:recording equipment.offhand.components."minecraft:custom_data"
data remove storage survirec:recording equipment.body.components."minecraft:custom_name"
data remove storage survirec:recording equipment.body.components."minecraft:item_name"
data remove storage survirec:recording equipment.body.components."minecraft:lore"
data remove storage survirec:recording equipment.body.components."minecraft:written_book_content"
data remove storage survirec:recording equipment.body.components."minecraft:writable_book_content"
data remove storage survirec:recording equipment.body.components."minecraft:container"
data remove storage survirec:recording equipment.body.components."minecraft:bundle_contents"
data remove storage survirec:recording equipment.body.components."minecraft:custom_data"
data remove storage survirec:recording equipment.saddle.components."minecraft:custom_name"
data remove storage survirec:recording equipment.saddle.components."minecraft:item_name"
data remove storage survirec:recording equipment.saddle.components."minecraft:lore"
data remove storage survirec:recording equipment.saddle.components."minecraft:written_book_content"
data remove storage survirec:recording equipment.saddle.components."minecraft:writable_book_content"
data remove storage survirec:recording equipment.saddle.components."minecraft:container"
data remove storage survirec:recording equipment.saddle.components."minecraft:bundle_contents"
data remove storage survirec:recording equipment.saddle.components."minecraft:custom_data"
function survirec:v1.3.2/record/note_equipment_change with storage survirec:recorder

