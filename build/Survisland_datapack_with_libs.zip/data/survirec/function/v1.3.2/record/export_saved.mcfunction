
#> survirec:v1.3.2/record/export_saved
#
# @within	survirec:v1.3.2/api/export with storage survirec:call options
#
# @args		name (unknown)
#

$execute unless data storage survirec:library recordings.$(name) run return run tellraw @s [{text:"🎥 "},{text:"Aucun enregistrement nommé ",color:"red"},{text:"$(name)",color:"gold"},{text:".",color:"red"}]
$data modify storage survirec:recording meta set from storage survirec:library recordings.$(name).meta
$data modify storage survirec:recording chunks set from storage survirec:library recordings.$(name).chunks
$data modify storage survirec:recording e set from storage survirec:library recordings.$(name).e
$data modify storage survirec:recording s set from storage survirec:library recordings.$(name).s
data modify storage survirec:recording a set value []
$data modify storage survirec:recording a set from storage survirec:library recordings.$(name).a
function survirec:v1.3.2/record/export

