
#> survirec:v1.3.2/record/stop_with_walk_back
#
# @within	survirec:v1.3.2/record/stop_loop_player
#			survirec:v1.3.2/record/on_stop_item_click
#

function survirec:v1.3.2/record/prepare_walk_back
function survirec:v1.3.2/record/finish

