
#> survirec:v1.3.2/record/restore_world
#
# @executed	at @s
#
# @within	survirec:v1.3.2/reset [ at @s ]
#			survirec:v1.3.2/record/abort
#			survirec:v1.3.2/record/finish
#			survirec:v1.3.2/challenge/end
#

function survirec:v1.3.2/record/store_player_id
data modify storage survirec:recording world_backups set value []
function survirec:v1.3.2/record/pull_world_backups with storage survirec:recorder
execute if data storage survirec:recording world_backups[0] at @s run function survirec:v1.3.2/record/restore_next_backup

