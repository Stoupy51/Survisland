
#> survirec:v1.3.2/record/drop_state
#
# @within	survirec:v1.3.2/record/abort with storage survirec:recorder
#			survirec:v1.3.2/record/finish with storage survirec:recorder
#			survirec:v1.3.2/challenge/end with storage survirec:recorder
#
# @args		player_id (unknown)
#

$data remove storage survirec:in_progress players.p$(player_id)

