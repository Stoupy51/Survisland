
#> survirec:v1.3.2/record/store_snapshot
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/snapshot_looked_cube with storage survirec:recording snapshot
#
# @args		look_x (unknown)
#			look_y (unknown)
#			look_z (unknown)
#			look_end_x (unknown)
#			look_end_y (unknown)
#			look_end_z (unknown)
#			cube_x (unknown)
#			cube_y (unknown)
#			cube_z (unknown)
#			player_id (unknown)
#			cube_end_x (unknown)
#			cube_end_y (unknown)
#			cube_end_z (unknown)
#			x (unknown)
#			y (unknown)
#			z (unknown)
#

$execute in survirec:vault run clone $(look_x) $(look_y) $(look_z) $(look_end_x) $(look_end_y) $(look_end_z) $(cube_x) $(cube_y) $(cube_z) strict
$data modify storage survirec:in_progress players.p$(player_id).world_backups append value {cube_x:$(cube_x),cube_y:$(cube_y),cube_z:$(cube_z),cube_end_x:$(cube_end_x),cube_end_y:$(cube_end_y),cube_end_z:$(cube_end_z),x:$(x),y:$(y),z:$(z)}

