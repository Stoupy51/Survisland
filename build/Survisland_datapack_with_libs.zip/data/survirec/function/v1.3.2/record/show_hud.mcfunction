
#> survirec:v1.3.2/record/show_hud
#
# @executed	at @s
#
# @within	survirec:v1.3.2/record/tick
#

execute if score @s survirec.is_challenge matches 1 run return run function survirec:v1.3.2/challenge/show_hud
scoreboard players operation #seconds survirec.data = @s survirec.record_tick
scoreboard players operation #seconds survirec.data /= #20 survirec.data
scoreboard players operation #minutes survirec.data = #seconds survirec.data
scoreboard players operation #minutes survirec.data /= #60 survirec.data
scoreboard players operation #seconds survirec.data %= #60 survirec.data
execute if score #seconds survirec.data matches 10.. run title @s actionbar [{text:"● ",color:"red"},{text:"ENREGISTREMENT EN COURS ",color:"white",bold:true},{score:{name:"#minutes",objective:"survirec.data"},color:"yellow"},{text:":",color:"yellow"},{score:{name:"#seconds",objective:"survirec.data"},color:"yellow"}]
execute if score #seconds survirec.data matches ..9 run title @s actionbar [{text:"● ",color:"red"},{text:"ENREGISTREMENT EN COURS ",color:"white",bold:true},{score:{name:"#minutes",objective:"survirec.data"},color:"yellow"},{text:":0",color:"yellow"},{score:{name:"#seconds",objective:"survirec.data"},color:"yellow"}]

