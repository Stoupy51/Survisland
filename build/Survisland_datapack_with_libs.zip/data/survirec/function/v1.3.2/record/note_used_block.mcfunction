
#> survirec:v1.3.2/record/note_used_block
#
# @executed	at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1]
#
# @within	survirec:v1.3.2/record/note_use [ at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] ]
#

# pushed next tick by record/push_use, unless the use placed a block
execute store result score @s survirec.used_block_x run data get entity @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] Pos[0]
execute store result score @s survirec.used_block_y run data get entity @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] Pos[1]
execute store result score @s survirec.used_block_z run data get entity @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] Pos[2]
scoreboard players operation @s survirec.used_tick = @s survirec.record_tick
scoreboard players set @s survirec.has_pending_use 1

