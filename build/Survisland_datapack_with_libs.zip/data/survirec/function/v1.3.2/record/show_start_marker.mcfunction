
#> survirec:v1.3.2/record/show_start_marker
#
# @executed	at @s
#
# @within	survirec:v1.3.2/tick [ at @s ]
#

particle minecraft:happy_villager ~ ~-1.2 ~ 0.35 0 0.35 0 6 normal @a[distance=..48]
particle minecraft:end_rod ~ ~-1.2 ~ 0 0.8 0 0.01 2 normal @a[distance=..48]

