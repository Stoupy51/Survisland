
#> survirec:v1.3.2/record/note_other_half
#
# @executed	at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1]
#
# @within	survirec:v1.3.2/record/note_placed_block
#

data modify storage survirec:recording event.p set value {x:0,y:0,z:0,b:""}
scoreboard players operation #hit_x survirec.data += #pair_x survirec.data
execute store result storage survirec:recording event.p.x int 1 run scoreboard players get #hit_x survirec.data
execute store result storage survirec:recording pair_offset.x int 1 run scoreboard players get #pair_x survirec.data
scoreboard players operation #hit_y survirec.data += #pair_y survirec.data
execute store result storage survirec:recording event.p.y int 1 run scoreboard players get #hit_y survirec.data
execute store result storage survirec:recording pair_offset.y int 1 run scoreboard players get #pair_y survirec.data
scoreboard players operation #hit_z survirec.data += #pair_z survirec.data
execute store result storage survirec:recording event.p.z int 1 run scoreboard players get #hit_z survirec.data
execute store result storage survirec:recording pair_offset.z int 1 run scoreboard players get #pair_z survirec.data
function survirec:v1.3.2/record/read_other_half_at with storage survirec:recording pair_offset

