
#> survirec:v1.3.2/record/on_rejoin
#
# @executed	as @a[scores={survirec.left_game=1..}]
#
# @within	survirec:v1.3.2/tick [ as @a[scores={survirec.left_game=1..}] ]
#

# a recording is cancelled when its player comes back after a disconnection
scoreboard players set @s survirec.left_game 0
execute unless entity @s[tag=survirec.recording] unless entity @s[tag=survirec.armed] run return 0
function survirec:v1.3.2/record/abort
tellraw @s [{text:"🎥 "},{text:"Ton enregistrement a été annulé (déconnexion).",color:"yellow"}]

