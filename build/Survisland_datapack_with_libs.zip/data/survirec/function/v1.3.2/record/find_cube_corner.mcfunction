
#> survirec:v1.3.2/record/find_cube_corner
#
# @within	survirec:v1.3.2/record/init_actions
#			survirec:v1.3.2/record/allocate_snapshot_slot
#

# #cube_index -> corner of a 3x3x3 cube walled by barriers, in vault chunk 1 (x 17..31): #cube_x #cube_y #cube_z
scoreboard players operation #cube_x survirec.data = #cube_index survirec.data
scoreboard players operation #cube_x survirec.data %= #4 survirec.data
scoreboard players operation #cube_x survirec.data *= #4 survirec.data
scoreboard players add #cube_x survirec.data 17
scoreboard players operation #cube_z survirec.data = #cube_index survirec.data
scoreboard players operation #cube_z survirec.data /= #4 survirec.data
scoreboard players operation #cube_z survirec.data %= #4 survirec.data
scoreboard players operation #cube_z survirec.data *= #4 survirec.data
scoreboard players add #cube_z survirec.data 1
scoreboard players operation #cube_y survirec.data = #cube_index survirec.data
scoreboard players operation #cube_y survirec.data /= #16 survirec.data
scoreboard players operation #cube_y survirec.data *= #4 survirec.data
scoreboard players remove #cube_y survirec.data 63

