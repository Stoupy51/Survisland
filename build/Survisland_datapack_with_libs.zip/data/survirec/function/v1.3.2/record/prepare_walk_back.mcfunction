
#> survirec:v1.3.2/record/prepare_walk_back
#
# @within	survirec:v1.3.2/record/stop_with_walk_back
#

function survirec:v1.3.2/record/store_player_id
scoreboard players set #flags survirec.data 0
scoreboard players operation #remaining_x survirec.data = @s survirec.record_start_x
scoreboard players operation #remaining_x survirec.data -= @s survirec.recorded_x
scoreboard players operation #remaining_y survirec.data = @s survirec.record_start_y
scoreboard players operation #remaining_y survirec.data -= @s survirec.recorded_y
scoreboard players operation #remaining_z survirec.data = @s survirec.record_start_z
scoreboard players operation #remaining_z survirec.data -= @s survirec.recorded_z
scoreboard players operation #remaining_yaw survirec.data = @s survirec.record_start_yaw
scoreboard players operation #remaining_yaw survirec.data -= @s survirec.recorded_yaw
execute if score #remaining_yaw survirec.data matches 18001.. run scoreboard players remove #remaining_yaw survirec.data 36000
execute if score #remaining_yaw survirec.data matches ..-18001 run scoreboard players add #remaining_yaw survirec.data 36000
scoreboard players operation #remaining_pitch survirec.data = @s survirec.record_start_pitch
scoreboard players operation #remaining_pitch survirec.data -= @s survirec.recorded_pitch
scoreboard players set #walk_back_steps survirec.data 10
function survirec:v1.3.2/record/walk_back_step

