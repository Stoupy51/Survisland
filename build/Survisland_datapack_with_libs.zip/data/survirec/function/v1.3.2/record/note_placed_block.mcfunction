
#> survirec:v1.3.2/record/note_placed_block
#
# @executed	at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1]
#
# @within	survirec:v1.3.2/record/note_place [ at @e[type=minecraft:marker,tag=survirec.ray_cursor,limit=1] ]
#

function survirec:v1.3.2/block/read
execute if data storage survirec:block {id:""} run return 0
data modify storage survirec:recording event set value {t:0,k:3,x:0,y:0,z:0,b:""}
execute store result storage survirec:recording event.t int 1 run scoreboard players get @s survirec.record_tick
function survirec:v1.3.2/record/store_hit_position
function survirec:v1.3.2/block/store_state
data modify storage survirec:recording event.b set from storage survirec:block state
function survirec:v1.3.2/block/find_other_half
execute if score #is_pair survirec.data matches 1 run function survirec:v1.3.2/record/note_other_half
function survirec:v1.3.2/record/push_event with storage survirec:recorder

