
#> survirec:v1.3.2/record/cleanup
#
# @executed	as @a
#
# @within	survirec:v1.3.2/reset [ as @a ]
#			survirec:v1.3.2/record/abort
#			survirec:v1.3.2/record/finish
#

scoreboard players operation #player_id survirec.data = @s survirec.player_id
execute as @e[type=minecraft:text_display,tag=survirec.start_marker] if score @s survirec.player_id = #player_id survirec.data run kill @s
clear @s minecraft:carrot_on_a_stick[minecraft:custom_data~{survirec:{stop:1b}}]
title @s actionbar {text:""}
function survirec:v1.3.2/record/kill_markers

