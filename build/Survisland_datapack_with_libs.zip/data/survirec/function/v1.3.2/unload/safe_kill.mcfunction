
#> survirec:v1.3.2/unload/safe_kill
#
# @executed	as @e[tag=survirec.entity] & at @s
#
# @within	survirec:v1.3.2/unload [ as @e[tag=survirec.entity] & at @s ]
#			survirec:v1.3.2/unload [ at @s ]
#			survirec:v1.3.2/unload [ as @e[tag=survirec.look_marker] & at @s ]
#			survirec:v1.3.2/unload [ as @e[tag=survirec.new] & at @s ]
#			survirec:v1.3.2/unload [ as @e[tag=survirec.new_recorder_marker] & at @s ]
#			survirec:v1.3.2/unload [ as @e[tag=survirec.new_start_marker] & at @s ]
#			survirec:v1.3.2/unload [ as @e[tag=survirec.ray_marker] & at @s ]
#			survirec:v1.3.2/unload [ as @e[tag=survirec.recorder_marker] & at @s ]
#			survirec:v1.3.2/unload [ as @e[tag=survirec.start_marker] & at @s ]
#

# This function is used to safely kill entities by teleporting them to the void before killing them to prevent item drops
tp @s ~ -10000 ~
kill @s

