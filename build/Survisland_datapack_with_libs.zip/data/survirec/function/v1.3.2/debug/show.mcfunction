
#> survirec:v1.3.2/debug/show
#
# @within	survirec:v1.3.2/api/debug
#

tag @s add survirec.debug_viewer
tellraw @s [{text:"🎥 "},{text:"diagnostic",color:"gold",bold:true}]
execute store result score #debug_recording survirec.data if entity @a[tag=survirec.recording]
execute store result score #debug_armed survirec.data if entity @a[tag=survirec.armed]
tellraw @s [{text:"  Enregistrements : ",color:"gray"},{score:{name:"#debug_recording",objective:"survirec.data"},color:"aqua"},{text:"   armés : ",color:"gray"},{score:{name:"#debug_armed",objective:"survirec.data"},color:"aqua"}]
execute as @a[tag=survirec.recording] run tellraw @a[tag=survirec.debug_viewer] [{text:"  ● ",color:"red"},{selector:"@s",color:"white"},{text:"  ",color:"gray"},{score:{name:"@s",objective:"survirec.record_tick"},color:"aqua"},{text:" ticks, ",color:"gray"},{score:{name:"@s",objective:"survirec.recorded_keyframes"},color:"aqua"},{text:" keyframes",color:"gray"}]
execute as @a[tag=survirec.armed] run tellraw @a[tag=survirec.debug_viewer] [{text:"  ⏳ ",color:"gold"},{selector:"@s",color:"white"},{text:"  attend le groupe ",color:"gray"},{score:{name:"@s",objective:"survirec.waited_group"},color:"aqua"}]
execute store result score #debug_entities survirec.data if entity @e[tag=survirec.instance]
tellraw @s [{text:"  Entités animées : ",color:"gray"},{score:{name:"#debug_entities",objective:"survirec.data"},color:"aqua"}]
execute as @e[tag=survirec.instance] run tellraw @a[tag=survirec.debug_viewer] [{text:"  • groupe ",color:"gray"},{score:{name:"@s",objective:"survirec.group_id"},color:"gold",bold:true},{text:"  en lecture ",color:"gray"},{score:{name:"@s",objective:"survirec.play_state"},color:"gold",bold:true},{text:"  ",color:"gray"},{nbt:"Tags",entity:"@s",color:"aqua"}]
tag @s remove survirec.debug_viewer

