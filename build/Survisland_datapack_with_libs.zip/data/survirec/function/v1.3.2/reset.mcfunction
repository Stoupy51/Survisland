
#> survirec:v1.3.2/reset
#
# @within	survirec:v1.3.2/api/reset
#

execute as @a[tag=survirec.recording] run function #survirec:v1/signals/on_record_stop
execute as @a[tag=survirec.recording] at @s run function survirec:v1.3.2/record/restore_world
tag @a remove survirec.recording
tag @a remove survirec.armed
execute as @a run function survirec:v1.3.2/record/cleanup
scoreboard players set @a survirec.is_challenge 0
kill @e[type=minecraft:text_display,tag=survirec.start_marker]
kill @e[type=minecraft:marker,tag=survirec.recorder_marker]
execute as @e[type=minecraft:marker,tag=survirec.pulse_marker] at @s run function survirec:v1.3.2/pulse/stop
scoreboard players set #pulse_count survirec.data 0
data remove storage survirec:in_progress players
tellraw @s [{text:"🎥 "},{text:"État réinitialisé.",color:"green"}]

