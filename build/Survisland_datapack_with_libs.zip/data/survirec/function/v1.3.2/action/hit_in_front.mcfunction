
#> survirec:v1.3.2/action/hit_in_front
#
# @executed	at @s & anchored eyes & positioned ^ ^-0.6 ^1
#
# @within	survirec:v1.3.2/action/hit with storage survirec:playback hit [ at @s & anchored eyes & positioned ^ ^-0.6 ^1 ]
#
# @args		damage (unknown)
#

$execute as @e[distance=..1.6,tag=!survirec.instance,tag=!smithed.strict,type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker] run damage @s $(damage) minecraft:mob_attack by @e[tag=survirec.hitter,limit=1]
$execute if score @e[tag=survirec.hitter,limit=1] survirec.hit_players matches 1 as @a[distance=..1.6,gamemode=!spectator] run damage @s $(damage) minecraft:mob_attack by @e[tag=survirec.hitter,limit=1]

