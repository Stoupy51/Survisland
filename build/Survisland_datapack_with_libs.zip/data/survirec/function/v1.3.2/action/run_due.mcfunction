
#> survirec:v1.3.2/action/run_due
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/playback/tick
#

scoreboard players operation #sequence_time survirec.data = @s survirec.keyframe_index
scoreboard players operation #sequence_time survirec.data *= @s survirec.keyframe_ticks
scoreboard players operation #sequence_time survirec.data += @s survirec.keyframe_progress
execute if score #sequence_time survirec.data >= @s survirec.next_action_tick run function survirec:v1.3.2/action/run_next

