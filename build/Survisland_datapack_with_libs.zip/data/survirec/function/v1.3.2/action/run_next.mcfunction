
#> survirec:v1.3.2/action/run_next
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/run_due
#			survirec:v1.3.2/action/run_next
#

execute store result storage survirec:playback instance_id int 1 run scoreboard players get @s survirec.instance_id
execute store result storage survirec:playback action_index int 1 run scoreboard players get @s survirec.action_index
function survirec:v1.3.2/action/read_event_name with storage survirec:playback
function survirec:v1.3.2/action/run_event
scoreboard players add @s survirec.action_index 1
function survirec:v1.3.2/action/load_next
execute if score #sequence_time survirec.data >= @s survirec.next_action_tick run function survirec:v1.3.2/action/run_next

