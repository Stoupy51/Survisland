
#> survirec:v1.3.2/action/run_block_action
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/run_at
#

execute if score #event_kind survirec.data matches 2 run return run function survirec:v1.3.2/action/use_block
execute if score #event_kind survirec.data matches 3 run return run function survirec:v1.3.2/action/place_block
execute if score #event_kind survirec.data matches 4 run return run function survirec:v1.3.2/action/break_block

