
#> survirec:v1.3.2/action/read_event_name
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/run_next with storage survirec:playback
#
# @args		instance_id (unknown)
#

$data modify storage survirec:playback name set from storage survirec:instances i$(instance_id).name
function survirec:v1.3.2/action/read_event with storage survirec:playback

