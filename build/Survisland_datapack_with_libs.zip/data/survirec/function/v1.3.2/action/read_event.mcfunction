
#> survirec:v1.3.2/action/read_event
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/read_event_name with storage survirec:playback
#
# @args		name (unknown)
#			action_index (unknown)
#

$data modify storage survirec:playback event set from storage survirec:data seqs.$(name).a[$(action_index)]

