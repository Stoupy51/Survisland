
#> survirec:v1.3.2/action/break_block
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/run_block_action
#

function survirec:v1.3.2/block/read
function survirec:v1.3.2/block/find_other_half
scoreboard players operation #restore_strict survirec.data = #is_pair survirec.data
function survirec:v1.3.2/vault/back_up_here
execute if score #is_pair survirec.data matches 1 run function survirec:v1.3.2/action/back_up_other_half
setblock ~ ~ ~ minecraft:air destroy
execute align xyz positioned ~0.5 ~0.5 ~0.5 run kill @e[type=minecraft:item,distance=..1.6,nbt={Age:0s}]
execute align xyz positioned ~0.5 ~0.5 ~0.5 run kill @e[type=minecraft:experience_orb,distance=..1.6]
swing @s mainhand

