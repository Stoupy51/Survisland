
#> survirec:v1.3.2/action/hit
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/run_event
#

scoreboard players set #hit_damage survirec.data 10
execute if items entity @s weapon.mainhand #survirec:dmg/d20 run scoreboard players set #hit_damage survirec.data 20
execute if items entity @s weapon.mainhand #survirec:dmg/d25 run scoreboard players set #hit_damage survirec.data 25
execute if items entity @s weapon.mainhand #survirec:dmg/d30 run scoreboard players set #hit_damage survirec.data 30
execute if items entity @s weapon.mainhand #survirec:dmg/d35 run scoreboard players set #hit_damage survirec.data 35
execute if items entity @s weapon.mainhand #survirec:dmg/d40 run scoreboard players set #hit_damage survirec.data 40
execute if items entity @s weapon.mainhand #survirec:dmg/d45 run scoreboard players set #hit_damage survirec.data 45
execute if items entity @s weapon.mainhand #survirec:dmg/d50 run scoreboard players set #hit_damage survirec.data 50
execute if items entity @s weapon.mainhand #survirec:dmg/d55 run scoreboard players set #hit_damage survirec.data 55
execute if items entity @s weapon.mainhand #survirec:dmg/d60 run scoreboard players set #hit_damage survirec.data 60
execute if items entity @s weapon.mainhand #survirec:dmg/d65 run scoreboard players set #hit_damage survirec.data 65
execute if items entity @s weapon.mainhand #survirec:dmg/d70 run scoreboard players set #hit_damage survirec.data 70
execute if items entity @s weapon.mainhand #survirec:dmg/d80 run scoreboard players set #hit_damage survirec.data 80
execute if items entity @s weapon.mainhand #survirec:dmg/d90 run scoreboard players set #hit_damage survirec.data 90
execute if items entity @s weapon.mainhand #survirec:dmg/d100 run scoreboard players set #hit_damage survirec.data 100
execute store result storage survirec:playback hit.damage float 0.1 run scoreboard players get #hit_damage survirec.data
tag @s add survirec.hitter
execute at @s anchored eyes positioned ^ ^-0.6 ^1 run function survirec:v1.3.2/action/hit_in_front with storage survirec:playback hit
tag @s remove survirec.hitter

