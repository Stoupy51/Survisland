
#> survirec:v1.3.2/action/back_up_other_half
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/break_block
#

data modify storage survirec:playback pair_offset set value {x:0,y:0,z:0}
execute store result storage survirec:playback pair_offset.x int 1 run scoreboard players get #pair_x survirec.data
execute store result storage survirec:playback pair_offset.y int 1 run scoreboard players get #pair_y survirec.data
execute store result storage survirec:playback pair_offset.z int 1 run scoreboard players get #pair_z survirec.data
function survirec:v1.3.2/action/back_up_other_half_at with storage survirec:playback pair_offset

