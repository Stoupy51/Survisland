
#> survirec:v1.3.2/action/run_event
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/run_next
#

execute store result score #event_kind survirec.data run data get storage survirec:playback event.k
execute if score #event_kind survirec.data matches 1 run return run function survirec:v1.3.2/action/hit
# block of the action = start block of the entity + recorded offset
data modify storage survirec:playback action_position set value {x:0,y:0,z:0}
execute store result score #block_x survirec.data run data get storage survirec:playback event.x
scoreboard players operation #block_x survirec.data += @s survirec.start_block_x
execute store result storage survirec:playback action_position.x int 1 run scoreboard players get #block_x survirec.data
execute store result score #block_y survirec.data run data get storage survirec:playback event.y
scoreboard players operation #block_y survirec.data += @s survirec.start_block_y
execute store result storage survirec:playback action_position.y int 1 run scoreboard players get #block_y survirec.data
execute store result score #block_z survirec.data run data get storage survirec:playback event.z
scoreboard players operation #block_z survirec.data += @s survirec.start_block_z
execute store result storage survirec:playback action_position.z int 1 run scoreboard players get #block_z survirec.data
execute if score #event_kind survirec.data matches 2..4 run return run function survirec:v1.3.2/action/run_at with storage survirec:playback action_position

