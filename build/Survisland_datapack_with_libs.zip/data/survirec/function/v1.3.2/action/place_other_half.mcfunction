
#> survirec:v1.3.2/action/place_other_half
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/place_block
#

data modify storage survirec:playback other_half set value {x:0,y:0,z:0,b:""}
data modify storage survirec:playback other_half.b set from storage survirec:playback event.p.b
execute store result score #half_x survirec.data run data get storage survirec:playback event.p.x
scoreboard players operation #half_x survirec.data += @s survirec.start_block_x
execute store result storage survirec:playback other_half.x int 1 run scoreboard players get #half_x survirec.data
execute store result score #half_y survirec.data run data get storage survirec:playback event.p.y
scoreboard players operation #half_y survirec.data += @s survirec.start_block_y
execute store result storage survirec:playback other_half.y int 1 run scoreboard players get #half_y survirec.data
execute store result score #half_z survirec.data run data get storage survirec:playback event.p.z
scoreboard players operation #half_z survirec.data += @s survirec.start_block_z
execute store result storage survirec:playback other_half.z int 1 run scoreboard players get #half_z survirec.data
function survirec:v1.3.2/action/place_other_half_at with storage survirec:playback other_half

