
#> survirec:v1.3.2/action/back_up_other_half_at
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/back_up_other_half with storage survirec:playback pair_offset
#
# @args		x (int)
#			y (int)
#			z (int)
#

$execute positioned ~$(x) ~$(y) ~$(z) run function survirec:v1.3.2/vault/back_up_here

