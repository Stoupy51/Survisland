
#> survirec:v1.3.2/action/use_block
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/run_block_action
#

function survirec:v1.3.2/block/read
execute if data storage survirec:block {id:""} run return 0
execute if block ~ ~ ~ #minecraft:buttons run return run function survirec:v1.3.2/use/press_button
execute if block ~ ~ ~ minecraft:lever run return run function survirec:v1.3.2/use/toggle_lever
execute if block ~ ~ ~ #survirec:doors_open run return run function survirec:v1.3.2/use/toggle_door
execute if block ~ ~ ~ #survirec:trapdoors_open run return run function survirec:v1.3.2/use/toggle_open
execute if block ~ ~ ~ #minecraft:fence_gates run return run function survirec:v1.3.2/use/toggle_open

