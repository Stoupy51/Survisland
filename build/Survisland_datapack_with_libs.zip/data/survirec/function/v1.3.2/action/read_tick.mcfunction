
#> survirec:v1.3.2/action/read_tick
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/action/read_name with storage survirec:playback
#
# @args		name (unknown)
#			action_index (unknown)
#

$execute if data storage survirec:data seqs.$(name).a[$(action_index)] store result score @s survirec.next_action_tick run data get storage survirec:data seqs.$(name).a[$(action_index)].t 100

