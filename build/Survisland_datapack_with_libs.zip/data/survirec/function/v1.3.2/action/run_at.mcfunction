
#> survirec:v1.3.2/action/run_at
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/run_event with storage survirec:playback action_position
#
# @args		x (int)
#			y (int)
#			z (int)
#

$execute at @s positioned $(x) $(y) $(z) run function survirec:v1.3.2/action/run_block_action

