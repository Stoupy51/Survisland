
#> survirec:v1.3.2/action/place_block
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/run_block_action
#

# a door or a bed is placed without block updates, so that its halves do not copy each other
scoreboard players set #restore_strict survirec.data 0
execute if data storage survirec:playback event.p run scoreboard players set #restore_strict survirec.data 1
function survirec:v1.3.2/vault/back_up_here
execute if score #restore_strict survirec.data matches 1 run function survirec:v1.3.2/action/place_other_half
execute if score #restore_strict survirec.data matches 0 run function survirec:v1.3.2/block/set_recorded with storage survirec:playback event
execute if score #restore_strict survirec.data matches 1 run function survirec:v1.3.2/block/set_recorded_strict with storage survirec:playback event
playsound minecraft:block.stone.place block @a[distance=..24] ~ ~ ~

