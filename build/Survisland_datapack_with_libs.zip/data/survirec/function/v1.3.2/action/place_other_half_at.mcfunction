
#> survirec:v1.3.2/action/place_other_half_at
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/action/place_other_half with storage survirec:playback other_half
#
# @args		x (int)
#			y (int)
#			z (int)
#			b (string)
#

$execute positioned $(x) $(y) $(z) run function survirec:v1.3.2/vault/back_up_here
$setblock $(x) $(y) $(z) $(b) strict

