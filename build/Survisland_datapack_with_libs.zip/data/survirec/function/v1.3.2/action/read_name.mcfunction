
#> survirec:v1.3.2/action/read_name
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/action/load_next with storage survirec:playback
#
# @args		instance_id (unknown)
#

$data modify storage survirec:playback name set from storage survirec:instances i$(instance_id).name
function survirec:v1.3.2/action/read_tick with storage survirec:playback

