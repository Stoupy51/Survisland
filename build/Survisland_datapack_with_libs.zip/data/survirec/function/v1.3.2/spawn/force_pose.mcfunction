
#> survirec:v1.3.2/spawn/force_pose
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init_appearance with storage survirec:call spawn
#
# @args		pose (unknown)
#

$data modify entity @s pose set value "$(pose)"
execute if data storage survirec:call spawn{pose:"fall_flying"} run data modify entity @s OnGround set value 0b
execute if data storage survirec:call spawn{pose:"fall_flying"} run data modify entity @s FallFlying set value 1b
scoreboard players set @s survirec.is_pose_fixed 1

