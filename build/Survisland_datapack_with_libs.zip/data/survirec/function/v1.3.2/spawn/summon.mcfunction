
#> survirec:v1.3.2/spawn/summon
#
# @within	survirec:v1.3.2/spawn/from_options
#			survirec:v1.3.2/challenge/spawn_at_start
#

execute unless data storage survirec:call spawn{tag:""} run function survirec:v1.3.2/kill/by_tag with storage survirec:call spawn
execute if data storage survirec:call spawn{entity:""} run function survirec:v1.3.2/spawn/summon_mannequin
execute if data storage survirec:call spawn{entity:"minecraft:mannequin"} run function survirec:v1.3.2/spawn/summon_mannequin
execute if data storage survirec:call spawn{entity:"mannequin"} run function survirec:v1.3.2/spawn/summon_mannequin
execute unless data storage survirec:call spawn{entity:""} unless data storage survirec:call spawn{entity:"minecraft:mannequin"} unless data storage survirec:call spawn{entity:"mannequin"} run function survirec:v1.3.2/spawn/summon_other with storage survirec:call spawn
scoreboard players add #next_instance_id survirec.data 1
execute as @e[tag=survirec.new,sort=nearest,limit=1] run function survirec:v1.3.2/spawn/init

