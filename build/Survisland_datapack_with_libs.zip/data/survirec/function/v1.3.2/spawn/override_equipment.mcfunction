
#> survirec:v1.3.2/spawn/override_equipment
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init_appearance
#

# a filled equipment field also stops the recorded equipment changes
execute unless data storage survirec:call spawn{head:""} run data modify storage survirec:call slot_override set value {slot:"armor.head"}
execute unless data storage survirec:call spawn{head:""} run data modify storage survirec:call slot_override.item set from storage survirec:call spawn.head
execute unless data storage survirec:call spawn{head:""} run function survirec:v1.3.2/spawn/set_slot with storage survirec:call slot_override
execute unless data storage survirec:call spawn{head:""} run scoreboard players set @s survirec.is_equipment_forced 1
execute unless data storage survirec:call spawn{chest:""} run data modify storage survirec:call slot_override set value {slot:"armor.chest"}
execute unless data storage survirec:call spawn{chest:""} run data modify storage survirec:call slot_override.item set from storage survirec:call spawn.chest
execute unless data storage survirec:call spawn{chest:""} run function survirec:v1.3.2/spawn/set_slot with storage survirec:call slot_override
execute unless data storage survirec:call spawn{chest:""} run scoreboard players set @s survirec.is_equipment_forced 1
execute unless data storage survirec:call spawn{legs:""} run data modify storage survirec:call slot_override set value {slot:"armor.legs"}
execute unless data storage survirec:call spawn{legs:""} run data modify storage survirec:call slot_override.item set from storage survirec:call spawn.legs
execute unless data storage survirec:call spawn{legs:""} run function survirec:v1.3.2/spawn/set_slot with storage survirec:call slot_override
execute unless data storage survirec:call spawn{legs:""} run scoreboard players set @s survirec.is_equipment_forced 1
execute unless data storage survirec:call spawn{feet:""} run data modify storage survirec:call slot_override set value {slot:"armor.feet"}
execute unless data storage survirec:call spawn{feet:""} run data modify storage survirec:call slot_override.item set from storage survirec:call spawn.feet
execute unless data storage survirec:call spawn{feet:""} run function survirec:v1.3.2/spawn/set_slot with storage survirec:call slot_override
execute unless data storage survirec:call spawn{feet:""} run scoreboard players set @s survirec.is_equipment_forced 1
execute unless data storage survirec:call spawn{mainhand:""} run data modify storage survirec:call slot_override set value {slot:"weapon.mainhand"}
execute unless data storage survirec:call spawn{mainhand:""} run data modify storage survirec:call slot_override.item set from storage survirec:call spawn.mainhand
execute unless data storage survirec:call spawn{mainhand:""} run function survirec:v1.3.2/spawn/set_slot with storage survirec:call slot_override
execute unless data storage survirec:call spawn{mainhand:""} run scoreboard players set @s survirec.is_equipment_forced 1
execute unless data storage survirec:call spawn{offhand:""} run data modify storage survirec:call slot_override set value {slot:"weapon.offhand"}
execute unless data storage survirec:call spawn{offhand:""} run data modify storage survirec:call slot_override.item set from storage survirec:call spawn.offhand
execute unless data storage survirec:call spawn{offhand:""} run function survirec:v1.3.2/spawn/set_slot with storage survirec:call slot_override
execute unless data storage survirec:call spawn{offhand:""} run scoreboard players set @s survirec.is_equipment_forced 1

