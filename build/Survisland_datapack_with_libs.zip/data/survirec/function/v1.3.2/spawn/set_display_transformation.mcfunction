
#> survirec:v1.3.2/spawn/set_display_transformation
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init_display with storage survirec:call spawn
#
# @args		teleport_duration (unknown)
#			display_offset (unknown)
#			size (unknown)
#

$data merge entity @s {teleport_duration:$(teleport_duration),transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[$(display_offset)f,0f,$(display_offset)f],scale:[$(size)f,$(size)f,$(size)f]}}

