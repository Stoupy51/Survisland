
#> survirec:v1.3.2/spawn/init_display
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init_appearance
#

# the client does not smooth a display: it glides over the ticks until its next move. A block display is drawn from its corner
execute store result storage survirec:call spawn.teleport_duration int 1 run scoreboard players get #move_every survirec.data
execute store result storage survirec:call spawn.display_offset float -0.0005 run data get storage survirec:call spawn.size 1000
execute unless entity @s[type=minecraft:block_display] run data modify storage survirec:call spawn.display_offset set value 0f
function survirec:v1.3.2/spawn/set_display_transformation with storage survirec:call spawn

