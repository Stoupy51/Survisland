
#> survirec:v1.3.2/spawn/set_slot
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/override_equipment with storage survirec:call slot_override
#
# @args		slot (string)
#			item (unknown)
#

$item replace entity @s $(slot) with $(item)

