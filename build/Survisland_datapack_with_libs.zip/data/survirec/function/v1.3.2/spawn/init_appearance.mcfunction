
#> survirec:v1.3.2/spawn/init_appearance
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init
#

function survirec:v1.3.2/spawn/override_equipment
execute if entity @s[type=minecraft:mannequin] if data storage survirec:call profile run data modify entity @s profile set from storage survirec:call profile
data remove storage survirec:call profile
execute if entity @s[type=minecraft:mannequin] unless data storage survirec:call spawn{skin:""} run function survirec:v1.3.2/spawn/set_skin with storage survirec:call spawn
execute if entity @s[type=minecraft:mannequin] if data storage survirec:call spawn{skin:""} unless data storage survirec:call spawn{texture:""} run function survirec:v1.3.2/spawn/set_texture with storage survirec:call spawn
execute unless data storage survirec:call spawn{pose:""} run function survirec:v1.3.2/spawn/force_pose with storage survirec:call spawn
execute if entity @s[type=#survirec:displays] run function survirec:v1.3.2/spawn/init_display
# the nbt field comes last so it wins, but never over the tags that make the entity a playback entity
data remove storage survirec:call spawn.nbt.Tags
scoreboard players set #nbt_key_count survirec.data 0
execute store result score #nbt_key_count survirec.data run data get storage survirec:call spawn.nbt
execute if score #nbt_key_count survirec.data matches 1.. run function survirec:v1.3.2/spawn/merge_nbt with storage survirec:call spawn

