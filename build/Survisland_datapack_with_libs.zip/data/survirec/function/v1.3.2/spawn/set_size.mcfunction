
#> survirec:v1.3.2/spawn/set_size
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init_sequence with storage survirec:call spawn
#
# @args		size (unknown)
#

$attribute @s minecraft:scale base set $(size)

