
#> survirec:v1.3.2/spawn/read_sequence
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init_sequence with storage survirec:call spawn
#
# @args		name (unknown)
#

$execute store result score @s survirec.keyframe_ticks run data get storage survirec:data seqs.$(name).n 100
$execute store result score @s survirec.start_yaw run data get storage survirec:data seqs.$(name).y
$execute store result score @s survirec.start_pitch run data get storage survirec:data seqs.$(name).p
$execute store result score @s survirec.keyframe_count run data get storage survirec:data seqs.$(name).d
$execute store result score @s survirec.has_swings run data get storage survirec:data seqs.$(name).s
$execute store result score @s survirec.has_actions run data get storage survirec:data seqs.$(name).a

