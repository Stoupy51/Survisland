
#> survirec:v1.3.2/spawn/summon_other
#
# @within	survirec:v1.3.2/spawn/summon with storage survirec:call spawn
#
# @args		entity (unknown)
#

$summon $(entity) ~ ~ ~ {Tags:["survirec.instance","survirec.entity","survirec.new","smithed.entity","smithed.strict"],NoAI:1b,Silent:1b,Invulnerable:1b,NoGravity:1b,PersistenceRequired:1b}

