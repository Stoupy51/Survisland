
#> survirec:v1.3.2/spawn/tag_name
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init with storage survirec:call spawn
#
# @args		name (unknown)
#

$tag @s add survirec.sequence.$(name)

