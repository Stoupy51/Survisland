
#> survirec:v1.3.2/spawn/store_command_block_position
#
# @within	survirec:v1.3.2/api/play
#

execute store result storage survirec:call options.command_block_x int 1 run data get entity @s Pos[0]
execute store result storage survirec:call options.command_block_y int 1 run data get entity @s Pos[1]
execute store result storage survirec:call options.command_block_z int 1 run data get entity @s Pos[2]
kill @s

