
#> survirec:v1.3.2/spawn/register
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init with storage survirec:call spawn
#
# @args		instance_id (unknown)
#			name (unknown)
#

$data modify storage survirec:instances i$(instance_id) set value {name:"$(name)"}

