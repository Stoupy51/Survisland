
#> survirec:v1.3.2/spawn/set_skin
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init_appearance with storage survirec:call spawn
#
# @args		skin (unknown)
#

$data modify entity @s profile set value "$(skin)"

