
#> survirec:v1.3.2/spawn/from_options
#
# @within	survirec:v1.3.2/api/play with storage survirec:call options
#
# @args		pos (unknown)
#

data modify storage survirec:call spawn set from storage survirec:call options
$execute positioned $(pos) run function survirec:v1.3.2/spawn/summon

