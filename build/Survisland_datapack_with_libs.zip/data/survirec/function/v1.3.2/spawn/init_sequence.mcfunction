
#> survirec:v1.3.2/spawn/init_sequence
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init
#

scoreboard players set @s survirec.restart_pending 0
scoreboard players set @s survirec.has_swings 0
scoreboard players set @s survirec.has_actions 0
function survirec:v1.3.2/spawn/read_sequence with storage survirec:call spawn
execute if score @s survirec.has_swings matches 1.. run scoreboard players set @s survirec.has_swings 1
execute if score @s survirec.has_actions matches 1.. run scoreboard players set @s survirec.has_actions 1
scoreboard players set @s survirec.restore_mode 1
execute if data storage survirec:call spawn.restore store result score @s survirec.restore_mode run data get storage survirec:call spawn.restore
scoreboard players set @s survirec.hit_players 0
execute if data storage survirec:call spawn.hit_players store result score @s survirec.hit_players run data get storage survirec:call spawn.hit_players
scoreboard players set @s survirec.next_release_tick -1
scoreboard players set @s survirec.redstone 0
execute if data storage survirec:call spawn.redstone store result score @s survirec.redstone run data get storage survirec:call spawn.redstone
execute if score @s survirec.redstone matches 1 store result score @s survirec.command_block_x run data get storage survirec:call spawn.command_block_x
execute if score @s survirec.redstone matches 1 store result score @s survirec.command_block_y run data get storage survirec:call spawn.command_block_y
execute if score @s survirec.redstone matches 1 store result score @s survirec.command_block_z run data get storage survirec:call spawn.command_block_z
execute store result score @s survirec.start_block_x run data get entity @s Pos[0]
execute store result score @s survirec.start_block_y run data get entity @s Pos[1]
execute store result score @s survirec.start_block_z run data get entity @s Pos[2]
execute unless entity @s[type=#survirec:displays] run function survirec:v1.3.2/spawn/set_size with storage survirec:call spawn
execute unless score @s survirec.keyframe_ticks matches 1.. run scoreboard players set @s survirec.keyframe_count 0
scoreboard players operation @s survirec.keyframe_divisor = @s survirec.keyframe_ticks
execute store result score @s survirec.loop_mode run data get storage survirec:call spawn.loop
execute store result score @s survirec.speed run data get storage survirec:call spawn.speed
scoreboard players operation @s survirec.keyframe_x = @s survirec.start_x
scoreboard players operation @s survirec.keyframe_y = @s survirec.start_y
scoreboard players operation @s survirec.keyframe_z = @s survirec.start_z
scoreboard players operation @s survirec.keyframe_yaw = @s survirec.start_yaw
scoreboard players operation @s survirec.keyframe_pitch = @s survirec.start_pitch
scoreboard players set @s survirec.is_still 0
scoreboard players set @s survirec.is_still_placed 0
scoreboard players set @s survirec.is_near 1
scoreboard players set @s survirec.own_range 0
execute if data storage survirec:call spawn.range store result score @s survirec.own_range run data get storage survirec:call spawn.range
execute if score @s survirec.own_range matches 1.. run tag @s add survirec.has_own_range
scoreboard players set @s survirec.keyframe_index 0
scoreboard players set @s survirec.equipment_index 0
scoreboard players set @s survirec.next_equipment_keyframe 0
scoreboard players set @s survirec.is_equipment_forced 0
scoreboard players set @s survirec.pose_flags -1
scoreboard players set @s survirec.is_pose_fixed 0
execute unless entity @s[type=minecraft:mannequin] run scoreboard players set @s survirec.is_pose_fixed 1
scoreboard players set @s survirec.turns_body 0
scoreboard players set @s survirec.play_state 0
execute if score @s survirec.keyframe_count matches 1.. run scoreboard players set @s survirec.play_state 1
execute if score @s survirec.play_state matches 1 run function survirec:v1.3.2/playback/load_keyframe
execute if score @s survirec.group_id matches 1.. run function survirec:v1.3.2/group/join

