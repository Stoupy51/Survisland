
#> survirec:v1.3.2/spawn/summon_mannequin
#
# @within	survirec:v1.3.2/spawn/summon
#

summon minecraft:mannequin ~ ~ ~ {Tags:["survirec.instance","survirec.entity","survirec.new","smithed.entity","smithed.strict"],immovable:true,hide_description:true,Invulnerable:1b,Silent:1b,NoGravity:1b}

