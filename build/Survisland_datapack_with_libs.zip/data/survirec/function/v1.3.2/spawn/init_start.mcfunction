
#> survirec:v1.3.2/spawn/init_start
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init
#

# a delayed start moves into the sequence, past swings and actions included
execute store result score @s survirec.keyframe_progress run data get storage survirec:call spawn.delay 100
scoreboard players operation #sequence_length survirec.data = @s survirec.keyframe_count
scoreboard players operation #sequence_length survirec.data *= @s survirec.keyframe_ticks
execute if score #sequence_length survirec.data matches 1.. run scoreboard players operation @s survirec.keyframe_progress %= #sequence_length survirec.data
execute if score @s survirec.play_state matches 1 if score @s survirec.keyframe_progress >= @s survirec.keyframe_ticks run function survirec:v1.3.2/playback/advance_keyframe
execute if score @s survirec.has_swings matches 1 run scoreboard players set @s survirec.swing_index 0
execute if score @s survirec.has_swings matches 1 run function survirec:v1.3.2/swing/load_next
execute if score @s survirec.has_swings matches 1 run function survirec:v1.3.2/swing/skip_past
execute if score @s survirec.has_actions matches 1 run scoreboard players set @s survirec.action_index 0
execute if score @s survirec.has_actions matches 1 run function survirec:v1.3.2/action/load_next
execute if score @s survirec.has_actions matches 1 run function survirec:v1.3.2/action/skip_past
function survirec:v1.3.2/playback/move
function #survirec:v1/signals/on_spawn

