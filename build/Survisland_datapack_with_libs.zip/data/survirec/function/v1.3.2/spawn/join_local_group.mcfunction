
#> survirec:v1.3.2/spawn/join_local_group
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init with storage survirec:call spawn
#
# @args		group (unknown)
#			group_radius (unknown)
#

# joins the nearest group of the same name within group_radius blocks, else starts a new one
scoreboard players set #found_group survirec.data 0
$execute as @e[tag=survirec.instance,tag=survirec.group.$(group),distance=..$(group_radius),sort=nearest,limit=1] run scoreboard players operation #found_group survirec.data = @s survirec.group_id
execute if score #found_group survirec.data matches ..0 run scoreboard players add #next_group_id survirec.data 1
execute if score #found_group survirec.data matches ..0 run scoreboard players operation #found_group survirec.data = #next_group_id survirec.data
scoreboard players operation @s survirec.group_id = #found_group survirec.data
$tag @s add survirec.group.$(group)

