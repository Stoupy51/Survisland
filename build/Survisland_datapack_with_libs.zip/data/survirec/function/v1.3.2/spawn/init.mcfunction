
#> survirec:v1.3.2/spawn/init
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/summon [ as @e[tag=survirec.new,sort=nearest,limit=1] ]
#

tag @s remove survirec.new
scoreboard players operation @s survirec.instance_id = #next_instance_id survirec.data
scoreboard players add #instance_count survirec.data 1
execute store result score @s survirec.start_x run data get entity @s Pos[0] 1000
execute store result score @s survirec.start_y run data get entity @s Pos[1] 1000
execute store result score @s survirec.start_z run data get entity @s Pos[2] 1000
execute store result storage survirec:call spawn.instance_id int 1 run scoreboard players get @s survirec.instance_id
function survirec:v1.3.2/spawn/register with storage survirec:call spawn
function survirec:v1.3.2/spawn/tag_name with storage survirec:call spawn
execute unless data storage survirec:call spawn{tag:""} run function survirec:v1.3.2/spawn/tag_user with storage survirec:call spawn
scoreboard players set @s survirec.group_id 0
execute if data storage survirec:call spawn.group_id store result score @s survirec.group_id run data get storage survirec:call spawn.group_id
execute if score @s survirec.group_id matches -1 run function survirec:v1.3.2/spawn/join_local_group with storage survirec:call spawn
scoreboard players set @s survirec.group_loop 1
execute if data storage survirec:call spawn.group_loop store result score @s survirec.group_loop run data get storage survirec:call spawn.group_loop
scoreboard players set @s survirec.group_start_tick -1
function survirec:v1.3.2/spawn/init_sequence
function survirec:v1.3.2/spawn/init_appearance
function survirec:v1.3.2/spawn/init_start

