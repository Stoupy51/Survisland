
#> survirec:v1.3.2/spawn/merge_nbt
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init_appearance with storage survirec:call spawn
#
# @args		nbt (unknown)
#

$data merge entity @s $(nbt)

