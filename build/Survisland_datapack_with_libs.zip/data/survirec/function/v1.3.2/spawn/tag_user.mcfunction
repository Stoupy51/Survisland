
#> survirec:v1.3.2/spawn/tag_user
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init with storage survirec:call spawn
#
# @args		tag (unknown)
#

$tag @s add survirec.tag.$(tag)

