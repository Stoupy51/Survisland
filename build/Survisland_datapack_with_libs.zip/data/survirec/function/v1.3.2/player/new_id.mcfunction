
#> survirec:v1.3.2/player/new_id
#
# @within	survirec:v1.3.2/record/arm
#			survirec:v1.3.2/record/init
#			survirec:v1.3.2/challenge/start
#

scoreboard players add #next_player_id survirec.data 1
scoreboard players operation @s survirec.player_id = #next_player_id survirec.data

