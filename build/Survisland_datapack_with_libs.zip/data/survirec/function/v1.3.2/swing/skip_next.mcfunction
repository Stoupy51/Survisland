
#> survirec:v1.3.2/swing/skip_next
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/swing/skip_past
#			survirec:v1.3.2/swing/skip_next
#

scoreboard players add @s survirec.swing_index 1
function survirec:v1.3.2/swing/load_next
execute if score #sequence_time survirec.data > @s survirec.next_swing_tick run function survirec:v1.3.2/swing/skip_next

