
#> survirec:v1.3.2/swing/load_next
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/swing/skip_next
#			survirec:v1.3.2/swing/run_next
#			survirec:v1.3.2/playback/restart
#			survirec:v1.3.2/spawn/init_start
#

execute store result storage survirec:playback instance_id int 1 run scoreboard players get @s survirec.instance_id
execute store result storage survirec:playback swing_index int 1 run scoreboard players get @s survirec.swing_index
scoreboard players set @s survirec.next_swing_tick 999999999
function survirec:v1.3.2/swing/read_name with storage survirec:playback

