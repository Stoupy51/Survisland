
#> survirec:v1.3.2/swing/read_tick
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/swing/read_name with storage survirec:playback
#
# @args		name (unknown)
#			swing_index (unknown)
#

$execute if data storage survirec:data seqs.$(name).s[$(swing_index)] store result score @s survirec.next_swing_tick run data get storage survirec:data seqs.$(name).s[$(swing_index)] 100

