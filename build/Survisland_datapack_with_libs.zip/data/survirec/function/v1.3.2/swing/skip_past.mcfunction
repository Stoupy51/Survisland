
#> survirec:v1.3.2/swing/skip_past
#
# @executed	as @e[tag=survirec.new,sort=nearest,limit=1]
#
# @within	survirec:v1.3.2/spawn/init_start
#

scoreboard players operation #sequence_time survirec.data = @s survirec.keyframe_index
scoreboard players operation #sequence_time survirec.data *= @s survirec.keyframe_ticks
scoreboard players operation #sequence_time survirec.data += @s survirec.keyframe_progress
execute if score #sequence_time survirec.data > @s survirec.next_swing_tick run function survirec:v1.3.2/swing/skip_next

