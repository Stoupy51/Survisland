
#> survirec:v1.3.2/swing/run_next
#
# @executed	as @e[tag=survirec.instance]
#
# @within	survirec:v1.3.2/swing/run_due
#			survirec:v1.3.2/swing/run_next
#

swing @s mainhand
scoreboard players add @s survirec.swing_index 1
function survirec:v1.3.2/swing/load_next
execute if score #sequence_time survirec.data >= @s survirec.next_swing_tick run function survirec:v1.3.2/swing/run_next

