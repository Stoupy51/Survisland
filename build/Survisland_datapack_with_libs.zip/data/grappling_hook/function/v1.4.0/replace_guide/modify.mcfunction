item modify entity @s weapon.mainhand grappling_hook:v1.4.0/add_versionning
item modify entity @s weapon.mainhand grappling_hook:v1.4.0/guide
