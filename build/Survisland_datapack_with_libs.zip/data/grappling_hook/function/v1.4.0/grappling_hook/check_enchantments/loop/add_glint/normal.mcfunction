$item modify entity @s container.$(Slot) grappling_hook:v1.4.0/add_glint
