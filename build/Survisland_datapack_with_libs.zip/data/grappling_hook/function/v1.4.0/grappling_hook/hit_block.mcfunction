execute store result score #ax grappling_hook.data run data get entity @s Pos[0] 100
execute store result score #ay grappling_hook.data run data get entity @s Pos[1] 100
execute store result score #az grappling_hook.data run data get entity @s Pos[2] 100
scoreboard players operation #power grappling_hook.data = @s grappling_hook.arrow.power
execute on origin if entity @s[distance=..200] run function grappling_hook:v1.4.0/grappling_hook/player_motion
kill @s
