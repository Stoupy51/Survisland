data modify storage grappling_hook:main temp.UUID set from entity @s UUID
execute if data entity @s Inventory[{Slot: -106b}].components."minecraft:enchantments"."grappling_hook:grappling_hook" store result score #level grappling_hook.data run data get entity @s Inventory[{Slot: -106b}].components."minecraft:enchantments"."grappling_hook:grappling_hook"
execute if data entity @s SelectedItem.components."minecraft:enchantments"."grappling_hook:grappling_hook" store result score #level grappling_hook.data run data get entity @s SelectedItem.components."minecraft:enchantments"."grappling_hook:grappling_hook"
tag @s add grappling_hook.player.me
