execute if score #grappling_hook.patch load.status matches ..0 unless score #grappling_hook.patch load.status matches 0 run function grappling_hook:v1.4.0/test_load/enumerate/set_version
