data remove storage grappling_hook:main temp.UUID
data modify entity @s damage set value 0.01d
execute on origin run function grappling_hook:v1.4.0/init_player
scoreboard players operation @s grappling_hook.arrow.power = #level grappling_hook.data
execute as @e[tag=grappling_hook.arrow, tag=!grappling_hook.arrow.summoned] run function grappling_hook:v1.4.0/tick/arrow/kill_arrow
execute on origin run tag @s remove grappling_hook.player.me
tag @s remove grappling_hook.arrow.summoned
