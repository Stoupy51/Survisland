data modify storage smithed.crafter:input flags set value ["consume_tools"]
loot replace block ~ ~ ~ container.16 loot grappling_hook:v1.4.0/items/advanced_grappling_hook
scoreboard players set @s smithed.data 1
