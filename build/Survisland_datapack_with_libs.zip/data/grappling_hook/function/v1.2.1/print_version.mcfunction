tellraw @s {"text": "[Loaded Grappling Hook v1.2.1]", "color": "green"}
