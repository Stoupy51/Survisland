scoreboard players set #to_kill grappling_hook.data 0
execute on origin if entity @s[tag=grappling_hook.player.me] run scoreboard players set #to_kill grappling_hook.data 1
execute if score #to_kill grappling_hook.data matches 1 run kill @s
