scoreboard players reset #grappling_hook.set load.status
scoreboard players add #grappling_hook.major load.status 0
scoreboard players add #grappling_hook.minor load.status 0
scoreboard players add #grappling_hook.patch load.status 0
function grappling_hook:v1.2.1/test_load/enumerate/major
