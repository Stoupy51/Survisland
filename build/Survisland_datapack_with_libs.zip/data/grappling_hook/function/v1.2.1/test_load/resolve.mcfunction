schedule clear grappling_hook:v1.2.1/tick
execute if score #grappling_hook.major load.status matches 1 if score #grappling_hook.minor load.status matches 2 if score #grappling_hook.patch load.status matches 1 run function grappling_hook:v1.2.1/test_load
