scoreboard players set #grappling_hook.major load.status 1
scoreboard players set #grappling_hook.minor load.status 2
scoreboard players set #grappling_hook.patch load.status 1
scoreboard players set #grappling_hook.set load.status 1
