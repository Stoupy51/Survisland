execute if score #grappling_hook.patch load.status matches ..1 unless score #grappling_hook.patch load.status matches 1 run function grappling_hook:v1.2.1/test_load/enumerate/set_version
