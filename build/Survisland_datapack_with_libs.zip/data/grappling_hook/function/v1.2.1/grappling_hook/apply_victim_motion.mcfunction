tag @s remove grappling_hook.victim
function grappling_hook:v1.2.1/grappling_hook/player_motion
