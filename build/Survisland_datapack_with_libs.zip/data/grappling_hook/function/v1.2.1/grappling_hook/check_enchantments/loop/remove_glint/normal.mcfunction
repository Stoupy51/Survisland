$item modify entity @s container.$(Slot) grappling_hook:v1.2.1/remove_glint
