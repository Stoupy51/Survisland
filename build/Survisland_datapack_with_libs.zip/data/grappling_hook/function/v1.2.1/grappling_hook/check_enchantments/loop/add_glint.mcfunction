execute if score #slot grappling_hook.data matches 0..35 run function grappling_hook:v1.2.1/grappling_hook/check_enchantments/loop/add_glint/normal with storage grappling_hook:main temp.RealInventory[0]
execute if score #slot grappling_hook.data matches -106 run item modify entity @s weapon.offhand grappling_hook:v1.2.1/add_glint
