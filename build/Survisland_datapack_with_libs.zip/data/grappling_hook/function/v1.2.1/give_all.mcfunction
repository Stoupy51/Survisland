loot give @s loot grappling_hook:v1.2.1/items/basic_grappling_hook
loot give @s loot grappling_hook:v1.2.1/items/normal_grappling_hook
loot give @s loot grappling_hook:v1.2.1/items/advanced_grappling_hook
loot give @s loot grappling_hook:v1.2.1/items/guide
