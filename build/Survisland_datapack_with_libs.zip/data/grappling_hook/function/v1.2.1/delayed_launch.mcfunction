execute if score @s grappling_hook.launch.delay matches 1 run function grappling_hook:v1.2.1/launch
scoreboard players remove @s grappling_hook.launch.delay 1
