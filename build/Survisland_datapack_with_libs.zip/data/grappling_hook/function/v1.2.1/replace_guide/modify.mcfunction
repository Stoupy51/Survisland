item modify entity @s weapon.mainhand grappling_hook:v1.2.1/add_versionning
item modify entity @s weapon.mainhand grappling_hook:v1.2.1/guide
