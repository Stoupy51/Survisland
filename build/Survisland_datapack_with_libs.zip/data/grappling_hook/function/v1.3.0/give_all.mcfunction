loot give @s loot grappling_hook:v1.3.0/items/basic_grappling_hook
loot give @s loot grappling_hook:v1.3.0/items/normal_grappling_hook
loot give @s loot grappling_hook:v1.3.0/items/advanced_grappling_hook
loot give @s loot grappling_hook:v1.3.0/items/guide
