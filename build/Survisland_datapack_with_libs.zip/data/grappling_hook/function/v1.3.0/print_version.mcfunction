tellraw @s {"text": "[Loaded Grappling Hook v1.3.0]", "color": "green"}
