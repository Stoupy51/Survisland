advancement revoke @s only grappling_hook:v1.3.0/check_enchantments
data remove storage grappling_hook:main temp.Inventory
data modify storage grappling_hook:main temp.Inventory set from entity @s Inventory
data modify storage grappling_hook:main temp.RealInventory set value []
data modify storage grappling_hook:main temp.RealInventory append from storage grappling_hook:main temp.Inventory[{components: {"minecraft:custom_data": {grappling_hook: 1b}}}]
data remove storage grappling_hook:main temp.Inventory
execute if data storage grappling_hook:main temp.RealInventory[0] run function grappling_hook:v1.3.0/grappling_hook/check_enchantments/loop
