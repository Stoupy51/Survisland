$item modify entity @s container.$(Slot) grappling_hook:v1.3.0/remove_glint
