item modify entity @s weapon.mainhand grappling_hook:v1.3.0/add_versionning
item modify entity @s weapon.mainhand grappling_hook:v1.3.0/guide
