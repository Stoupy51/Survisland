function grappling_hook:v1.3.0/load
