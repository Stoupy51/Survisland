schedule clear smithed.custom_block:v0.6.2/technical/tick
execute if score #smithed.custom_block.major load.status matches 0 if score #smithed.custom_block.minor load.status matches 6 if score #smithed.custom_block.patch load.status matches 2 run function smithed.custom_block:v0.6.2/technical/load
