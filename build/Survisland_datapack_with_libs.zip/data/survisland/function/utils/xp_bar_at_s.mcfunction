
#> survisland:utils/xp_bar_at_s
#
# @executed	as @a
#
# @within	survisland:modes/laser_game/xp_bar
#

# t=1000
# i=-t
# while i <= 0:
#    print('execute if score #points survisland.data matches '+str(i+t)+' run xp set @s '+str((t+i)))
#    i += 1

scoreboard players operation #points survisland.data /= #divide survisland.data
scoreboard players set #divide survisland.data 1

# XP from 0 to 1000 points
xp set @s 130 levels
execute if score #points survisland.data matches ..0 run xp set @s 0
execute if score #points survisland.data matches 1 run xp set @s 1
execute if score #points survisland.data matches 2 run xp set @s 2
execute if score #points survisland.data matches 3 run xp set @s 3
execute if score #points survisland.data matches 4 run xp set @s 4
execute if score #points survisland.data matches 5 run xp set @s 5
execute if score #points survisland.data matches 6 run xp set @s 6
execute if score #points survisland.data matches 7 run xp set @s 7
execute if score #points survisland.data matches 8 run xp set @s 8
execute if score #points survisland.data matches 9 run xp set @s 9
execute if score #points survisland.data matches 10 run xp set @s 10
execute if score #points survisland.data matches 11 run xp set @s 11
execute if score #points survisland.data matches 12 run xp set @s 12
execute if score #points survisland.data matches 13 run xp set @s 13
execute if score #points survisland.data matches 14 run xp set @s 14
execute if score #points survisland.data matches 15 run xp set @s 15
execute if score #points survisland.data matches 16 run xp set @s 16
execute if score #points survisland.data matches 17 run xp set @s 17
execute if score #points survisland.data matches 18 run xp set @s 18
execute if score #points survisland.data matches 19 run xp set @s 19
execute if score #points survisland.data matches 20 run xp set @s 20
execute if score #points survisland.data matches 21 run xp set @s 21
execute if score #points survisland.data matches 22 run xp set @s 22
execute if score #points survisland.data matches 23 run xp set @s 23
execute if score #points survisland.data matches 24 run xp set @s 24
execute if score #points survisland.data matches 25 run xp set @s 25
execute if score #points survisland.data matches 26 run xp set @s 26
execute if score #points survisland.data matches 27 run xp set @s 27
execute if score #points survisland.data matches 28 run xp set @s 28
execute if score #points survisland.data matches 29 run xp set @s 29
execute if score #points survisland.data matches 30 run xp set @s 30
execute if score #points survisland.data matches 31 run xp set @s 31
execute if score #points survisland.data matches 32 run xp set @s 32
execute if score #points survisland.data matches 33 run xp set @s 33
execute if score #points survisland.data matches 34 run xp set @s 34
execute if score #points survisland.data matches 35 run xp set @s 35
execute if score #points survisland.data matches 36 run xp set @s 36
execute if score #points survisland.data matches 37 run xp set @s 37
execute if score #points survisland.data matches 38 run xp set @s 38
execute if score #points survisland.data matches 39 run xp set @s 39
execute if score #points survisland.data matches 40 run xp set @s 40
execute if score #points survisland.data matches 41 run xp set @s 41
execute if score #points survisland.data matches 42 run xp set @s 42
execute if score #points survisland.data matches 43 run xp set @s 43
execute if score #points survisland.data matches 44 run xp set @s 44
execute if score #points survisland.data matches 45 run xp set @s 45
execute if score #points survisland.data matches 46 run xp set @s 46
execute if score #points survisland.data matches 47 run xp set @s 47
execute if score #points survisland.data matches 48 run xp set @s 48
execute if score #points survisland.data matches 49 run xp set @s 49
execute if score #points survisland.data matches 50 run xp set @s 50
execute if score #points survisland.data matches 51 run xp set @s 51
execute if score #points survisland.data matches 52 run xp set @s 52
execute if score #points survisland.data matches 53 run xp set @s 53
execute if score #points survisland.data matches 54 run xp set @s 54
execute if score #points survisland.data matches 55 run xp set @s 55
execute if score #points survisland.data matches 56 run xp set @s 56
execute if score #points survisland.data matches 57 run xp set @s 57
execute if score #points survisland.data matches 58 run xp set @s 58
execute if score #points survisland.data matches 59 run xp set @s 59
execute if score #points survisland.data matches 60 run xp set @s 60
execute if score #points survisland.data matches 61 run xp set @s 61
execute if score #points survisland.data matches 62 run xp set @s 62
execute if score #points survisland.data matches 63 run xp set @s 63
execute if score #points survisland.data matches 64 run xp set @s 64
execute if score #points survisland.data matches 65 run xp set @s 65
execute if score #points survisland.data matches 66 run xp set @s 66
execute if score #points survisland.data matches 67 run xp set @s 67
execute if score #points survisland.data matches 68 run xp set @s 68
execute if score #points survisland.data matches 69 run xp set @s 69
execute if score #points survisland.data matches 70 run xp set @s 70
execute if score #points survisland.data matches 71 run xp set @s 71
execute if score #points survisland.data matches 72 run xp set @s 72
execute if score #points survisland.data matches 73 run xp set @s 73
execute if score #points survisland.data matches 74 run xp set @s 74
execute if score #points survisland.data matches 75 run xp set @s 75
execute if score #points survisland.data matches 76 run xp set @s 76
execute if score #points survisland.data matches 77 run xp set @s 77
execute if score #points survisland.data matches 78 run xp set @s 78
execute if score #points survisland.data matches 79 run xp set @s 79
execute if score #points survisland.data matches 80 run xp set @s 80
execute if score #points survisland.data matches 81 run xp set @s 81
execute if score #points survisland.data matches 82 run xp set @s 82
execute if score #points survisland.data matches 83 run xp set @s 83
execute if score #points survisland.data matches 84 run xp set @s 84
execute if score #points survisland.data matches 85 run xp set @s 85
execute if score #points survisland.data matches 86 run xp set @s 86
execute if score #points survisland.data matches 87 run xp set @s 87
execute if score #points survisland.data matches 88 run xp set @s 88
execute if score #points survisland.data matches 89 run xp set @s 89
execute if score #points survisland.data matches 90 run xp set @s 90
execute if score #points survisland.data matches 91 run xp set @s 91
execute if score #points survisland.data matches 92 run xp set @s 92
execute if score #points survisland.data matches 93 run xp set @s 93
execute if score #points survisland.data matches 94 run xp set @s 94
execute if score #points survisland.data matches 95 run xp set @s 95
execute if score #points survisland.data matches 96 run xp set @s 96
execute if score #points survisland.data matches 97 run xp set @s 97
execute if score #points survisland.data matches 98 run xp set @s 98
execute if score #points survisland.data matches 99 run xp set @s 99
execute if score #points survisland.data matches 100 run xp set @s 100
execute if score #points survisland.data matches 101 run xp set @s 101
execute if score #points survisland.data matches 102 run xp set @s 102
execute if score #points survisland.data matches 103 run xp set @s 103
execute if score #points survisland.data matches 104 run xp set @s 104
execute if score #points survisland.data matches 105 run xp set @s 105
execute if score #points survisland.data matches 106 run xp set @s 106
execute if score #points survisland.data matches 107 run xp set @s 107
execute if score #points survisland.data matches 108 run xp set @s 108
execute if score #points survisland.data matches 109 run xp set @s 109
execute if score #points survisland.data matches 110 run xp set @s 110
execute if score #points survisland.data matches 111 run xp set @s 111
execute if score #points survisland.data matches 112 run xp set @s 112
execute if score #points survisland.data matches 113 run xp set @s 113
execute if score #points survisland.data matches 114 run xp set @s 114
execute if score #points survisland.data matches 115 run xp set @s 115
execute if score #points survisland.data matches 116 run xp set @s 116
execute if score #points survisland.data matches 117 run xp set @s 117
execute if score #points survisland.data matches 118 run xp set @s 118
execute if score #points survisland.data matches 119 run xp set @s 119
execute if score #points survisland.data matches 120 run xp set @s 120
execute if score #points survisland.data matches 121 run xp set @s 121
execute if score #points survisland.data matches 122 run xp set @s 122
execute if score #points survisland.data matches 123 run xp set @s 123
execute if score #points survisland.data matches 124 run xp set @s 124
execute if score #points survisland.data matches 125 run xp set @s 125
execute if score #points survisland.data matches 126 run xp set @s 126
execute if score #points survisland.data matches 127 run xp set @s 127
execute if score #points survisland.data matches 128 run xp set @s 128
execute if score #points survisland.data matches 129 run xp set @s 129
execute if score #points survisland.data matches 130 run xp set @s 130
execute if score #points survisland.data matches 131 run xp set @s 131
execute if score #points survisland.data matches 132 run xp set @s 132
execute if score #points survisland.data matches 133 run xp set @s 133
execute if score #points survisland.data matches 134 run xp set @s 134
execute if score #points survisland.data matches 135 run xp set @s 135
execute if score #points survisland.data matches 136 run xp set @s 136
execute if score #points survisland.data matches 137 run xp set @s 137
execute if score #points survisland.data matches 138 run xp set @s 138
execute if score #points survisland.data matches 139 run xp set @s 139
execute if score #points survisland.data matches 140 run xp set @s 140
execute if score #points survisland.data matches 141 run xp set @s 141
execute if score #points survisland.data matches 142 run xp set @s 142
execute if score #points survisland.data matches 143 run xp set @s 143
execute if score #points survisland.data matches 144 run xp set @s 144
execute if score #points survisland.data matches 145 run xp set @s 145
execute if score #points survisland.data matches 146 run xp set @s 146
execute if score #points survisland.data matches 147 run xp set @s 147
execute if score #points survisland.data matches 148 run xp set @s 148
execute if score #points survisland.data matches 149 run xp set @s 149
execute if score #points survisland.data matches 150 run xp set @s 150
execute if score #points survisland.data matches 151 run xp set @s 151
execute if score #points survisland.data matches 152 run xp set @s 152
execute if score #points survisland.data matches 153 run xp set @s 153
execute if score #points survisland.data matches 154 run xp set @s 154
execute if score #points survisland.data matches 155 run xp set @s 155
execute if score #points survisland.data matches 156 run xp set @s 156
execute if score #points survisland.data matches 157 run xp set @s 157
execute if score #points survisland.data matches 158 run xp set @s 158
execute if score #points survisland.data matches 159 run xp set @s 159
execute if score #points survisland.data matches 160 run xp set @s 160
execute if score #points survisland.data matches 161 run xp set @s 161
execute if score #points survisland.data matches 162 run xp set @s 162
execute if score #points survisland.data matches 163 run xp set @s 163
execute if score #points survisland.data matches 164 run xp set @s 164
execute if score #points survisland.data matches 165 run xp set @s 165
execute if score #points survisland.data matches 166 run xp set @s 166
execute if score #points survisland.data matches 167 run xp set @s 167
execute if score #points survisland.data matches 168 run xp set @s 168
execute if score #points survisland.data matches 169 run xp set @s 169
execute if score #points survisland.data matches 170 run xp set @s 170
execute if score #points survisland.data matches 171 run xp set @s 171
execute if score #points survisland.data matches 172 run xp set @s 172
execute if score #points survisland.data matches 173 run xp set @s 173
execute if score #points survisland.data matches 174 run xp set @s 174
execute if score #points survisland.data matches 175 run xp set @s 175
execute if score #points survisland.data matches 176 run xp set @s 176
execute if score #points survisland.data matches 177 run xp set @s 177
execute if score #points survisland.data matches 178 run xp set @s 178
execute if score #points survisland.data matches 179 run xp set @s 179
execute if score #points survisland.data matches 180 run xp set @s 180
execute if score #points survisland.data matches 181 run xp set @s 181
execute if score #points survisland.data matches 182 run xp set @s 182
execute if score #points survisland.data matches 183 run xp set @s 183
execute if score #points survisland.data matches 184 run xp set @s 184
execute if score #points survisland.data matches 185 run xp set @s 185
execute if score #points survisland.data matches 186 run xp set @s 186
execute if score #points survisland.data matches 187 run xp set @s 187
execute if score #points survisland.data matches 188 run xp set @s 188
execute if score #points survisland.data matches 189 run xp set @s 189
execute if score #points survisland.data matches 190 run xp set @s 190
execute if score #points survisland.data matches 191 run xp set @s 191
execute if score #points survisland.data matches 192 run xp set @s 192
execute if score #points survisland.data matches 193 run xp set @s 193
execute if score #points survisland.data matches 194 run xp set @s 194
execute if score #points survisland.data matches 195 run xp set @s 195
execute if score #points survisland.data matches 196 run xp set @s 196
execute if score #points survisland.data matches 197 run xp set @s 197
execute if score #points survisland.data matches 198 run xp set @s 198
execute if score #points survisland.data matches 199 run xp set @s 199
execute if score #points survisland.data matches 200 run xp set @s 200
execute if score #points survisland.data matches 201 run xp set @s 201
execute if score #points survisland.data matches 202 run xp set @s 202
execute if score #points survisland.data matches 203 run xp set @s 203
execute if score #points survisland.data matches 204 run xp set @s 204
execute if score #points survisland.data matches 205 run xp set @s 205
execute if score #points survisland.data matches 206 run xp set @s 206
execute if score #points survisland.data matches 207 run xp set @s 207
execute if score #points survisland.data matches 208 run xp set @s 208
execute if score #points survisland.data matches 209 run xp set @s 209
execute if score #points survisland.data matches 210 run xp set @s 210
execute if score #points survisland.data matches 211 run xp set @s 211
execute if score #points survisland.data matches 212 run xp set @s 212
execute if score #points survisland.data matches 213 run xp set @s 213
execute if score #points survisland.data matches 214 run xp set @s 214
execute if score #points survisland.data matches 215 run xp set @s 215
execute if score #points survisland.data matches 216 run xp set @s 216
execute if score #points survisland.data matches 217 run xp set @s 217
execute if score #points survisland.data matches 218 run xp set @s 218
execute if score #points survisland.data matches 219 run xp set @s 219
execute if score #points survisland.data matches 220 run xp set @s 220
execute if score #points survisland.data matches 221 run xp set @s 221
execute if score #points survisland.data matches 222 run xp set @s 222
execute if score #points survisland.data matches 223 run xp set @s 223
execute if score #points survisland.data matches 224 run xp set @s 224
execute if score #points survisland.data matches 225 run xp set @s 225
execute if score #points survisland.data matches 226 run xp set @s 226
execute if score #points survisland.data matches 227 run xp set @s 227
execute if score #points survisland.data matches 228 run xp set @s 228
execute if score #points survisland.data matches 229 run xp set @s 229
execute if score #points survisland.data matches 230 run xp set @s 230
execute if score #points survisland.data matches 231 run xp set @s 231
execute if score #points survisland.data matches 232 run xp set @s 232
execute if score #points survisland.data matches 233 run xp set @s 233
execute if score #points survisland.data matches 234 run xp set @s 234
execute if score #points survisland.data matches 235 run xp set @s 235
execute if score #points survisland.data matches 236 run xp set @s 236
execute if score #points survisland.data matches 237 run xp set @s 237
execute if score #points survisland.data matches 238 run xp set @s 238
execute if score #points survisland.data matches 239 run xp set @s 239
execute if score #points survisland.data matches 240 run xp set @s 240
execute if score #points survisland.data matches 241 run xp set @s 241
execute if score #points survisland.data matches 242 run xp set @s 242
execute if score #points survisland.data matches 243 run xp set @s 243
execute if score #points survisland.data matches 244 run xp set @s 244
execute if score #points survisland.data matches 245 run xp set @s 245
execute if score #points survisland.data matches 246 run xp set @s 246
execute if score #points survisland.data matches 247 run xp set @s 247
execute if score #points survisland.data matches 248 run xp set @s 248
execute if score #points survisland.data matches 249 run xp set @s 249
execute if score #points survisland.data matches 250 run xp set @s 250
execute if score #points survisland.data matches 251 run xp set @s 251
execute if score #points survisland.data matches 252 run xp set @s 252
execute if score #points survisland.data matches 253 run xp set @s 253
execute if score #points survisland.data matches 254 run xp set @s 254
execute if score #points survisland.data matches 255 run xp set @s 255
execute if score #points survisland.data matches 256 run xp set @s 256
execute if score #points survisland.data matches 257 run xp set @s 257
execute if score #points survisland.data matches 258 run xp set @s 258
execute if score #points survisland.data matches 259 run xp set @s 259
execute if score #points survisland.data matches 260 run xp set @s 260
execute if score #points survisland.data matches 261 run xp set @s 261
execute if score #points survisland.data matches 262 run xp set @s 262
execute if score #points survisland.data matches 263 run xp set @s 263
execute if score #points survisland.data matches 264 run xp set @s 264
execute if score #points survisland.data matches 265 run xp set @s 265
execute if score #points survisland.data matches 266 run xp set @s 266
execute if score #points survisland.data matches 267 run xp set @s 267
execute if score #points survisland.data matches 268 run xp set @s 268
execute if score #points survisland.data matches 269 run xp set @s 269
execute if score #points survisland.data matches 270 run xp set @s 270
execute if score #points survisland.data matches 271 run xp set @s 271
execute if score #points survisland.data matches 272 run xp set @s 272
execute if score #points survisland.data matches 273 run xp set @s 273
execute if score #points survisland.data matches 274 run xp set @s 274
execute if score #points survisland.data matches 275 run xp set @s 275
execute if score #points survisland.data matches 276 run xp set @s 276
execute if score #points survisland.data matches 277 run xp set @s 277
execute if score #points survisland.data matches 278 run xp set @s 278
execute if score #points survisland.data matches 279 run xp set @s 279
execute if score #points survisland.data matches 280 run xp set @s 280
execute if score #points survisland.data matches 281 run xp set @s 281
execute if score #points survisland.data matches 282 run xp set @s 282
execute if score #points survisland.data matches 283 run xp set @s 283
execute if score #points survisland.data matches 284 run xp set @s 284
execute if score #points survisland.data matches 285 run xp set @s 285
execute if score #points survisland.data matches 286 run xp set @s 286
execute if score #points survisland.data matches 287 run xp set @s 287
execute if score #points survisland.data matches 288 run xp set @s 288
execute if score #points survisland.data matches 289 run xp set @s 289
execute if score #points survisland.data matches 290 run xp set @s 290
execute if score #points survisland.data matches 291 run xp set @s 291
execute if score #points survisland.data matches 292 run xp set @s 292
execute if score #points survisland.data matches 293 run xp set @s 293
execute if score #points survisland.data matches 294 run xp set @s 294
execute if score #points survisland.data matches 295 run xp set @s 295
execute if score #points survisland.data matches 296 run xp set @s 296
execute if score #points survisland.data matches 297 run xp set @s 297
execute if score #points survisland.data matches 298 run xp set @s 298
execute if score #points survisland.data matches 299 run xp set @s 299
execute if score #points survisland.data matches 300 run xp set @s 300
execute if score #points survisland.data matches 301 run xp set @s 301
execute if score #points survisland.data matches 302 run xp set @s 302
execute if score #points survisland.data matches 303 run xp set @s 303
execute if score #points survisland.data matches 304 run xp set @s 304
execute if score #points survisland.data matches 305 run xp set @s 305
execute if score #points survisland.data matches 306 run xp set @s 306
execute if score #points survisland.data matches 307 run xp set @s 307
execute if score #points survisland.data matches 308 run xp set @s 308
execute if score #points survisland.data matches 309 run xp set @s 309
execute if score #points survisland.data matches 310 run xp set @s 310
execute if score #points survisland.data matches 311 run xp set @s 311
execute if score #points survisland.data matches 312 run xp set @s 312
execute if score #points survisland.data matches 313 run xp set @s 313
execute if score #points survisland.data matches 314 run xp set @s 314
execute if score #points survisland.data matches 315 run xp set @s 315
execute if score #points survisland.data matches 316 run xp set @s 316
execute if score #points survisland.data matches 317 run xp set @s 317
execute if score #points survisland.data matches 318 run xp set @s 318
execute if score #points survisland.data matches 319 run xp set @s 319
execute if score #points survisland.data matches 320 run xp set @s 320
execute if score #points survisland.data matches 321 run xp set @s 321
execute if score #points survisland.data matches 322 run xp set @s 322
execute if score #points survisland.data matches 323 run xp set @s 323
execute if score #points survisland.data matches 324 run xp set @s 324
execute if score #points survisland.data matches 325 run xp set @s 325
execute if score #points survisland.data matches 326 run xp set @s 326
execute if score #points survisland.data matches 327 run xp set @s 327
execute if score #points survisland.data matches 328 run xp set @s 328
execute if score #points survisland.data matches 329 run xp set @s 329
execute if score #points survisland.data matches 330 run xp set @s 330
execute if score #points survisland.data matches 331 run xp set @s 331
execute if score #points survisland.data matches 332 run xp set @s 332
execute if score #points survisland.data matches 333 run xp set @s 333
execute if score #points survisland.data matches 334 run xp set @s 334
execute if score #points survisland.data matches 335 run xp set @s 335
execute if score #points survisland.data matches 336 run xp set @s 336
execute if score #points survisland.data matches 337 run xp set @s 337
execute if score #points survisland.data matches 338 run xp set @s 338
execute if score #points survisland.data matches 339 run xp set @s 339
execute if score #points survisland.data matches 340 run xp set @s 340
execute if score #points survisland.data matches 341 run xp set @s 341
execute if score #points survisland.data matches 342 run xp set @s 342
execute if score #points survisland.data matches 343 run xp set @s 343
execute if score #points survisland.data matches 344 run xp set @s 344
execute if score #points survisland.data matches 345 run xp set @s 345
execute if score #points survisland.data matches 346 run xp set @s 346
execute if score #points survisland.data matches 347 run xp set @s 347
execute if score #points survisland.data matches 348 run xp set @s 348
execute if score #points survisland.data matches 349 run xp set @s 349
execute if score #points survisland.data matches 350 run xp set @s 350
execute if score #points survisland.data matches 351 run xp set @s 351
execute if score #points survisland.data matches 352 run xp set @s 352
execute if score #points survisland.data matches 353 run xp set @s 353
execute if score #points survisland.data matches 354 run xp set @s 354
execute if score #points survisland.data matches 355 run xp set @s 355
execute if score #points survisland.data matches 356 run xp set @s 356
execute if score #points survisland.data matches 357 run xp set @s 357
execute if score #points survisland.data matches 358 run xp set @s 358
execute if score #points survisland.data matches 359 run xp set @s 359
execute if score #points survisland.data matches 360 run xp set @s 360
execute if score #points survisland.data matches 361 run xp set @s 361
execute if score #points survisland.data matches 362 run xp set @s 362
execute if score #points survisland.data matches 363 run xp set @s 363
execute if score #points survisland.data matches 364 run xp set @s 364
execute if score #points survisland.data matches 365 run xp set @s 365
execute if score #points survisland.data matches 366 run xp set @s 366
execute if score #points survisland.data matches 367 run xp set @s 367
execute if score #points survisland.data matches 368 run xp set @s 368
execute if score #points survisland.data matches 369 run xp set @s 369
execute if score #points survisland.data matches 370 run xp set @s 370
execute if score #points survisland.data matches 371 run xp set @s 371
execute if score #points survisland.data matches 372 run xp set @s 372
execute if score #points survisland.data matches 373 run xp set @s 373
execute if score #points survisland.data matches 374 run xp set @s 374
execute if score #points survisland.data matches 375 run xp set @s 375
execute if score #points survisland.data matches 376 run xp set @s 376
execute if score #points survisland.data matches 377 run xp set @s 377
execute if score #points survisland.data matches 378 run xp set @s 378
execute if score #points survisland.data matches 379 run xp set @s 379
execute if score #points survisland.data matches 380 run xp set @s 380
execute if score #points survisland.data matches 381 run xp set @s 381
execute if score #points survisland.data matches 382 run xp set @s 382
execute if score #points survisland.data matches 383 run xp set @s 383
execute if score #points survisland.data matches 384 run xp set @s 384
execute if score #points survisland.data matches 385 run xp set @s 385
execute if score #points survisland.data matches 386 run xp set @s 386
execute if score #points survisland.data matches 387 run xp set @s 387
execute if score #points survisland.data matches 388 run xp set @s 388
execute if score #points survisland.data matches 389 run xp set @s 389
execute if score #points survisland.data matches 390 run xp set @s 390
execute if score #points survisland.data matches 391 run xp set @s 391
execute if score #points survisland.data matches 392 run xp set @s 392
execute if score #points survisland.data matches 393 run xp set @s 393
execute if score #points survisland.data matches 394 run xp set @s 394
execute if score #points survisland.data matches 395 run xp set @s 395
execute if score #points survisland.data matches 396 run xp set @s 396
execute if score #points survisland.data matches 397 run xp set @s 397
execute if score #points survisland.data matches 398 run xp set @s 398
execute if score #points survisland.data matches 399 run xp set @s 399
execute if score #points survisland.data matches 400 run xp set @s 400
execute if score #points survisland.data matches 401 run xp set @s 401
execute if score #points survisland.data matches 402 run xp set @s 402
execute if score #points survisland.data matches 403 run xp set @s 403
execute if score #points survisland.data matches 404 run xp set @s 404
execute if score #points survisland.data matches 405 run xp set @s 405
execute if score #points survisland.data matches 406 run xp set @s 406
execute if score #points survisland.data matches 407 run xp set @s 407
execute if score #points survisland.data matches 408 run xp set @s 408
execute if score #points survisland.data matches 409 run xp set @s 409
execute if score #points survisland.data matches 410 run xp set @s 410
execute if score #points survisland.data matches 411 run xp set @s 411
execute if score #points survisland.data matches 412 run xp set @s 412
execute if score #points survisland.data matches 413 run xp set @s 413
execute if score #points survisland.data matches 414 run xp set @s 414
execute if score #points survisland.data matches 415 run xp set @s 415
execute if score #points survisland.data matches 416 run xp set @s 416
execute if score #points survisland.data matches 417 run xp set @s 417
execute if score #points survisland.data matches 418 run xp set @s 418
execute if score #points survisland.data matches 419 run xp set @s 419
execute if score #points survisland.data matches 420 run xp set @s 420
execute if score #points survisland.data matches 421 run xp set @s 421
execute if score #points survisland.data matches 422 run xp set @s 422
execute if score #points survisland.data matches 423 run xp set @s 423
execute if score #points survisland.data matches 424 run xp set @s 424
execute if score #points survisland.data matches 425 run xp set @s 425
execute if score #points survisland.data matches 426 run xp set @s 426
execute if score #points survisland.data matches 427 run xp set @s 427
execute if score #points survisland.data matches 428 run xp set @s 428
execute if score #points survisland.data matches 429 run xp set @s 429
execute if score #points survisland.data matches 430 run xp set @s 430
execute if score #points survisland.data matches 431 run xp set @s 431
execute if score #points survisland.data matches 432 run xp set @s 432
execute if score #points survisland.data matches 433 run xp set @s 433
execute if score #points survisland.data matches 434 run xp set @s 434
execute if score #points survisland.data matches 435 run xp set @s 435
execute if score #points survisland.data matches 436 run xp set @s 436
execute if score #points survisland.data matches 437 run xp set @s 437
execute if score #points survisland.data matches 438 run xp set @s 438
execute if score #points survisland.data matches 439 run xp set @s 439
execute if score #points survisland.data matches 440 run xp set @s 440
execute if score #points survisland.data matches 441 run xp set @s 441
execute if score #points survisland.data matches 442 run xp set @s 442
execute if score #points survisland.data matches 443 run xp set @s 443
execute if score #points survisland.data matches 444 run xp set @s 444
execute if score #points survisland.data matches 445 run xp set @s 445
execute if score #points survisland.data matches 446 run xp set @s 446
execute if score #points survisland.data matches 447 run xp set @s 447
execute if score #points survisland.data matches 448 run xp set @s 448
execute if score #points survisland.data matches 449 run xp set @s 449
execute if score #points survisland.data matches 450 run xp set @s 450
execute if score #points survisland.data matches 451 run xp set @s 451
execute if score #points survisland.data matches 452 run xp set @s 452
execute if score #points survisland.data matches 453 run xp set @s 453
execute if score #points survisland.data matches 454 run xp set @s 454
execute if score #points survisland.data matches 455 run xp set @s 455
execute if score #points survisland.data matches 456 run xp set @s 456
execute if score #points survisland.data matches 457 run xp set @s 457
execute if score #points survisland.data matches 458 run xp set @s 458
execute if score #points survisland.data matches 459 run xp set @s 459
execute if score #points survisland.data matches 460 run xp set @s 460
execute if score #points survisland.data matches 461 run xp set @s 461
execute if score #points survisland.data matches 462 run xp set @s 462
execute if score #points survisland.data matches 463 run xp set @s 463
execute if score #points survisland.data matches 464 run xp set @s 464
execute if score #points survisland.data matches 465 run xp set @s 465
execute if score #points survisland.data matches 466 run xp set @s 466
execute if score #points survisland.data matches 467 run xp set @s 467
execute if score #points survisland.data matches 468 run xp set @s 468
execute if score #points survisland.data matches 469 run xp set @s 469
execute if score #points survisland.data matches 470 run xp set @s 470
execute if score #points survisland.data matches 471 run xp set @s 471
execute if score #points survisland.data matches 472 run xp set @s 472
execute if score #points survisland.data matches 473 run xp set @s 473
execute if score #points survisland.data matches 474 run xp set @s 474
execute if score #points survisland.data matches 475 run xp set @s 475
execute if score #points survisland.data matches 476 run xp set @s 476
execute if score #points survisland.data matches 477 run xp set @s 477
execute if score #points survisland.data matches 478 run xp set @s 478
execute if score #points survisland.data matches 479 run xp set @s 479
execute if score #points survisland.data matches 480 run xp set @s 480
execute if score #points survisland.data matches 481 run xp set @s 481
execute if score #points survisland.data matches 482 run xp set @s 482
execute if score #points survisland.data matches 483 run xp set @s 483
execute if score #points survisland.data matches 484 run xp set @s 484
execute if score #points survisland.data matches 485 run xp set @s 485
execute if score #points survisland.data matches 486 run xp set @s 486
execute if score #points survisland.data matches 487 run xp set @s 487
execute if score #points survisland.data matches 488 run xp set @s 488
execute if score #points survisland.data matches 489 run xp set @s 489
execute if score #points survisland.data matches 490 run xp set @s 490
execute if score #points survisland.data matches 491 run xp set @s 491
execute if score #points survisland.data matches 492 run xp set @s 492
execute if score #points survisland.data matches 493 run xp set @s 493
execute if score #points survisland.data matches 494 run xp set @s 494
execute if score #points survisland.data matches 495 run xp set @s 495
execute if score #points survisland.data matches 496 run xp set @s 496
execute if score #points survisland.data matches 497 run xp set @s 497
execute if score #points survisland.data matches 498 run xp set @s 498
execute if score #points survisland.data matches 499 run xp set @s 499
execute if score #points survisland.data matches 500 run xp set @s 500
execute if score #points survisland.data matches 501 run xp set @s 501
execute if score #points survisland.data matches 502 run xp set @s 502
execute if score #points survisland.data matches 503 run xp set @s 503
execute if score #points survisland.data matches 504 run xp set @s 504
execute if score #points survisland.data matches 505 run xp set @s 505
execute if score #points survisland.data matches 506 run xp set @s 506
execute if score #points survisland.data matches 507 run xp set @s 507
execute if score #points survisland.data matches 508 run xp set @s 508
execute if score #points survisland.data matches 509 run xp set @s 509
execute if score #points survisland.data matches 510 run xp set @s 510
execute if score #points survisland.data matches 511 run xp set @s 511
execute if score #points survisland.data matches 512 run xp set @s 512
execute if score #points survisland.data matches 513 run xp set @s 513
execute if score #points survisland.data matches 514 run xp set @s 514
execute if score #points survisland.data matches 515 run xp set @s 515
execute if score #points survisland.data matches 516 run xp set @s 516
execute if score #points survisland.data matches 517 run xp set @s 517
execute if score #points survisland.data matches 518 run xp set @s 518
execute if score #points survisland.data matches 519 run xp set @s 519
execute if score #points survisland.data matches 520 run xp set @s 520
execute if score #points survisland.data matches 521 run xp set @s 521
execute if score #points survisland.data matches 522 run xp set @s 522
execute if score #points survisland.data matches 523 run xp set @s 523
execute if score #points survisland.data matches 524 run xp set @s 524
execute if score #points survisland.data matches 525 run xp set @s 525
execute if score #points survisland.data matches 526 run xp set @s 526
execute if score #points survisland.data matches 527 run xp set @s 527
execute if score #points survisland.data matches 528 run xp set @s 528
execute if score #points survisland.data matches 529 run xp set @s 529
execute if score #points survisland.data matches 530 run xp set @s 530
execute if score #points survisland.data matches 531 run xp set @s 531
execute if score #points survisland.data matches 532 run xp set @s 532
execute if score #points survisland.data matches 533 run xp set @s 533
execute if score #points survisland.data matches 534 run xp set @s 534
execute if score #points survisland.data matches 535 run xp set @s 535
execute if score #points survisland.data matches 536 run xp set @s 536
execute if score #points survisland.data matches 537 run xp set @s 537
execute if score #points survisland.data matches 538 run xp set @s 538
execute if score #points survisland.data matches 539 run xp set @s 539
execute if score #points survisland.data matches 540 run xp set @s 540
execute if score #points survisland.data matches 541 run xp set @s 541
execute if score #points survisland.data matches 542 run xp set @s 542
execute if score #points survisland.data matches 543 run xp set @s 543
execute if score #points survisland.data matches 544 run xp set @s 544
execute if score #points survisland.data matches 545 run xp set @s 545
execute if score #points survisland.data matches 546 run xp set @s 546
execute if score #points survisland.data matches 547 run xp set @s 547
execute if score #points survisland.data matches 548 run xp set @s 548
execute if score #points survisland.data matches 549 run xp set @s 549
execute if score #points survisland.data matches 550 run xp set @s 550
execute if score #points survisland.data matches 551 run xp set @s 551
execute if score #points survisland.data matches 552 run xp set @s 552
execute if score #points survisland.data matches 553 run xp set @s 553
execute if score #points survisland.data matches 554 run xp set @s 554
execute if score #points survisland.data matches 555 run xp set @s 555
execute if score #points survisland.data matches 556 run xp set @s 556
execute if score #points survisland.data matches 557 run xp set @s 557
execute if score #points survisland.data matches 558 run xp set @s 558
execute if score #points survisland.data matches 559 run xp set @s 559
execute if score #points survisland.data matches 560 run xp set @s 560
execute if score #points survisland.data matches 561 run xp set @s 561
execute if score #points survisland.data matches 562 run xp set @s 562
execute if score #points survisland.data matches 563 run xp set @s 563
execute if score #points survisland.data matches 564 run xp set @s 564
execute if score #points survisland.data matches 565 run xp set @s 565
execute if score #points survisland.data matches 566 run xp set @s 566
execute if score #points survisland.data matches 567 run xp set @s 567
execute if score #points survisland.data matches 568 run xp set @s 568
execute if score #points survisland.data matches 569 run xp set @s 569
execute if score #points survisland.data matches 570 run xp set @s 570
execute if score #points survisland.data matches 571 run xp set @s 571
execute if score #points survisland.data matches 572 run xp set @s 572
execute if score #points survisland.data matches 573 run xp set @s 573
execute if score #points survisland.data matches 574 run xp set @s 574
execute if score #points survisland.data matches 575 run xp set @s 575
execute if score #points survisland.data matches 576 run xp set @s 576
execute if score #points survisland.data matches 577 run xp set @s 577
execute if score #points survisland.data matches 578 run xp set @s 578
execute if score #points survisland.data matches 579 run xp set @s 579
execute if score #points survisland.data matches 580 run xp set @s 580
execute if score #points survisland.data matches 581 run xp set @s 581
execute if score #points survisland.data matches 582 run xp set @s 582
execute if score #points survisland.data matches 583 run xp set @s 583
execute if score #points survisland.data matches 584 run xp set @s 584
execute if score #points survisland.data matches 585 run xp set @s 585
execute if score #points survisland.data matches 586 run xp set @s 586
execute if score #points survisland.data matches 587 run xp set @s 587
execute if score #points survisland.data matches 588 run xp set @s 588
execute if score #points survisland.data matches 589 run xp set @s 589
execute if score #points survisland.data matches 590 run xp set @s 590
execute if score #points survisland.data matches 591 run xp set @s 591
execute if score #points survisland.data matches 592 run xp set @s 592
execute if score #points survisland.data matches 593 run xp set @s 593
execute if score #points survisland.data matches 594 run xp set @s 594
execute if score #points survisland.data matches 595 run xp set @s 595
execute if score #points survisland.data matches 596 run xp set @s 596
execute if score #points survisland.data matches 597 run xp set @s 597
execute if score #points survisland.data matches 598 run xp set @s 598
execute if score #points survisland.data matches 599 run xp set @s 599
execute if score #points survisland.data matches 600 run xp set @s 600
execute if score #points survisland.data matches 601 run xp set @s 601
execute if score #points survisland.data matches 602 run xp set @s 602
execute if score #points survisland.data matches 603 run xp set @s 603
execute if score #points survisland.data matches 604 run xp set @s 604
execute if score #points survisland.data matches 605 run xp set @s 605
execute if score #points survisland.data matches 606 run xp set @s 606
execute if score #points survisland.data matches 607 run xp set @s 607
execute if score #points survisland.data matches 608 run xp set @s 608
execute if score #points survisland.data matches 609 run xp set @s 609
execute if score #points survisland.data matches 610 run xp set @s 610
execute if score #points survisland.data matches 611 run xp set @s 611
execute if score #points survisland.data matches 612 run xp set @s 612
execute if score #points survisland.data matches 613 run xp set @s 613
execute if score #points survisland.data matches 614 run xp set @s 614
execute if score #points survisland.data matches 615 run xp set @s 615
execute if score #points survisland.data matches 616 run xp set @s 616
execute if score #points survisland.data matches 617 run xp set @s 617
execute if score #points survisland.data matches 618 run xp set @s 618
execute if score #points survisland.data matches 619 run xp set @s 619
execute if score #points survisland.data matches 620 run xp set @s 620
execute if score #points survisland.data matches 621 run xp set @s 621
execute if score #points survisland.data matches 622 run xp set @s 622
execute if score #points survisland.data matches 623 run xp set @s 623
execute if score #points survisland.data matches 624 run xp set @s 624
execute if score #points survisland.data matches 625 run xp set @s 625
execute if score #points survisland.data matches 626 run xp set @s 626
execute if score #points survisland.data matches 627 run xp set @s 627
execute if score #points survisland.data matches 628 run xp set @s 628
execute if score #points survisland.data matches 629 run xp set @s 629
execute if score #points survisland.data matches 630 run xp set @s 630
execute if score #points survisland.data matches 631 run xp set @s 631
execute if score #points survisland.data matches 632 run xp set @s 632
execute if score #points survisland.data matches 633 run xp set @s 633
execute if score #points survisland.data matches 634 run xp set @s 634
execute if score #points survisland.data matches 635 run xp set @s 635
execute if score #points survisland.data matches 636 run xp set @s 636
execute if score #points survisland.data matches 637 run xp set @s 637
execute if score #points survisland.data matches 638 run xp set @s 638
execute if score #points survisland.data matches 639 run xp set @s 639
execute if score #points survisland.data matches 640 run xp set @s 640
execute if score #points survisland.data matches 641 run xp set @s 641
execute if score #points survisland.data matches 642 run xp set @s 642
execute if score #points survisland.data matches 643 run xp set @s 643
execute if score #points survisland.data matches 644 run xp set @s 644
execute if score #points survisland.data matches 645 run xp set @s 645
execute if score #points survisland.data matches 646 run xp set @s 646
execute if score #points survisland.data matches 647 run xp set @s 647
execute if score #points survisland.data matches 648 run xp set @s 648
execute if score #points survisland.data matches 649 run xp set @s 649
execute if score #points survisland.data matches 650 run xp set @s 650
execute if score #points survisland.data matches 651 run xp set @s 651
execute if score #points survisland.data matches 652 run xp set @s 652
execute if score #points survisland.data matches 653 run xp set @s 653
execute if score #points survisland.data matches 654 run xp set @s 654
execute if score #points survisland.data matches 655 run xp set @s 655
execute if score #points survisland.data matches 656 run xp set @s 656
execute if score #points survisland.data matches 657 run xp set @s 657
execute if score #points survisland.data matches 658 run xp set @s 658
execute if score #points survisland.data matches 659 run xp set @s 659
execute if score #points survisland.data matches 660 run xp set @s 660
execute if score #points survisland.data matches 661 run xp set @s 661
execute if score #points survisland.data matches 662 run xp set @s 662
execute if score #points survisland.data matches 663 run xp set @s 663
execute if score #points survisland.data matches 664 run xp set @s 664
execute if score #points survisland.data matches 665 run xp set @s 665
execute if score #points survisland.data matches 666 run xp set @s 666
execute if score #points survisland.data matches 667 run xp set @s 667
execute if score #points survisland.data matches 668 run xp set @s 668
execute if score #points survisland.data matches 669 run xp set @s 669
execute if score #points survisland.data matches 670 run xp set @s 670
execute if score #points survisland.data matches 671 run xp set @s 671
execute if score #points survisland.data matches 672 run xp set @s 672
execute if score #points survisland.data matches 673 run xp set @s 673
execute if score #points survisland.data matches 674 run xp set @s 674
execute if score #points survisland.data matches 675 run xp set @s 675
execute if score #points survisland.data matches 676 run xp set @s 676
execute if score #points survisland.data matches 677 run xp set @s 677
execute if score #points survisland.data matches 678 run xp set @s 678
execute if score #points survisland.data matches 679 run xp set @s 679
execute if score #points survisland.data matches 680 run xp set @s 680
execute if score #points survisland.data matches 681 run xp set @s 681
execute if score #points survisland.data matches 682 run xp set @s 682
execute if score #points survisland.data matches 683 run xp set @s 683
execute if score #points survisland.data matches 684 run xp set @s 684
execute if score #points survisland.data matches 685 run xp set @s 685
execute if score #points survisland.data matches 686 run xp set @s 686
execute if score #points survisland.data matches 687 run xp set @s 687
execute if score #points survisland.data matches 688 run xp set @s 688
execute if score #points survisland.data matches 689 run xp set @s 689
execute if score #points survisland.data matches 690 run xp set @s 690
execute if score #points survisland.data matches 691 run xp set @s 691
execute if score #points survisland.data matches 692 run xp set @s 692
execute if score #points survisland.data matches 693 run xp set @s 693
execute if score #points survisland.data matches 694 run xp set @s 694
execute if score #points survisland.data matches 695 run xp set @s 695
execute if score #points survisland.data matches 696 run xp set @s 696
execute if score #points survisland.data matches 697 run xp set @s 697
execute if score #points survisland.data matches 698 run xp set @s 698
execute if score #points survisland.data matches 699 run xp set @s 699
execute if score #points survisland.data matches 700 run xp set @s 700
execute if score #points survisland.data matches 701 run xp set @s 701
execute if score #points survisland.data matches 702 run xp set @s 702
execute if score #points survisland.data matches 703 run xp set @s 703
execute if score #points survisland.data matches 704 run xp set @s 704
execute if score #points survisland.data matches 705 run xp set @s 705
execute if score #points survisland.data matches 706 run xp set @s 706
execute if score #points survisland.data matches 707 run xp set @s 707
execute if score #points survisland.data matches 708 run xp set @s 708
execute if score #points survisland.data matches 709 run xp set @s 709
execute if score #points survisland.data matches 710 run xp set @s 710
execute if score #points survisland.data matches 711 run xp set @s 711
execute if score #points survisland.data matches 712 run xp set @s 712
execute if score #points survisland.data matches 713 run xp set @s 713
execute if score #points survisland.data matches 714 run xp set @s 714
execute if score #points survisland.data matches 715 run xp set @s 715
execute if score #points survisland.data matches 716 run xp set @s 716
execute if score #points survisland.data matches 717 run xp set @s 717
execute if score #points survisland.data matches 718 run xp set @s 718
execute if score #points survisland.data matches 719 run xp set @s 719
execute if score #points survisland.data matches 720 run xp set @s 720
execute if score #points survisland.data matches 721 run xp set @s 721
execute if score #points survisland.data matches 722 run xp set @s 722
execute if score #points survisland.data matches 723 run xp set @s 723
execute if score #points survisland.data matches 724 run xp set @s 724
execute if score #points survisland.data matches 725 run xp set @s 725
execute if score #points survisland.data matches 726 run xp set @s 726
execute if score #points survisland.data matches 727 run xp set @s 727
execute if score #points survisland.data matches 728 run xp set @s 728
execute if score #points survisland.data matches 729 run xp set @s 729
execute if score #points survisland.data matches 730 run xp set @s 730
execute if score #points survisland.data matches 731 run xp set @s 731
execute if score #points survisland.data matches 732 run xp set @s 732
execute if score #points survisland.data matches 733 run xp set @s 733
execute if score #points survisland.data matches 734 run xp set @s 734
execute if score #points survisland.data matches 735 run xp set @s 735
execute if score #points survisland.data matches 736 run xp set @s 736
execute if score #points survisland.data matches 737 run xp set @s 737
execute if score #points survisland.data matches 738 run xp set @s 738
execute if score #points survisland.data matches 739 run xp set @s 739
execute if score #points survisland.data matches 740 run xp set @s 740
execute if score #points survisland.data matches 741 run xp set @s 741
execute if score #points survisland.data matches 742 run xp set @s 742
execute if score #points survisland.data matches 743 run xp set @s 743
execute if score #points survisland.data matches 744 run xp set @s 744
execute if score #points survisland.data matches 745 run xp set @s 745
execute if score #points survisland.data matches 746 run xp set @s 746
execute if score #points survisland.data matches 747 run xp set @s 747
execute if score #points survisland.data matches 748 run xp set @s 748
execute if score #points survisland.data matches 749 run xp set @s 749
execute if score #points survisland.data matches 750 run xp set @s 750
execute if score #points survisland.data matches 751 run xp set @s 751
execute if score #points survisland.data matches 752 run xp set @s 752
execute if score #points survisland.data matches 753 run xp set @s 753
execute if score #points survisland.data matches 754 run xp set @s 754
execute if score #points survisland.data matches 755 run xp set @s 755
execute if score #points survisland.data matches 756 run xp set @s 756
execute if score #points survisland.data matches 757 run xp set @s 757
execute if score #points survisland.data matches 758 run xp set @s 758
execute if score #points survisland.data matches 759 run xp set @s 759
execute if score #points survisland.data matches 760 run xp set @s 760
execute if score #points survisland.data matches 761 run xp set @s 761
execute if score #points survisland.data matches 762 run xp set @s 762
execute if score #points survisland.data matches 763 run xp set @s 763
execute if score #points survisland.data matches 764 run xp set @s 764
execute if score #points survisland.data matches 765 run xp set @s 765
execute if score #points survisland.data matches 766 run xp set @s 766
execute if score #points survisland.data matches 767 run xp set @s 767
execute if score #points survisland.data matches 768 run xp set @s 768
execute if score #points survisland.data matches 769 run xp set @s 769
execute if score #points survisland.data matches 770 run xp set @s 770
execute if score #points survisland.data matches 771 run xp set @s 771
execute if score #points survisland.data matches 772 run xp set @s 772
execute if score #points survisland.data matches 773 run xp set @s 773
execute if score #points survisland.data matches 774 run xp set @s 774
execute if score #points survisland.data matches 775 run xp set @s 775
execute if score #points survisland.data matches 776 run xp set @s 776
execute if score #points survisland.data matches 777 run xp set @s 777
execute if score #points survisland.data matches 778 run xp set @s 778
execute if score #points survisland.data matches 779 run xp set @s 779
execute if score #points survisland.data matches 780 run xp set @s 780
execute if score #points survisland.data matches 781 run xp set @s 781
execute if score #points survisland.data matches 782 run xp set @s 782
execute if score #points survisland.data matches 783 run xp set @s 783
execute if score #points survisland.data matches 784 run xp set @s 784
execute if score #points survisland.data matches 785 run xp set @s 785
execute if score #points survisland.data matches 786 run xp set @s 786
execute if score #points survisland.data matches 787 run xp set @s 787
execute if score #points survisland.data matches 788 run xp set @s 788
execute if score #points survisland.data matches 789 run xp set @s 789
execute if score #points survisland.data matches 790 run xp set @s 790
execute if score #points survisland.data matches 791 run xp set @s 791
execute if score #points survisland.data matches 792 run xp set @s 792
execute if score #points survisland.data matches 793 run xp set @s 793
execute if score #points survisland.data matches 794 run xp set @s 794
execute if score #points survisland.data matches 795 run xp set @s 795
execute if score #points survisland.data matches 796 run xp set @s 796
execute if score #points survisland.data matches 797 run xp set @s 797
execute if score #points survisland.data matches 798 run xp set @s 798
execute if score #points survisland.data matches 799 run xp set @s 799
execute if score #points survisland.data matches 800 run xp set @s 800
execute if score #points survisland.data matches 801 run xp set @s 801
execute if score #points survisland.data matches 802 run xp set @s 802
execute if score #points survisland.data matches 803 run xp set @s 803
execute if score #points survisland.data matches 804 run xp set @s 804
execute if score #points survisland.data matches 805 run xp set @s 805
execute if score #points survisland.data matches 806 run xp set @s 806
execute if score #points survisland.data matches 807 run xp set @s 807
execute if score #points survisland.data matches 808 run xp set @s 808
execute if score #points survisland.data matches 809 run xp set @s 809
execute if score #points survisland.data matches 810 run xp set @s 810
execute if score #points survisland.data matches 811 run xp set @s 811
execute if score #points survisland.data matches 812 run xp set @s 812
execute if score #points survisland.data matches 813 run xp set @s 813
execute if score #points survisland.data matches 814 run xp set @s 814
execute if score #points survisland.data matches 815 run xp set @s 815
execute if score #points survisland.data matches 816 run xp set @s 816
execute if score #points survisland.data matches 817 run xp set @s 817
execute if score #points survisland.data matches 818 run xp set @s 818
execute if score #points survisland.data matches 819 run xp set @s 819
execute if score #points survisland.data matches 820 run xp set @s 820
execute if score #points survisland.data matches 821 run xp set @s 821
execute if score #points survisland.data matches 822 run xp set @s 822
execute if score #points survisland.data matches 823 run xp set @s 823
execute if score #points survisland.data matches 824 run xp set @s 824
execute if score #points survisland.data matches 825 run xp set @s 825
execute if score #points survisland.data matches 826 run xp set @s 826
execute if score #points survisland.data matches 827 run xp set @s 827
execute if score #points survisland.data matches 828 run xp set @s 828
execute if score #points survisland.data matches 829 run xp set @s 829
execute if score #points survisland.data matches 830 run xp set @s 830
execute if score #points survisland.data matches 831 run xp set @s 831
execute if score #points survisland.data matches 832 run xp set @s 832
execute if score #points survisland.data matches 833 run xp set @s 833
execute if score #points survisland.data matches 834 run xp set @s 834
execute if score #points survisland.data matches 835 run xp set @s 835
execute if score #points survisland.data matches 836 run xp set @s 836
execute if score #points survisland.data matches 837 run xp set @s 837
execute if score #points survisland.data matches 838 run xp set @s 838
execute if score #points survisland.data matches 839 run xp set @s 839
execute if score #points survisland.data matches 840 run xp set @s 840
execute if score #points survisland.data matches 841 run xp set @s 841
execute if score #points survisland.data matches 842 run xp set @s 842
execute if score #points survisland.data matches 843 run xp set @s 843
execute if score #points survisland.data matches 844 run xp set @s 844
execute if score #points survisland.data matches 845 run xp set @s 845
execute if score #points survisland.data matches 846 run xp set @s 846
execute if score #points survisland.data matches 847 run xp set @s 847
execute if score #points survisland.data matches 848 run xp set @s 848
execute if score #points survisland.data matches 849 run xp set @s 849
execute if score #points survisland.data matches 850 run xp set @s 850
execute if score #points survisland.data matches 851 run xp set @s 851
execute if score #points survisland.data matches 852 run xp set @s 852
execute if score #points survisland.data matches 853 run xp set @s 853
execute if score #points survisland.data matches 854 run xp set @s 854
execute if score #points survisland.data matches 855 run xp set @s 855
execute if score #points survisland.data matches 856 run xp set @s 856
execute if score #points survisland.data matches 857 run xp set @s 857
execute if score #points survisland.data matches 858 run xp set @s 858
execute if score #points survisland.data matches 859 run xp set @s 859
execute if score #points survisland.data matches 860 run xp set @s 860
execute if score #points survisland.data matches 861 run xp set @s 861
execute if score #points survisland.data matches 862 run xp set @s 862
execute if score #points survisland.data matches 863 run xp set @s 863
execute if score #points survisland.data matches 864 run xp set @s 864
execute if score #points survisland.data matches 865 run xp set @s 865
execute if score #points survisland.data matches 866 run xp set @s 866
execute if score #points survisland.data matches 867 run xp set @s 867
execute if score #points survisland.data matches 868 run xp set @s 868
execute if score #points survisland.data matches 869 run xp set @s 869
execute if score #points survisland.data matches 870 run xp set @s 870
execute if score #points survisland.data matches 871 run xp set @s 871
execute if score #points survisland.data matches 872 run xp set @s 872
execute if score #points survisland.data matches 873 run xp set @s 873
execute if score #points survisland.data matches 874 run xp set @s 874
execute if score #points survisland.data matches 875 run xp set @s 875
execute if score #points survisland.data matches 876 run xp set @s 876
execute if score #points survisland.data matches 877 run xp set @s 877
execute if score #points survisland.data matches 878 run xp set @s 878
execute if score #points survisland.data matches 879 run xp set @s 879
execute if score #points survisland.data matches 880 run xp set @s 880
execute if score #points survisland.data matches 881 run xp set @s 881
execute if score #points survisland.data matches 882 run xp set @s 882
execute if score #points survisland.data matches 883 run xp set @s 883
execute if score #points survisland.data matches 884 run xp set @s 884
execute if score #points survisland.data matches 885 run xp set @s 885
execute if score #points survisland.data matches 886 run xp set @s 886
execute if score #points survisland.data matches 887 run xp set @s 887
execute if score #points survisland.data matches 888 run xp set @s 888
execute if score #points survisland.data matches 889 run xp set @s 889
execute if score #points survisland.data matches 890 run xp set @s 890
execute if score #points survisland.data matches 891 run xp set @s 891
execute if score #points survisland.data matches 892 run xp set @s 892
execute if score #points survisland.data matches 893 run xp set @s 893
execute if score #points survisland.data matches 894 run xp set @s 894
execute if score #points survisland.data matches 895 run xp set @s 895
execute if score #points survisland.data matches 896 run xp set @s 896
execute if score #points survisland.data matches 897 run xp set @s 897
execute if score #points survisland.data matches 898 run xp set @s 898
execute if score #points survisland.data matches 899 run xp set @s 899
execute if score #points survisland.data matches 900 run xp set @s 900
execute if score #points survisland.data matches 901 run xp set @s 901
execute if score #points survisland.data matches 902 run xp set @s 902
execute if score #points survisland.data matches 903 run xp set @s 903
execute if score #points survisland.data matches 904 run xp set @s 904
execute if score #points survisland.data matches 905 run xp set @s 905
execute if score #points survisland.data matches 906 run xp set @s 906
execute if score #points survisland.data matches 907 run xp set @s 907
execute if score #points survisland.data matches 908 run xp set @s 908
execute if score #points survisland.data matches 909 run xp set @s 909
execute if score #points survisland.data matches 910 run xp set @s 910
execute if score #points survisland.data matches 911 run xp set @s 911
execute if score #points survisland.data matches 912 run xp set @s 912
execute if score #points survisland.data matches 913 run xp set @s 913
execute if score #points survisland.data matches 914 run xp set @s 914
execute if score #points survisland.data matches 915 run xp set @s 915
execute if score #points survisland.data matches 916 run xp set @s 916
execute if score #points survisland.data matches 917 run xp set @s 917
execute if score #points survisland.data matches 918 run xp set @s 918
execute if score #points survisland.data matches 919 run xp set @s 919
execute if score #points survisland.data matches 920 run xp set @s 920
execute if score #points survisland.data matches 921 run xp set @s 921
execute if score #points survisland.data matches 922 run xp set @s 922
execute if score #points survisland.data matches 923 run xp set @s 923
execute if score #points survisland.data matches 924 run xp set @s 924
execute if score #points survisland.data matches 925 run xp set @s 925
execute if score #points survisland.data matches 926 run xp set @s 926
execute if score #points survisland.data matches 927 run xp set @s 927
execute if score #points survisland.data matches 928 run xp set @s 928
execute if score #points survisland.data matches 929 run xp set @s 929
execute if score #points survisland.data matches 930 run xp set @s 930
execute if score #points survisland.data matches 931 run xp set @s 931
execute if score #points survisland.data matches 932 run xp set @s 932
execute if score #points survisland.data matches 933 run xp set @s 933
execute if score #points survisland.data matches 934 run xp set @s 934
execute if score #points survisland.data matches 935 run xp set @s 935
execute if score #points survisland.data matches 936 run xp set @s 936
execute if score #points survisland.data matches 937 run xp set @s 937
execute if score #points survisland.data matches 938 run xp set @s 938
execute if score #points survisland.data matches 939 run xp set @s 939
execute if score #points survisland.data matches 940 run xp set @s 940
execute if score #points survisland.data matches 941 run xp set @s 941
execute if score #points survisland.data matches 942 run xp set @s 942
execute if score #points survisland.data matches 943 run xp set @s 943
execute if score #points survisland.data matches 944 run xp set @s 944
execute if score #points survisland.data matches 945 run xp set @s 945
execute if score #points survisland.data matches 946 run xp set @s 946
execute if score #points survisland.data matches 947 run xp set @s 947
execute if score #points survisland.data matches 948 run xp set @s 948
execute if score #points survisland.data matches 949 run xp set @s 949
execute if score #points survisland.data matches 950 run xp set @s 950
execute if score #points survisland.data matches 951 run xp set @s 951
execute if score #points survisland.data matches 952 run xp set @s 952
execute if score #points survisland.data matches 953 run xp set @s 953
execute if score #points survisland.data matches 954 run xp set @s 954
execute if score #points survisland.data matches 955 run xp set @s 955
execute if score #points survisland.data matches 956 run xp set @s 956
execute if score #points survisland.data matches 957 run xp set @s 957
execute if score #points survisland.data matches 958 run xp set @s 958
execute if score #points survisland.data matches 959 run xp set @s 959
execute if score #points survisland.data matches 960 run xp set @s 960
execute if score #points survisland.data matches 961 run xp set @s 961
execute if score #points survisland.data matches 962 run xp set @s 962
execute if score #points survisland.data matches 963 run xp set @s 963
execute if score #points survisland.data matches 964 run xp set @s 964
execute if score #points survisland.data matches 965 run xp set @s 965
execute if score #points survisland.data matches 966 run xp set @s 966
execute if score #points survisland.data matches 967 run xp set @s 967
execute if score #points survisland.data matches 968 run xp set @s 968
execute if score #points survisland.data matches 969 run xp set @s 969
execute if score #points survisland.data matches 970 run xp set @s 970
execute if score #points survisland.data matches 971 run xp set @s 971
execute if score #points survisland.data matches 972 run xp set @s 972
execute if score #points survisland.data matches 973 run xp set @s 973
execute if score #points survisland.data matches 974 run xp set @s 974
execute if score #points survisland.data matches 975 run xp set @s 975
execute if score #points survisland.data matches 976 run xp set @s 976
execute if score #points survisland.data matches 977 run xp set @s 977
execute if score #points survisland.data matches 978 run xp set @s 978
execute if score #points survisland.data matches 979 run xp set @s 979
execute if score #points survisland.data matches 980 run xp set @s 980
execute if score #points survisland.data matches 981 run xp set @s 981
execute if score #points survisland.data matches 982 run xp set @s 982
execute if score #points survisland.data matches 983 run xp set @s 983
execute if score #points survisland.data matches 984 run xp set @s 984
execute if score #points survisland.data matches 985 run xp set @s 985
execute if score #points survisland.data matches 986 run xp set @s 986
execute if score #points survisland.data matches 987 run xp set @s 987
execute if score #points survisland.data matches 988 run xp set @s 988
execute if score #points survisland.data matches 989 run xp set @s 989
execute if score #points survisland.data matches 990 run xp set @s 990
execute if score #points survisland.data matches 991 run xp set @s 991
execute if score #points survisland.data matches 992 run xp set @s 992
execute if score #points survisland.data matches 993 run xp set @s 993
execute if score #points survisland.data matches 994 run xp set @s 994
execute if score #points survisland.data matches 995 run xp set @s 995
execute if score #points survisland.data matches 996 run xp set @s 996
execute if score #points survisland.data matches 997 run xp set @s 997
execute if score #points survisland.data matches 998 run xp set @s 998
execute if score #points survisland.data matches 999 run xp set @s 999
execute if score #points survisland.data matches 1000.. run xp set @s 1000
xp set @s 0 levels

