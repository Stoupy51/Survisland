
#> survisland:v2.5.1/load/resolve
#
# @within	#survisland:resolve
#

# If correct version, load the datapack
execute if score #survisland.major load.status matches 2 if score #survisland.minor load.status matches 5 if score #survisland.patch load.status matches 1 run function survisland:v2.5.1/load/main

