
#> survisland:modes/cache_s13/update_sidebar_points
#
# @executed	as the player & at current position
#
# @within	survisland:modes/cache_s13/adv/add_points
#			survisland:modes/cache_s13/process_end
#			survisland:modes/cache_s13/second
#

execute if score #mSambor_points survisland.data matches -100 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"-100","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches -100 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"-100","color":"yellow"}]
execute if score #mSambor_points survisland.data matches -90 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"-90","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches -90 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"-90","color":"yellow"}]
execute if score #mSambor_points survisland.data matches -80 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"-80","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches -80 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"-80","color":"yellow"}]
execute if score #mSambor_points survisland.data matches -70 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"-70","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches -70 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"-70","color":"yellow"}]
execute if score #mSambor_points survisland.data matches -60 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"-60","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches -60 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"-60","color":"yellow"}]
execute if score #mSambor_points survisland.data matches -50 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"-50","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches -50 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"-50","color":"yellow"}]
execute if score #mSambor_points survisland.data matches -40 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"-40","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches -40 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"-40","color":"yellow"}]
execute if score #mSambor_points survisland.data matches -30 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"-30","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches -30 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"-30","color":"yellow"}]
execute if score #mSambor_points survisland.data matches -20 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"-20","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches -20 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"-20","color":"yellow"}]
execute if score #mSambor_points survisland.data matches -10 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"-10","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches -10 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"-10","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 0 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"0","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 0 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"0","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 10 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"10","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 10 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"10","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 20 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"20","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 20 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"20","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 30 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"30","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 30 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"30","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 40 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"40","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 40 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"40","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 50 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"50","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 50 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"50","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 60 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"60","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 60 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"60","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 70 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"70","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 70 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"70","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 80 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"80","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 80 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"80","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 90 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"90","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 90 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"90","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 100 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"100","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 100 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"100","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 110 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"110","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 110 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"110","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 120 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"120","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 120 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"120","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 130 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"130","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 130 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"130","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 140 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"140","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 140 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"140","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 150 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"150","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 150 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"150","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 160 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"160","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 160 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"160","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 170 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"170","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 170 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"170","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 180 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"180","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 180 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"180","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 190 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"190","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 190 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"190","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 200 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"200","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 200 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"200","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 210 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"210","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 210 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"210","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 220 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"220","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 220 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"220","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 230 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"230","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 230 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"230","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 240 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"240","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 240 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"240","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 250 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"250","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 250 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"250","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 260 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"260","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 260 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"260","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 270 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"270","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 270 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"270","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 280 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"280","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 280 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"280","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 290 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"290","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 290 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"290","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 300 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"300","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 300 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"300","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 310 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"310","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 310 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"310","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 320 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"320","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 320 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"320","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 330 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"330","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 330 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"330","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 340 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"340","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 340 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"340","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 350 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"350","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 350 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"350","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 360 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"360","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 360 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"360","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 370 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"370","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 370 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"370","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 380 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"380","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 380 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"380","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 390 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"390","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 390 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"390","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 400 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"400","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 400 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"400","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 410 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"410","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 410 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"410","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 420 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"420","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 420 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"420","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 430 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"430","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 430 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"430","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 440 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"440","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 440 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"440","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 450 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"450","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 450 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"450","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 460 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"460","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 460 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"460","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 470 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"470","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 470 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"470","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 480 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"480","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 480 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"480","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 490 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"490","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 490 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"490","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 500 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"500","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 500 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"500","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 510 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"510","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 510 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"510","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 520 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"520","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 520 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"520","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 530 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"530","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 530 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"530","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 540 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"540","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 540 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"540","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 550 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"550","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 550 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"550","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 560 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"560","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 560 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"560","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 570 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"570","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 570 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"570","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 580 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"580","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 580 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"580","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 590 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"590","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 590 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"590","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 600 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"600","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 600 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"600","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 610 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"610","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 610 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"610","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 620 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"620","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 620 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"620","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 630 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"630","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 630 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"630","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 640 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"640","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 640 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"640","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 650 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"650","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 650 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"650","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 660 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"660","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 660 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"660","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 670 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"670","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 670 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"670","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 680 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"680","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 680 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"680","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 690 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"690","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 690 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"690","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 700 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"700","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 700 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"700","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 710 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"710","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 710 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"710","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 720 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"720","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 720 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"720","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 730 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"730","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 730 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"730","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 740 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"740","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 740 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"740","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 750 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"750","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 750 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"750","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 760 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"760","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 760 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"760","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 770 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"770","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 770 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"770","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 780 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"780","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 780 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"780","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 790 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"790","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 790 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"790","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 800 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"800","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 800 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"800","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 810 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"810","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 810 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"810","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 820 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"820","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 820 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"820","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 830 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"830","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 830 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"830","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 840 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"840","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 840 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"840","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 850 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"850","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 850 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"850","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 860 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"860","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 860 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"860","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 870 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"870","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 870 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"870","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 880 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"880","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 880 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"880","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 890 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"890","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 890 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"890","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 900 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"900","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 900 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"900","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 910 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"910","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 910 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"910","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 920 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"920","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 920 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"920","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 930 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"930","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 930 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"930","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 940 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"940","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 940 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"940","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 950 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"950","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 950 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"950","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 960 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"960","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 960 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"960","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 970 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"970","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 970 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"970","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 980 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"980","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 980 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"980","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 990 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"990","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 990 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"990","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1000 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1000","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1000 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1000","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1010 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1010","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1010 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1010","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1020 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1020","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1020 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1020","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1030 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1030","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1030 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1030","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1040 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1040","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1040 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1040","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1050 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1050","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1050 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1050","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1060 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1060","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1060 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1060","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1070 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1070","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1070 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1070","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1080 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1080","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1080 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1080","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1090 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1090","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1090 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1090","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1100 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1100","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1100 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1100","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1110 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1110","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1110 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1110","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1120 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1120","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1120 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1120","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1130 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1130","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1130 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1130","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1140 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1140","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1140 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1140","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1150 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1150","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1150 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1150","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1160 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1160","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1160 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1160","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1170 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1170","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1170 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1170","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1180 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1180","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1180 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1180","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1190 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1190","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1190 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1190","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1200 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1200","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1200 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1200","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1210 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1210","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1210 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1210","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1220 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1220","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1220 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1220","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1230 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1230","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1230 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1230","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1240 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1240","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1240 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1240","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1250 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1250","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1250 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1250","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1260 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1260","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1260 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1260","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1270 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1270","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1270 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1270","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1280 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1280","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1280 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1280","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1290 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1290","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1290 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1290","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1300 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1300","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1300 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1300","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1310 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1310","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1310 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1310","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1320 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1320","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1320 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1320","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1330 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1330","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1330 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1330","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1340 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1340","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1340 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1340","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1350 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1350","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1350 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1350","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1360 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1360","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1360 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1360","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1370 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1370","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1370 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1370","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1380 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1380","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1380 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1380","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1390 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1390","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1390 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1390","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1400 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1400","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1400 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1400","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1410 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1410","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1410 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1410","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1420 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1420","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1420 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1420","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1430 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1430","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1430 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1430","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1440 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1440","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1440 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1440","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1450 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1450","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1450 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1450","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1460 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1460","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1460 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1460","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1470 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1470","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1470 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1470","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1480 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1480","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1480 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1480","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1490 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1490","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1490 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1490","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1500 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1500","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1500 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1500","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1510 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1510","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1510 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1510","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1520 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1520","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1520 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1520","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1530 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1530","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1530 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1530","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1540 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1540","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1540 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1540","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1550 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1550","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1550 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1550","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1560 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1560","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1560 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1560","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1570 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1570","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1570 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1570","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1580 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1580","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1580 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1580","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1590 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1590","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1590 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1590","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1600 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1600","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1600 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1600","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1610 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1610","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1610 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1610","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1620 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1620","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1620 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1620","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1630 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1630","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1630 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1630","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1640 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1640","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1640 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1640","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1650 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1650","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1650 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1650","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1660 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1660","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1660 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1660","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1670 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1670","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1670 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1670","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1680 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1680","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1680 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1680","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1690 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1690","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1690 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1690","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1700 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1700","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1700 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1700","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1710 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1710","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1710 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1710","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1720 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1720","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1720 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1720","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1730 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1730","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1730 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1730","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1740 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1740","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1740 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1740","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1750 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1750","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1750 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1750","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1760 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1760","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1760 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1760","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1770 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1770","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1770 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1770","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1780 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1780","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1780 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1780","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1790 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1790","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1790 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1790","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1800 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1800","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1800 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1800","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1810 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1810","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1810 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1810","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1820 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1820","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1820 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1820","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1830 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1830","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1830 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1830","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1840 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1840","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1840 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1840","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1850 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1850","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1850 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1850","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1860 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1860","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1860 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1860","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1870 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1870","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1870 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1870","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1880 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1880","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1880 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1880","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1890 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1890","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1890 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1890","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1900 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1900","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1900 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1900","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1910 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1910","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1910 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1910","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1920 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1920","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1920 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1920","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1930 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1930","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1930 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1930","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1940 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1940","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1940 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1940","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1950 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1950","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1950 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1950","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1960 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1960","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1960 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1960","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1970 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1970","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1970 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1970","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1980 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1980","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1980 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1980","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 1990 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"1990","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 1990 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"1990","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2000 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2000","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2000 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2000","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2010 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2010","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2010 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2010","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2020 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2020","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2020 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2020","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2030 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2030","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2030 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2030","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2040 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2040","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2040 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2040","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2050 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2050","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2050 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2050","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2060 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2060","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2060 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2060","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2070 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2070","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2070 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2070","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2080 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2080","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2080 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2080","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2090 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2090","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2090 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2090","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2100 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2100","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2100 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2100","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2110 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2110","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2110 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2110","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2120 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2120","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2120 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2120","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2130 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2130","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2130 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2130","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2140 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2140","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2140 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2140","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2150 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2150","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2150 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2150","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2160 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2160","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2160 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2160","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2170 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2170","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2170 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2170","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2180 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2180","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2180 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2180","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2190 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2190","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2190 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2190","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2200 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2200","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2200 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2200","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2210 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2210","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2210 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2210","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2220 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2220","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2220 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2220","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2230 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2230","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2230 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2230","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2240 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2240","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2240 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2240","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2250 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2250","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2250 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2250","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2260 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2260","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2260 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2260","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2270 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2270","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2270 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2270","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2280 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2280","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2280 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2280","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2290 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2290","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2290 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2290","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2300 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2300","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2300 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2300","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2310 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2310","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2310 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2310","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2320 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2320","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2320 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2320","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2330 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2330","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2330 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2330","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2340 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2340","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2340 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2340","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2350 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2350","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2350 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2350","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2360 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2360","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2360 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2360","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2370 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2370","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2370 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2370","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2380 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2380","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2380 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2380","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2390 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2390","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2390 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2390","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2400 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2400","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2400 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2400","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2410 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2410","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2410 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2410","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2420 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2420","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2420 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2420","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2430 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2430","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2430 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2430","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2440 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2440","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2440 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2440","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2450 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2450","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2450 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2450","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2460 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2460","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2460 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2460","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2470 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2470","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2470 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2470","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2480 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2480","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2480 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2480","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2490 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2490","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2490 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2490","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2500 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2500","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2500 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2500","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2510 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2510","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2510 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2510","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2520 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2520","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2520 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2520","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2530 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2530","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2530 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2530","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2540 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2540","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2540 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2540","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2550 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2550","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2550 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2550","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2560 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2560","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2560 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2560","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2570 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2570","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2570 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2570","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2580 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2580","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2580 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2580","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2590 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2590","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2590 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2590","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2600 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2600","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2600 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2600","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2610 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2610","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2610 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2610","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2620 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2620","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2620 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2620","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2630 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2630","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2630 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2630","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2640 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2640","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2640 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2640","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2650 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2650","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2650 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2650","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2660 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2660","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2660 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2660","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2670 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2670","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2670 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2670","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2680 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2680","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2680 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2680","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2690 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2690","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2690 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2690","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2700 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2700","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2700 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2700","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2710 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2710","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2710 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2710","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2720 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2720","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2720 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2720","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2730 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2730","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2730 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2730","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2740 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2740","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2740 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2740","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2750 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2750","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2750 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2750","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2760 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2760","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2760 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2760","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2770 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2770","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2770 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2770","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2780 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2780","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2780 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2780","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2790 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2790","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2790 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2790","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2800 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2800","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2800 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2800","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2810 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2810","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2810 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2810","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2820 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2820","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2820 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2820","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2830 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2830","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2830 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2830","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2840 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2840","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2840 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2840","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2850 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2850","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2850 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2850","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2860 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2860","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2860 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2860","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2870 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2870","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2870 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2870","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2880 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2880","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2880 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2880","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2890 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2890","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2890 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2890","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2900 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2900","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2900 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2900","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2910 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2910","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2910 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2910","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2920 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2920","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2920 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2920","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2930 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2930","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2930 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2930","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2940 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2940","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2940 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2940","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2950 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2950","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2950 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2950","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2960 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2960","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2960 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2960","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2970 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2970","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2970 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2970","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2980 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2980","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2980 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2980","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 2990 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"2990","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 2990 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"2990","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3000 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3000","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3000 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3000","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3010 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3010","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3010 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3010","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3020 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3020","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3020 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3020","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3030 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3030","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3030 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3030","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3040 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3040","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3040 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3040","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3050 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3050","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3050 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3050","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3060 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3060","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3060 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3060","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3070 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3070","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3070 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3070","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3080 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3080","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3080 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3080","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3090 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3090","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3090 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3090","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3100 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3100","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3100 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3100","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3110 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3110","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3110 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3110","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3120 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3120","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3120 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3120","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3130 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3130","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3130 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3130","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3140 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3140","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3140 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3140","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3150 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3150","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3150 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3150","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3160 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3160","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3160 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3160","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3170 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3170","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3170 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3170","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3180 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3180","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3180 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3180","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3190 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3190","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3190 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3190","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3200 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3200","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3200 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3200","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3210 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3210","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3210 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3210","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3220 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3220","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3220 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3220","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3230 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3230","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3230 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3230","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3240 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3240","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3240 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3240","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3250 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3250","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3250 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3250","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3260 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3260","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3260 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3260","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3270 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3270","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3270 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3270","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3280 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3280","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3280 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3280","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3290 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3290","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3290 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3290","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3300 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3300","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3300 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3300","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3310 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3310","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3310 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3310","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3320 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3320","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3320 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3320","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3330 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3330","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3330 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3330","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3340 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3340","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3340 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3340","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3350 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3350","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3350 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3350","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3360 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3360","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3360 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3360","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3370 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3370","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3370 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3370","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3380 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3380","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3380 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3380","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3390 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3390","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3390 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3390","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3400 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3400","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3400 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3400","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3410 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3410","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3410 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3410","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3420 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3420","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3420 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3420","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3430 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3430","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3430 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3430","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3440 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3440","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3440 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3440","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3450 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3450","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3450 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3450","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3460 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3460","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3460 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3460","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3470 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3470","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3470 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3470","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3480 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3480","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3480 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3480","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3490 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3490","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3490 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3490","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3500 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3500","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3500 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3500","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3510 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3510","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3510 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3510","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3520 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3520","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3520 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3520","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3530 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3530","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3530 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3530","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3540 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3540","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3540 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3540","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3550 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3550","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3550 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3550","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3560 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3560","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3560 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3560","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3570 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3570","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3570 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3570","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3580 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3580","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3580 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3580","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3590 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3590","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3590 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3590","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3600 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3600","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3600 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3600","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3610 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3610","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3610 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3610","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3620 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3620","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3620 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3620","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3630 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3630","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3630 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3630","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3640 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3640","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3640 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3640","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3650 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3650","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3650 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3650","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3660 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3660","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3660 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3660","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3670 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3670","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3670 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3670","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3680 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3680","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3680 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3680","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3690 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3690","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3690 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3690","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3700 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3700","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3700 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3700","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3710 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3710","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3710 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3710","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3720 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3720","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3720 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3720","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3730 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3730","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3730 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3730","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3740 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3740","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3740 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3740","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3750 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3750","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3750 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3750","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3760 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3760","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3760 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3760","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3770 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3770","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3770 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3770","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3780 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3780","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3780 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3780","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3790 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3790","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3790 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3790","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3800 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3800","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3800 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3800","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3810 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3810","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3810 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3810","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3820 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3820","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3820 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3820","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3830 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3830","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3830 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3830","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3840 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3840","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3840 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3840","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3850 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3850","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3850 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3850","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3860 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3860","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3860 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3860","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3870 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3870","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3870 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3870","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3880 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3880","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3880 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3880","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3890 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3890","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3890 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3890","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3900 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3900","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3900 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3900","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3910 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3910","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3910 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3910","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3920 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3920","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3920 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3920","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3930 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3930","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3930 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3930","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3940 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3940","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3940 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3940","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3950 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3950","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3950 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3950","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3960 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3960","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3960 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3960","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3970 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3970","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3970 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3970","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3980 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3980","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3980 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3980","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 3990 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"3990","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 3990 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"3990","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4000 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4000","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4000 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4000","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4010 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4010","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4010 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4010","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4020 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4020","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4020 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4020","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4030 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4030","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4030 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4030","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4040 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4040","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4040 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4040","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4050 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4050","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4050 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4050","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4060 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4060","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4060 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4060","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4070 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4070","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4070 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4070","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4080 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4080","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4080 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4080","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4090 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4090","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4090 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4090","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4100 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4100","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4100 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4100","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4110 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4110","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4110 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4110","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4120 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4120","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4120 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4120","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4130 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4130","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4130 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4130","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4140 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4140","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4140 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4140","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4150 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4150","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4150 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4150","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4160 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4160","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4160 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4160","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4170 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4170","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4170 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4170","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4180 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4180","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4180 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4180","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4190 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4190","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4190 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4190","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4200 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4200","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4200 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4200","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4210 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4210","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4210 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4210","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4220 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4220","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4220 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4220","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4230 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4230","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4230 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4230","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4240 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4240","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4240 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4240","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4250 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4250","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4250 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4250","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4260 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4260","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4260 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4260","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4270 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4270","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4270 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4270","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4280 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4280","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4280 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4280","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4290 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4290","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4290 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4290","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4300 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4300","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4300 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4300","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4310 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4310","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4310 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4310","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4320 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4320","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4320 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4320","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4330 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4330","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4330 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4330","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4340 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4340","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4340 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4340","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4350 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4350","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4350 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4350","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4360 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4360","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4360 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4360","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4370 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4370","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4370 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4370","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4380 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4380","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4380 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4380","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4390 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4390","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4390 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4390","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4400 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4400","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4400 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4400","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4410 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4410","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4410 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4410","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4420 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4420","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4420 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4420","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4430 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4430","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4430 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4430","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4440 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4440","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4440 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4440","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4450 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4450","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4450 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4450","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4460 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4460","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4460 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4460","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4470 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4470","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4470 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4470","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4480 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4480","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4480 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4480","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4490 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4490","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4490 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4490","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4500 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4500","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4500 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4500","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4510 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4510","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4510 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4510","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4520 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4520","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4520 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4520","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4530 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4530","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4530 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4530","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4540 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4540","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4540 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4540","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4550 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4550","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4550 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4550","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4560 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4560","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4560 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4560","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4570 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4570","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4570 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4570","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4580 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4580","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4580 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4580","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4590 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4590","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4590 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4590","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4600 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4600","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4600 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4600","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4610 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4610","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4610 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4610","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4620 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4620","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4620 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4620","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4630 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4630","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4630 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4630","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4640 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4640","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4640 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4640","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4650 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4650","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4650 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4650","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4660 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4660","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4660 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4660","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4670 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4670","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4670 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4670","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4680 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4680","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4680 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4680","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4690 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4690","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4690 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4690","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4700 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4700","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4700 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4700","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4710 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4710","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4710 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4710","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4720 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4720","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4720 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4720","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4730 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4730","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4730 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4730","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4740 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4740","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4740 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4740","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4750 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4750","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4750 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4750","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4760 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4760","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4760 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4760","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4770 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4770","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4770 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4770","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4780 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4780","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4780 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4780","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4790 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4790","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4790 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4790","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4800 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4800","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4800 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4800","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4810 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4810","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4810 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4810","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4820 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4820","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4820 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4820","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4830 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4830","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4830 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4830","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4840 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4840","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4840 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4840","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4850 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4850","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4850 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4850","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4860 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4860","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4860 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4860","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4870 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4870","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4870 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4870","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4880 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4880","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4880 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4880","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4890 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4890","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4890 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4890","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4900 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4900","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4900 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4900","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4910 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4910","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4910 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4910","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4920 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4920","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4920 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4920","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4930 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4930","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4930 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4930","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4940 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4940","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4940 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4940","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4950 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4950","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4950 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4950","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4960 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4960","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4960 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4960","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4970 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4970","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4970 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4970","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4980 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4980","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4980 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4980","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 4990 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"4990","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 4990 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"4990","color":"yellow"}]
execute if score #mSambor_points survisland.data matches 5000 run team modify survisland.temp.sidebar.4 suffix [{"text":"Points : ","color":"white"},{"text":"5000","color":"yellow"}]
execute if score #mKanawa_points survisland.data matches 5000 run team modify survisland.temp.sidebar.1 suffix [{"text":"Points : ","color":"dark_gray"},{"text":"5000","color":"yellow"}]

