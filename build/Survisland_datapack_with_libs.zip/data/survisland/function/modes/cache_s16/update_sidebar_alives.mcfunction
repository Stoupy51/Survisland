
#> survisland:modes/cache_s16/update_sidebar_alives
#
# @within	survisland:modes/cache_s16/tick
#

execute if score #specs_restants survisland.data matches 0 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"0","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 0 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"0","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 0 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"0","color":"yellow"}]
execute if score #specs_restants survisland.data matches 1 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"1","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 1 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"1","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 1 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"1","color":"yellow"}]
execute if score #specs_restants survisland.data matches 2 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"2","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 2 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"2","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 2 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"2","color":"yellow"}]
execute if score #specs_restants survisland.data matches 3 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"3","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 3 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"3","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 3 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"3","color":"yellow"}]
execute if score #specs_restants survisland.data matches 4 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"4","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 4 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"4","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 4 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"4","color":"yellow"}]
execute if score #specs_restants survisland.data matches 5 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"5","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 5 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"5","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 5 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"5","color":"yellow"}]
execute if score #specs_restants survisland.data matches 6 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"6","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 6 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"6","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 6 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"6","color":"yellow"}]
execute if score #specs_restants survisland.data matches 7 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"7","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 7 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"7","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 7 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"7","color":"yellow"}]
execute if score #specs_restants survisland.data matches 8 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"8","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 8 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"8","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 8 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"8","color":"yellow"}]
execute if score #specs_restants survisland.data matches 9 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"9","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 9 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"9","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 9 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"9","color":"yellow"}]
execute if score #specs_restants survisland.data matches 10 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"10","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 10 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"10","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 10 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"10","color":"yellow"}]
execute if score #specs_restants survisland.data matches 11 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"11","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 11 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"11","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 11 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"11","color":"yellow"}]
execute if score #specs_restants survisland.data matches 12 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"12","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 12 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"12","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 12 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"12","color":"yellow"}]
execute if score #specs_restants survisland.data matches 13 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"13","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 13 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"13","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 13 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"13","color":"yellow"}]
execute if score #specs_restants survisland.data matches 14 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"14","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 14 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"14","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 14 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"14","color":"yellow"}]
execute if score #specs_restants survisland.data matches 15 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"15","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 15 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"15","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 15 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"15","color":"yellow"}]
execute if score #specs_restants survisland.data matches 16 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"16","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 16 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"16","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 16 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"16","color":"yellow"}]
execute if score #specs_restants survisland.data matches 17 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"17","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 17 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"17","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 17 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"17","color":"yellow"}]
execute if score #specs_restants survisland.data matches 18 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"18","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 18 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"18","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 18 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"18","color":"yellow"}]
execute if score #specs_restants survisland.data matches 19 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"19","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 19 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"19","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 19 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"19","color":"yellow"}]
execute if score #specs_restants survisland.data matches 20 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"20","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 20 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"20","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 20 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"20","color":"yellow"}]
execute if score #specs_restants survisland.data matches 21 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"21","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 21 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"21","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 21 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"21","color":"yellow"}]
execute if score #specs_restants survisland.data matches 22 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"22","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 22 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"22","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 22 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"22","color":"yellow"}]
execute if score #specs_restants survisland.data matches 23 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"23","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 23 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"23","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 23 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"23","color":"yellow"}]
execute if score #specs_restants survisland.data matches 24 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"24","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 24 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"24","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 24 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"24","color":"yellow"}]
execute if score #specs_restants survisland.data matches 25 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"25","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 25 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"25","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 25 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"25","color":"yellow"}]
execute if score #specs_restants survisland.data matches 26 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"26","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 26 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"26","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 26 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"26","color":"yellow"}]
execute if score #specs_restants survisland.data matches 27 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"27","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 27 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"27","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 27 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"27","color":"yellow"}]
execute if score #specs_restants survisland.data matches 28 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"28","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 28 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"28","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 28 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"28","color":"yellow"}]
execute if score #specs_restants survisland.data matches 29 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"29","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 29 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"29","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 29 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"29","color":"yellow"}]
execute if score #specs_restants survisland.data matches 30 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"30","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 30 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"30","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 30 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"30","color":"yellow"}]
execute if score #specs_restants survisland.data matches 31 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"31","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 31 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"31","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 31 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"31","color":"yellow"}]
execute if score #specs_restants survisland.data matches 32 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"32","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 32 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"32","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 32 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"32","color":"yellow"}]
execute if score #specs_restants survisland.data matches 33 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"33","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 33 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"33","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 33 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"33","color":"yellow"}]
execute if score #specs_restants survisland.data matches 34 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"34","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 34 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"34","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 34 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"34","color":"yellow"}]
execute if score #specs_restants survisland.data matches 35 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"35","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 35 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"35","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 35 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"35","color":"yellow"}]
execute if score #specs_restants survisland.data matches 36 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"36","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 36 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"36","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 36 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"36","color":"yellow"}]
execute if score #specs_restants survisland.data matches 37 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"37","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 37 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"37","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 37 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"37","color":"yellow"}]
execute if score #specs_restants survisland.data matches 38 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"38","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 38 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"38","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 38 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"38","color":"yellow"}]
execute if score #specs_restants survisland.data matches 39 run team modify survisland.temp.sidebar.7 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"39","color":"white"}]
execute if score #mLiwai_restants survisland.data matches 39 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"white"},{"text":"39","color":"yellow"}]
execute if score #mMoemoea_restants survisland.data matches 39 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"dark_gray"},{"text":"39","color":"yellow"}]

