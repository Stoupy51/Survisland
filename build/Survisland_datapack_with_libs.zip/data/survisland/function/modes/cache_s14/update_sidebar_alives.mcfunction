
#> survisland:modes/cache_s14/update_sidebar_alives
#
# @within	survisland:modes/cache_s14/tick
#

execute if score #specs_restants survisland.data matches 0 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"0","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 0 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"0","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 0 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"0","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 0 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"0","color":"gray"}]
execute if score #specs_restants survisland.data matches 1 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"1","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 1 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"1","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 1 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"1","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 1 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"1","color":"gray"}]
execute if score #specs_restants survisland.data matches 2 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"2","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 2 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"2","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 2 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"2","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 2 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"2","color":"gray"}]
execute if score #specs_restants survisland.data matches 3 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"3","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 3 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"3","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 3 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"3","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 3 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"3","color":"gray"}]
execute if score #specs_restants survisland.data matches 4 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"4","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 4 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"4","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 4 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"4","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 4 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"4","color":"gray"}]
execute if score #specs_restants survisland.data matches 5 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"5","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 5 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"5","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 5 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"5","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 5 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"5","color":"gray"}]
execute if score #specs_restants survisland.data matches 6 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"6","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 6 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"6","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 6 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"6","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 6 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"6","color":"gray"}]
execute if score #specs_restants survisland.data matches 7 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"7","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 7 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"7","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 7 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"7","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 7 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"7","color":"gray"}]
execute if score #specs_restants survisland.data matches 8 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"8","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 8 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"8","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 8 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"8","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 8 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"8","color":"gray"}]
execute if score #specs_restants survisland.data matches 9 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"9","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 9 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"9","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 9 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"9","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 9 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"9","color":"gray"}]
execute if score #specs_restants survisland.data matches 10 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"10","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 10 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"10","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 10 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"10","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 10 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"10","color":"gray"}]
execute if score #specs_restants survisland.data matches 11 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"11","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 11 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"11","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 11 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"11","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 11 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"11","color":"gray"}]
execute if score #specs_restants survisland.data matches 12 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"12","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 12 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"12","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 12 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"12","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 12 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"12","color":"gray"}]
execute if score #specs_restants survisland.data matches 13 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"13","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 13 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"13","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 13 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"13","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 13 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"13","color":"gray"}]
execute if score #specs_restants survisland.data matches 14 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"14","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 14 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"14","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 14 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"14","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 14 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"14","color":"gray"}]
execute if score #specs_restants survisland.data matches 15 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"15","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 15 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"15","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 15 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"15","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 15 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"15","color":"gray"}]
execute if score #specs_restants survisland.data matches 16 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"16","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 16 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"16","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 16 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"16","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 16 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"16","color":"gray"}]
execute if score #specs_restants survisland.data matches 17 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"17","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 17 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"17","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 17 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"17","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 17 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"17","color":"gray"}]
execute if score #specs_restants survisland.data matches 18 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"18","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 18 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"18","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 18 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"18","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 18 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"18","color":"gray"}]
execute if score #specs_restants survisland.data matches 19 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"19","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 19 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"19","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 19 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"19","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 19 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"19","color":"gray"}]
execute if score #specs_restants survisland.data matches 20 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"20","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 20 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"20","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 20 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"20","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 20 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"20","color":"gray"}]
execute if score #specs_restants survisland.data matches 21 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"21","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 21 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"21","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 21 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"21","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 21 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"21","color":"gray"}]
execute if score #specs_restants survisland.data matches 22 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"22","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 22 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"22","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 22 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"22","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 22 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"22","color":"gray"}]
execute if score #specs_restants survisland.data matches 23 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"23","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 23 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"23","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 23 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"23","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 23 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"23","color":"gray"}]
execute if score #specs_restants survisland.data matches 24 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"24","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 24 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"24","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 24 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"24","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 24 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"24","color":"gray"}]
execute if score #specs_restants survisland.data matches 25 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"25","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 25 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"25","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 25 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"25","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 25 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"25","color":"gray"}]
execute if score #specs_restants survisland.data matches 26 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"26","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 26 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"26","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 26 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"26","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 26 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"26","color":"gray"}]
execute if score #specs_restants survisland.data matches 27 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"27","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 27 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"27","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 27 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"27","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 27 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"27","color":"gray"}]
execute if score #specs_restants survisland.data matches 28 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"28","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 28 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"28","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 28 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"28","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 28 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"28","color":"gray"}]
execute if score #specs_restants survisland.data matches 29 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"29","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 29 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"29","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 29 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"29","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 29 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"29","color":"gray"}]
execute if score #specs_restants survisland.data matches 30 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"30","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 30 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"30","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 30 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"30","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 30 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"30","color":"gray"}]
execute if score #specs_restants survisland.data matches 31 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"31","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 31 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"31","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 31 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"31","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 31 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"31","color":"gray"}]
execute if score #specs_restants survisland.data matches 32 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"32","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 32 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"32","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 32 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"32","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 32 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"32","color":"gray"}]
execute if score #specs_restants survisland.data matches 33 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"33","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 33 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"33","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 33 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"33","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 33 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"33","color":"gray"}]
execute if score #specs_restants survisland.data matches 34 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"34","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 34 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"34","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 34 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"34","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 34 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"34","color":"gray"}]
execute if score #specs_restants survisland.data matches 35 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"35","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 35 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"35","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 35 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"35","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 35 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"35","color":"gray"}]
execute if score #specs_restants survisland.data matches 36 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"36","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 36 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"36","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 36 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"36","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 36 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"36","color":"gray"}]
execute if score #specs_restants survisland.data matches 37 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"37","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 37 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"37","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 37 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"37","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 37 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"37","color":"gray"}]
execute if score #specs_restants survisland.data matches 38 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"38","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 38 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"38","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 38 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"38","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 38 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"38","color":"gray"}]
execute if score #specs_restants survisland.data matches 39 run team modify survisland.temp.sidebar.10 suffix [{"text":"Specs restants : ","color":"gray"},{"text":"39","color":"white"}]
execute if score #mPonogoro_restants survisland.data matches 39 run team modify survisland.temp.sidebar.8 suffix [{"text":"Joueurs restants : ","color":"light_purple"},{"text":"39","color":"gray"}]
execute if score #mKecak_restants survisland.data matches 39 run team modify survisland.temp.sidebar.5 suffix [{"text":"Joueurs restants : ","color":"gold"},{"text":"39","color":"gray"}]
execute if score #mSinaoh_restants survisland.data matches 39 run team modify survisland.temp.sidebar.2 suffix [{"text":"Joueurs restants : ","color":"green"},{"text":"39","color":"gray"}]

