
#> survisland:modes/cache_s12/update_sidebar_alives
#
# @within	survisland:modes/cache_s12/tick
#

execute if score #specs_restants survisland.data matches 0 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"0","color":"white"}]
execute if score #mKuning_restants survisland.data matches 0 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"0","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 0 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"0","color":"gray"}]
execute if score #specs_restants survisland.data matches 1 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"1","color":"white"}]
execute if score #mKuning_restants survisland.data matches 1 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"1","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 1 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"1","color":"gray"}]
execute if score #specs_restants survisland.data matches 2 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"2","color":"white"}]
execute if score #mKuning_restants survisland.data matches 2 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"2","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 2 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"2","color":"gray"}]
execute if score #specs_restants survisland.data matches 3 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"3","color":"white"}]
execute if score #mKuning_restants survisland.data matches 3 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"3","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 3 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"3","color":"gray"}]
execute if score #specs_restants survisland.data matches 4 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"4","color":"white"}]
execute if score #mKuning_restants survisland.data matches 4 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"4","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 4 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"4","color":"gray"}]
execute if score #specs_restants survisland.data matches 5 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"5","color":"white"}]
execute if score #mKuning_restants survisland.data matches 5 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"5","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 5 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"5","color":"gray"}]
execute if score #specs_restants survisland.data matches 6 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"6","color":"white"}]
execute if score #mKuning_restants survisland.data matches 6 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"6","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 6 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"6","color":"gray"}]
execute if score #specs_restants survisland.data matches 7 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"7","color":"white"}]
execute if score #mKuning_restants survisland.data matches 7 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"7","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 7 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"7","color":"gray"}]
execute if score #specs_restants survisland.data matches 8 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"8","color":"white"}]
execute if score #mKuning_restants survisland.data matches 8 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"8","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 8 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"8","color":"gray"}]
execute if score #specs_restants survisland.data matches 9 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"9","color":"white"}]
execute if score #mKuning_restants survisland.data matches 9 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"9","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 9 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"9","color":"gray"}]
execute if score #specs_restants survisland.data matches 10 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"10","color":"white"}]
execute if score #mKuning_restants survisland.data matches 10 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"10","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 10 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"10","color":"gray"}]
execute if score #specs_restants survisland.data matches 11 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"11","color":"white"}]
execute if score #mKuning_restants survisland.data matches 11 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"11","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 11 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"11","color":"gray"}]
execute if score #specs_restants survisland.data matches 12 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"12","color":"white"}]
execute if score #mKuning_restants survisland.data matches 12 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"12","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 12 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"12","color":"gray"}]
execute if score #specs_restants survisland.data matches 13 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"13","color":"white"}]
execute if score #mKuning_restants survisland.data matches 13 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"13","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 13 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"13","color":"gray"}]
execute if score #specs_restants survisland.data matches 14 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"14","color":"white"}]
execute if score #mKuning_restants survisland.data matches 14 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"14","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 14 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"14","color":"gray"}]
execute if score #specs_restants survisland.data matches 15 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"15","color":"white"}]
execute if score #mKuning_restants survisland.data matches 15 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"15","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 15 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"15","color":"gray"}]
execute if score #specs_restants survisland.data matches 16 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"16","color":"white"}]
execute if score #mKuning_restants survisland.data matches 16 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"16","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 16 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"16","color":"gray"}]
execute if score #specs_restants survisland.data matches 17 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"17","color":"white"}]
execute if score #mKuning_restants survisland.data matches 17 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"17","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 17 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"17","color":"gray"}]
execute if score #specs_restants survisland.data matches 18 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"18","color":"white"}]
execute if score #mKuning_restants survisland.data matches 18 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"18","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 18 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"18","color":"gray"}]
execute if score #specs_restants survisland.data matches 19 run team modify survisland.temp.sidebar.7 suffix [{"text":" restants : ","color":"gray"},{"text":"19","color":"white"}]
execute if score #mKuning_restants survisland.data matches 19 run team modify survisland.temp.sidebar.5 suffix [{"text":"eurs restants : ","color":"yellow"},{"text":"19","color":"gray"}]
execute if score #mMayra_restants survisland.data matches 19 run team modify survisland.temp.sidebar.2 suffix [{"text":"urs restants : ","color":"red"},{"text":"19","color":"gray"}]

