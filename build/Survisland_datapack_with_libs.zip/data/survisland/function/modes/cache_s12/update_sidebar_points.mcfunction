
#> survisland:modes/cache_s12/update_sidebar_points
#
# @within	survisland:modes/cache_s12/adv/add_points
#			survisland:modes/cache_s12/process_end
#			survisland:modes/cache_s12/second
#

execute if score #mKuning_points survisland.data matches -100 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"-100","color":"gray"}]
execute if score #mMayra_points survisland.data matches -100 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"-100","color":"gray"}]
execute if score #mKuning_points survisland.data matches -90 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"-90","color":"gray"}]
execute if score #mMayra_points survisland.data matches -90 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"-90","color":"gray"}]
execute if score #mKuning_points survisland.data matches -80 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"-80","color":"gray"}]
execute if score #mMayra_points survisland.data matches -80 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"-80","color":"gray"}]
execute if score #mKuning_points survisland.data matches -70 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"-70","color":"gray"}]
execute if score #mMayra_points survisland.data matches -70 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"-70","color":"gray"}]
execute if score #mKuning_points survisland.data matches -60 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"-60","color":"gray"}]
execute if score #mMayra_points survisland.data matches -60 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"-60","color":"gray"}]
execute if score #mKuning_points survisland.data matches -50 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"-50","color":"gray"}]
execute if score #mMayra_points survisland.data matches -50 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"-50","color":"gray"}]
execute if score #mKuning_points survisland.data matches -40 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"-40","color":"gray"}]
execute if score #mMayra_points survisland.data matches -40 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"-40","color":"gray"}]
execute if score #mKuning_points survisland.data matches -30 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"-30","color":"gray"}]
execute if score #mMayra_points survisland.data matches -30 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"-30","color":"gray"}]
execute if score #mKuning_points survisland.data matches -20 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"-20","color":"gray"}]
execute if score #mMayra_points survisland.data matches -20 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"-20","color":"gray"}]
execute if score #mKuning_points survisland.data matches -10 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"-10","color":"gray"}]
execute if score #mMayra_points survisland.data matches -10 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"-10","color":"gray"}]
execute if score #mKuning_points survisland.data matches 0 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"0","color":"gray"}]
execute if score #mMayra_points survisland.data matches 0 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"0","color":"gray"}]
execute if score #mKuning_points survisland.data matches 10 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"10","color":"gray"}]
execute if score #mMayra_points survisland.data matches 10 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"10","color":"gray"}]
execute if score #mKuning_points survisland.data matches 20 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"20","color":"gray"}]
execute if score #mMayra_points survisland.data matches 20 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"20","color":"gray"}]
execute if score #mKuning_points survisland.data matches 30 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"30","color":"gray"}]
execute if score #mMayra_points survisland.data matches 30 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"30","color":"gray"}]
execute if score #mKuning_points survisland.data matches 40 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"40","color":"gray"}]
execute if score #mMayra_points survisland.data matches 40 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"40","color":"gray"}]
execute if score #mKuning_points survisland.data matches 50 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"50","color":"gray"}]
execute if score #mMayra_points survisland.data matches 50 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"50","color":"gray"}]
execute if score #mKuning_points survisland.data matches 60 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"60","color":"gray"}]
execute if score #mMayra_points survisland.data matches 60 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"60","color":"gray"}]
execute if score #mKuning_points survisland.data matches 70 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"70","color":"gray"}]
execute if score #mMayra_points survisland.data matches 70 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"70","color":"gray"}]
execute if score #mKuning_points survisland.data matches 80 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"80","color":"gray"}]
execute if score #mMayra_points survisland.data matches 80 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"80","color":"gray"}]
execute if score #mKuning_points survisland.data matches 90 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"90","color":"gray"}]
execute if score #mMayra_points survisland.data matches 90 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"90","color":"gray"}]
execute if score #mKuning_points survisland.data matches 100 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"100","color":"gray"}]
execute if score #mMayra_points survisland.data matches 100 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"100","color":"gray"}]
execute if score #mKuning_points survisland.data matches 110 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"110","color":"gray"}]
execute if score #mMayra_points survisland.data matches 110 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"110","color":"gray"}]
execute if score #mKuning_points survisland.data matches 120 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"120","color":"gray"}]
execute if score #mMayra_points survisland.data matches 120 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"120","color":"gray"}]
execute if score #mKuning_points survisland.data matches 130 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"130","color":"gray"}]
execute if score #mMayra_points survisland.data matches 130 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"130","color":"gray"}]
execute if score #mKuning_points survisland.data matches 140 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"140","color":"gray"}]
execute if score #mMayra_points survisland.data matches 140 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"140","color":"gray"}]
execute if score #mKuning_points survisland.data matches 150 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"150","color":"gray"}]
execute if score #mMayra_points survisland.data matches 150 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"150","color":"gray"}]
execute if score #mKuning_points survisland.data matches 160 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"160","color":"gray"}]
execute if score #mMayra_points survisland.data matches 160 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"160","color":"gray"}]
execute if score #mKuning_points survisland.data matches 170 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"170","color":"gray"}]
execute if score #mMayra_points survisland.data matches 170 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"170","color":"gray"}]
execute if score #mKuning_points survisland.data matches 180 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"180","color":"gray"}]
execute if score #mMayra_points survisland.data matches 180 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"180","color":"gray"}]
execute if score #mKuning_points survisland.data matches 190 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"190","color":"gray"}]
execute if score #mMayra_points survisland.data matches 190 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"190","color":"gray"}]
execute if score #mKuning_points survisland.data matches 200 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"200","color":"gray"}]
execute if score #mMayra_points survisland.data matches 200 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"200","color":"gray"}]
execute if score #mKuning_points survisland.data matches 210 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"210","color":"gray"}]
execute if score #mMayra_points survisland.data matches 210 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"210","color":"gray"}]
execute if score #mKuning_points survisland.data matches 220 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"220","color":"gray"}]
execute if score #mMayra_points survisland.data matches 220 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"220","color":"gray"}]
execute if score #mKuning_points survisland.data matches 230 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"230","color":"gray"}]
execute if score #mMayra_points survisland.data matches 230 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"230","color":"gray"}]
execute if score #mKuning_points survisland.data matches 240 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"240","color":"gray"}]
execute if score #mMayra_points survisland.data matches 240 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"240","color":"gray"}]
execute if score #mKuning_points survisland.data matches 250 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"250","color":"gray"}]
execute if score #mMayra_points survisland.data matches 250 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"250","color":"gray"}]
execute if score #mKuning_points survisland.data matches 260 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"260","color":"gray"}]
execute if score #mMayra_points survisland.data matches 260 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"260","color":"gray"}]
execute if score #mKuning_points survisland.data matches 270 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"270","color":"gray"}]
execute if score #mMayra_points survisland.data matches 270 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"270","color":"gray"}]
execute if score #mKuning_points survisland.data matches 280 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"280","color":"gray"}]
execute if score #mMayra_points survisland.data matches 280 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"280","color":"gray"}]
execute if score #mKuning_points survisland.data matches 290 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"290","color":"gray"}]
execute if score #mMayra_points survisland.data matches 290 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"290","color":"gray"}]
execute if score #mKuning_points survisland.data matches 300 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"300","color":"gray"}]
execute if score #mMayra_points survisland.data matches 300 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"300","color":"gray"}]
execute if score #mKuning_points survisland.data matches 310 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"310","color":"gray"}]
execute if score #mMayra_points survisland.data matches 310 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"310","color":"gray"}]
execute if score #mKuning_points survisland.data matches 320 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"320","color":"gray"}]
execute if score #mMayra_points survisland.data matches 320 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"320","color":"gray"}]
execute if score #mKuning_points survisland.data matches 330 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"330","color":"gray"}]
execute if score #mMayra_points survisland.data matches 330 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"330","color":"gray"}]
execute if score #mKuning_points survisland.data matches 340 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"340","color":"gray"}]
execute if score #mMayra_points survisland.data matches 340 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"340","color":"gray"}]
execute if score #mKuning_points survisland.data matches 350 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"350","color":"gray"}]
execute if score #mMayra_points survisland.data matches 350 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"350","color":"gray"}]
execute if score #mKuning_points survisland.data matches 360 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"360","color":"gray"}]
execute if score #mMayra_points survisland.data matches 360 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"360","color":"gray"}]
execute if score #mKuning_points survisland.data matches 370 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"370","color":"gray"}]
execute if score #mMayra_points survisland.data matches 370 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"370","color":"gray"}]
execute if score #mKuning_points survisland.data matches 380 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"380","color":"gray"}]
execute if score #mMayra_points survisland.data matches 380 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"380","color":"gray"}]
execute if score #mKuning_points survisland.data matches 390 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"390","color":"gray"}]
execute if score #mMayra_points survisland.data matches 390 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"390","color":"gray"}]
execute if score #mKuning_points survisland.data matches 400 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"400","color":"gray"}]
execute if score #mMayra_points survisland.data matches 400 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"400","color":"gray"}]
execute if score #mKuning_points survisland.data matches 410 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"410","color":"gray"}]
execute if score #mMayra_points survisland.data matches 410 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"410","color":"gray"}]
execute if score #mKuning_points survisland.data matches 420 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"420","color":"gray"}]
execute if score #mMayra_points survisland.data matches 420 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"420","color":"gray"}]
execute if score #mKuning_points survisland.data matches 430 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"430","color":"gray"}]
execute if score #mMayra_points survisland.data matches 430 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"430","color":"gray"}]
execute if score #mKuning_points survisland.data matches 440 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"440","color":"gray"}]
execute if score #mMayra_points survisland.data matches 440 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"440","color":"gray"}]
execute if score #mKuning_points survisland.data matches 450 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"450","color":"gray"}]
execute if score #mMayra_points survisland.data matches 450 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"450","color":"gray"}]
execute if score #mKuning_points survisland.data matches 460 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"460","color":"gray"}]
execute if score #mMayra_points survisland.data matches 460 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"460","color":"gray"}]
execute if score #mKuning_points survisland.data matches 470 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"470","color":"gray"}]
execute if score #mMayra_points survisland.data matches 470 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"470","color":"gray"}]
execute if score #mKuning_points survisland.data matches 480 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"480","color":"gray"}]
execute if score #mMayra_points survisland.data matches 480 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"480","color":"gray"}]
execute if score #mKuning_points survisland.data matches 490 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"490","color":"gray"}]
execute if score #mMayra_points survisland.data matches 490 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"490","color":"gray"}]
execute if score #mKuning_points survisland.data matches 500 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"500","color":"gray"}]
execute if score #mMayra_points survisland.data matches 500 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"500","color":"gray"}]
execute if score #mKuning_points survisland.data matches 510 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"510","color":"gray"}]
execute if score #mMayra_points survisland.data matches 510 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"510","color":"gray"}]
execute if score #mKuning_points survisland.data matches 520 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"520","color":"gray"}]
execute if score #mMayra_points survisland.data matches 520 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"520","color":"gray"}]
execute if score #mKuning_points survisland.data matches 530 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"530","color":"gray"}]
execute if score #mMayra_points survisland.data matches 530 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"530","color":"gray"}]
execute if score #mKuning_points survisland.data matches 540 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"540","color":"gray"}]
execute if score #mMayra_points survisland.data matches 540 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"540","color":"gray"}]
execute if score #mKuning_points survisland.data matches 550 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"550","color":"gray"}]
execute if score #mMayra_points survisland.data matches 550 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"550","color":"gray"}]
execute if score #mKuning_points survisland.data matches 560 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"560","color":"gray"}]
execute if score #mMayra_points survisland.data matches 560 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"560","color":"gray"}]
execute if score #mKuning_points survisland.data matches 570 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"570","color":"gray"}]
execute if score #mMayra_points survisland.data matches 570 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"570","color":"gray"}]
execute if score #mKuning_points survisland.data matches 580 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"580","color":"gray"}]
execute if score #mMayra_points survisland.data matches 580 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"580","color":"gray"}]
execute if score #mKuning_points survisland.data matches 590 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"590","color":"gray"}]
execute if score #mMayra_points survisland.data matches 590 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"590","color":"gray"}]
execute if score #mKuning_points survisland.data matches 600 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"600","color":"gray"}]
execute if score #mMayra_points survisland.data matches 600 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"600","color":"gray"}]
execute if score #mKuning_points survisland.data matches 610 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"610","color":"gray"}]
execute if score #mMayra_points survisland.data matches 610 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"610","color":"gray"}]
execute if score #mKuning_points survisland.data matches 620 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"620","color":"gray"}]
execute if score #mMayra_points survisland.data matches 620 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"620","color":"gray"}]
execute if score #mKuning_points survisland.data matches 630 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"630","color":"gray"}]
execute if score #mMayra_points survisland.data matches 630 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"630","color":"gray"}]
execute if score #mKuning_points survisland.data matches 640 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"640","color":"gray"}]
execute if score #mMayra_points survisland.data matches 640 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"640","color":"gray"}]
execute if score #mKuning_points survisland.data matches 650 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"650","color":"gray"}]
execute if score #mMayra_points survisland.data matches 650 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"650","color":"gray"}]
execute if score #mKuning_points survisland.data matches 660 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"660","color":"gray"}]
execute if score #mMayra_points survisland.data matches 660 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"660","color":"gray"}]
execute if score #mKuning_points survisland.data matches 670 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"670","color":"gray"}]
execute if score #mMayra_points survisland.data matches 670 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"670","color":"gray"}]
execute if score #mKuning_points survisland.data matches 680 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"680","color":"gray"}]
execute if score #mMayra_points survisland.data matches 680 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"680","color":"gray"}]
execute if score #mKuning_points survisland.data matches 690 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"690","color":"gray"}]
execute if score #mMayra_points survisland.data matches 690 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"690","color":"gray"}]
execute if score #mKuning_points survisland.data matches 700 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"700","color":"gray"}]
execute if score #mMayra_points survisland.data matches 700 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"700","color":"gray"}]
execute if score #mKuning_points survisland.data matches 710 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"710","color":"gray"}]
execute if score #mMayra_points survisland.data matches 710 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"710","color":"gray"}]
execute if score #mKuning_points survisland.data matches 720 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"720","color":"gray"}]
execute if score #mMayra_points survisland.data matches 720 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"720","color":"gray"}]
execute if score #mKuning_points survisland.data matches 730 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"730","color":"gray"}]
execute if score #mMayra_points survisland.data matches 730 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"730","color":"gray"}]
execute if score #mKuning_points survisland.data matches 740 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"740","color":"gray"}]
execute if score #mMayra_points survisland.data matches 740 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"740","color":"gray"}]
execute if score #mKuning_points survisland.data matches 750 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"750","color":"gray"}]
execute if score #mMayra_points survisland.data matches 750 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"750","color":"gray"}]
execute if score #mKuning_points survisland.data matches 760 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"760","color":"gray"}]
execute if score #mMayra_points survisland.data matches 760 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"760","color":"gray"}]
execute if score #mKuning_points survisland.data matches 770 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"770","color":"gray"}]
execute if score #mMayra_points survisland.data matches 770 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"770","color":"gray"}]
execute if score #mKuning_points survisland.data matches 780 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"780","color":"gray"}]
execute if score #mMayra_points survisland.data matches 780 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"780","color":"gray"}]
execute if score #mKuning_points survisland.data matches 790 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"790","color":"gray"}]
execute if score #mMayra_points survisland.data matches 790 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"790","color":"gray"}]
execute if score #mKuning_points survisland.data matches 800 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"800","color":"gray"}]
execute if score #mMayra_points survisland.data matches 800 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"800","color":"gray"}]
execute if score #mKuning_points survisland.data matches 810 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"810","color":"gray"}]
execute if score #mMayra_points survisland.data matches 810 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"810","color":"gray"}]
execute if score #mKuning_points survisland.data matches 820 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"820","color":"gray"}]
execute if score #mMayra_points survisland.data matches 820 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"820","color":"gray"}]
execute if score #mKuning_points survisland.data matches 830 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"830","color":"gray"}]
execute if score #mMayra_points survisland.data matches 830 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"830","color":"gray"}]
execute if score #mKuning_points survisland.data matches 840 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"840","color":"gray"}]
execute if score #mMayra_points survisland.data matches 840 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"840","color":"gray"}]
execute if score #mKuning_points survisland.data matches 850 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"850","color":"gray"}]
execute if score #mMayra_points survisland.data matches 850 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"850","color":"gray"}]
execute if score #mKuning_points survisland.data matches 860 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"860","color":"gray"}]
execute if score #mMayra_points survisland.data matches 860 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"860","color":"gray"}]
execute if score #mKuning_points survisland.data matches 870 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"870","color":"gray"}]
execute if score #mMayra_points survisland.data matches 870 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"870","color":"gray"}]
execute if score #mKuning_points survisland.data matches 880 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"880","color":"gray"}]
execute if score #mMayra_points survisland.data matches 880 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"880","color":"gray"}]
execute if score #mKuning_points survisland.data matches 890 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"890","color":"gray"}]
execute if score #mMayra_points survisland.data matches 890 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"890","color":"gray"}]
execute if score #mKuning_points survisland.data matches 900 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"900","color":"gray"}]
execute if score #mMayra_points survisland.data matches 900 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"900","color":"gray"}]
execute if score #mKuning_points survisland.data matches 910 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"910","color":"gray"}]
execute if score #mMayra_points survisland.data matches 910 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"910","color":"gray"}]
execute if score #mKuning_points survisland.data matches 920 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"920","color":"gray"}]
execute if score #mMayra_points survisland.data matches 920 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"920","color":"gray"}]
execute if score #mKuning_points survisland.data matches 930 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"930","color":"gray"}]
execute if score #mMayra_points survisland.data matches 930 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"930","color":"gray"}]
execute if score #mKuning_points survisland.data matches 940 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"940","color":"gray"}]
execute if score #mMayra_points survisland.data matches 940 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"940","color":"gray"}]
execute if score #mKuning_points survisland.data matches 950 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"950","color":"gray"}]
execute if score #mMayra_points survisland.data matches 950 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"950","color":"gray"}]
execute if score #mKuning_points survisland.data matches 960 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"960","color":"gray"}]
execute if score #mMayra_points survisland.data matches 960 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"960","color":"gray"}]
execute if score #mKuning_points survisland.data matches 970 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"970","color":"gray"}]
execute if score #mMayra_points survisland.data matches 970 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"970","color":"gray"}]
execute if score #mKuning_points survisland.data matches 980 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"980","color":"gray"}]
execute if score #mMayra_points survisland.data matches 980 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"980","color":"gray"}]
execute if score #mKuning_points survisland.data matches 990 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"990","color":"gray"}]
execute if score #mMayra_points survisland.data matches 990 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"990","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1000 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1000","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1000 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1000","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1010 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1010","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1010 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1010","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1020 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1020","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1020 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1020","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1030 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1030","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1030 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1030","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1040 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1040","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1040 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1040","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1050 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1050","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1050 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1050","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1060 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1060","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1060 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1060","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1070 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1070","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1070 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1070","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1080 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1080","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1080 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1080","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1090 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1090","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1090 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1090","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1100 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1100","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1100 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1100","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1110 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1110","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1110 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1110","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1120 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1120","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1120 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1120","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1130 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1130","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1130 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1130","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1140 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1140","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1140 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1140","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1150 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1150","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1150 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1150","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1160 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1160","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1160 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1160","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1170 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1170","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1170 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1170","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1180 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1180","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1180 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1180","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1190 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1190","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1190 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1190","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1200 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1200","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1200 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1200","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1210 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1210","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1210 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1210","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1220 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1220","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1220 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1220","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1230 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1230","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1230 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1230","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1240 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1240","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1240 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1240","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1250 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1250","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1250 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1250","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1260 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1260","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1260 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1260","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1270 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1270","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1270 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1270","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1280 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1280","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1280 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1280","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1290 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1290","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1290 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1290","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1300 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1300","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1300 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1300","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1310 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1310","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1310 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1310","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1320 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1320","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1320 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1320","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1330 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1330","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1330 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1330","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1340 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1340","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1340 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1340","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1350 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1350","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1350 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1350","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1360 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1360","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1360 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1360","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1370 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1370","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1370 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1370","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1380 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1380","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1380 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1380","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1390 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1390","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1390 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1390","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1400 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1400","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1400 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1400","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1410 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1410","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1410 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1410","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1420 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1420","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1420 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1420","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1430 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1430","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1430 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1430","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1440 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1440","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1440 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1440","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1450 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1450","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1450 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1450","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1460 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1460","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1460 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1460","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1470 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1470","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1470 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1470","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1480 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1480","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1480 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1480","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1490 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1490","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1490 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1490","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1500 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1500","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1500 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1500","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1510 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1510","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1510 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1510","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1520 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1520","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1520 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1520","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1530 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1530","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1530 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1530","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1540 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1540","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1540 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1540","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1550 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1550","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1550 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1550","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1560 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1560","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1560 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1560","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1570 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1570","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1570 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1570","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1580 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1580","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1580 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1580","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1590 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1590","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1590 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1590","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1600 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1600","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1600 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1600","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1610 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1610","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1610 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1610","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1620 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1620","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1620 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1620","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1630 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1630","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1630 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1630","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1640 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1640","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1640 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1640","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1650 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1650","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1650 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1650","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1660 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1660","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1660 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1660","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1670 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1670","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1670 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1670","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1680 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1680","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1680 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1680","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1690 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1690","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1690 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1690","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1700 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1700","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1700 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1700","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1710 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1710","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1710 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1710","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1720 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1720","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1720 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1720","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1730 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1730","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1730 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1730","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1740 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1740","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1740 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1740","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1750 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1750","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1750 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1750","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1760 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1760","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1760 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1760","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1770 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1770","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1770 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1770","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1780 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1780","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1780 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1780","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1790 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1790","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1790 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1790","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1800 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1800","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1800 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1800","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1810 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1810","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1810 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1810","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1820 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1820","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1820 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1820","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1830 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1830","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1830 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1830","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1840 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1840","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1840 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1840","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1850 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1850","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1850 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1850","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1860 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1860","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1860 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1860","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1870 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1870","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1870 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1870","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1880 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1880","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1880 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1880","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1890 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1890","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1890 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1890","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1900 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1900","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1900 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1900","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1910 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1910","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1910 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1910","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1920 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1920","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1920 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1920","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1930 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1930","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1930 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1930","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1940 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1940","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1940 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1940","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1950 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1950","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1950 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1950","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1960 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1960","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1960 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1960","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1970 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1970","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1970 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1970","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1980 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1980","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1980 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1980","color":"gray"}]
execute if score #mKuning_points survisland.data matches 1990 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"1990","color":"gray"}]
execute if score #mMayra_points survisland.data matches 1990 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"1990","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2000 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2000","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2000 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2000","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2010 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2010","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2010 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2010","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2020 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2020","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2020 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2020","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2030 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2030","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2030 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2030","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2040 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2040","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2040 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2040","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2050 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2050","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2050 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2050","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2060 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2060","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2060 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2060","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2070 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2070","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2070 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2070","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2080 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2080","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2080 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2080","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2090 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2090","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2090 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2090","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2100 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2100","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2100 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2100","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2110 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2110","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2110 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2110","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2120 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2120","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2120 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2120","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2130 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2130","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2130 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2130","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2140 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2140","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2140 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2140","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2150 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2150","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2150 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2150","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2160 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2160","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2160 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2160","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2170 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2170","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2170 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2170","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2180 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2180","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2180 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2180","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2190 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2190","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2190 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2190","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2200 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2200","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2200 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2200","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2210 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2210","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2210 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2210","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2220 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2220","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2220 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2220","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2230 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2230","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2230 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2230","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2240 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2240","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2240 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2240","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2250 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2250","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2250 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2250","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2260 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2260","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2260 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2260","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2270 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2270","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2270 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2270","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2280 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2280","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2280 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2280","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2290 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2290","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2290 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2290","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2300 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2300","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2300 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2300","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2310 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2310","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2310 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2310","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2320 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2320","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2320 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2320","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2330 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2330","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2330 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2330","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2340 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2340","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2340 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2340","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2350 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2350","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2350 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2350","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2360 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2360","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2360 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2360","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2370 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2370","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2370 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2370","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2380 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2380","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2380 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2380","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2390 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2390","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2390 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2390","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2400 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2400","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2400 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2400","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2410 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2410","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2410 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2410","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2420 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2420","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2420 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2420","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2430 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2430","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2430 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2430","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2440 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2440","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2440 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2440","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2450 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2450","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2450 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2450","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2460 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2460","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2460 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2460","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2470 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2470","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2470 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2470","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2480 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2480","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2480 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2480","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2490 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2490","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2490 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2490","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2500 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2500","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2500 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2500","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2510 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2510","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2510 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2510","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2520 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2520","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2520 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2520","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2530 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2530","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2530 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2530","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2540 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2540","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2540 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2540","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2550 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2550","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2550 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2550","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2560 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2560","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2560 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2560","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2570 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2570","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2570 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2570","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2580 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2580","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2580 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2580","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2590 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2590","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2590 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2590","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2600 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2600","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2600 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2600","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2610 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2610","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2610 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2610","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2620 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2620","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2620 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2620","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2630 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2630","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2630 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2630","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2640 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2640","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2640 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2640","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2650 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2650","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2650 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2650","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2660 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2660","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2660 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2660","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2670 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2670","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2670 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2670","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2680 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2680","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2680 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2680","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2690 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2690","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2690 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2690","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2700 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2700","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2700 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2700","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2710 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2710","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2710 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2710","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2720 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2720","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2720 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2720","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2730 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2730","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2730 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2730","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2740 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2740","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2740 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2740","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2750 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2750","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2750 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2750","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2760 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2760","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2760 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2760","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2770 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2770","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2770 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2770","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2780 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2780","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2780 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2780","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2790 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2790","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2790 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2790","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2800 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2800","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2800 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2800","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2810 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2810","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2810 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2810","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2820 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2820","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2820 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2820","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2830 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2830","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2830 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2830","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2840 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2840","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2840 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2840","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2850 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2850","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2850 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2850","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2860 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2860","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2860 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2860","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2870 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2870","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2870 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2870","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2880 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2880","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2880 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2880","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2890 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2890","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2890 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2890","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2900 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2900","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2900 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2900","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2910 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2910","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2910 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2910","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2920 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2920","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2920 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2920","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2930 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2930","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2930 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2930","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2940 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2940","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2940 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2940","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2950 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2950","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2950 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2950","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2960 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2960","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2960 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2960","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2970 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2970","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2970 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2970","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2980 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2980","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2980 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2980","color":"gray"}]
execute if score #mKuning_points survisland.data matches 2990 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"2990","color":"gray"}]
execute if score #mMayra_points survisland.data matches 2990 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"2990","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3000 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3000","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3000 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3000","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3010 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3010","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3010 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3010","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3020 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3020","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3020 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3020","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3030 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3030","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3030 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3030","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3040 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3040","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3040 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3040","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3050 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3050","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3050 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3050","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3060 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3060","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3060 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3060","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3070 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3070","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3070 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3070","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3080 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3080","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3080 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3080","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3090 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3090","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3090 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3090","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3100 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3100","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3100 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3100","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3110 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3110","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3110 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3110","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3120 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3120","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3120 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3120","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3130 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3130","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3130 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3130","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3140 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3140","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3140 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3140","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3150 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3150","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3150 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3150","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3160 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3160","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3160 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3160","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3170 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3170","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3170 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3170","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3180 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3180","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3180 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3180","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3190 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3190","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3190 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3190","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3200 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3200","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3200 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3200","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3210 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3210","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3210 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3210","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3220 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3220","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3220 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3220","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3230 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3230","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3230 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3230","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3240 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3240","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3240 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3240","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3250 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3250","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3250 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3250","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3260 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3260","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3260 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3260","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3270 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3270","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3270 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3270","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3280 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3280","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3280 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3280","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3290 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3290","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3290 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3290","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3300 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3300","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3300 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3300","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3310 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3310","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3310 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3310","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3320 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3320","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3320 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3320","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3330 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3330","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3330 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3330","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3340 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3340","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3340 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3340","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3350 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3350","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3350 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3350","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3360 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3360","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3360 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3360","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3370 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3370","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3370 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3370","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3380 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3380","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3380 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3380","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3390 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3390","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3390 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3390","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3400 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3400","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3400 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3400","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3410 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3410","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3410 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3410","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3420 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3420","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3420 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3420","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3430 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3430","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3430 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3430","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3440 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3440","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3440 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3440","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3450 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3450","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3450 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3450","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3460 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3460","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3460 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3460","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3470 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3470","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3470 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3470","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3480 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3480","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3480 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3480","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3490 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3490","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3490 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3490","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3500 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3500","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3500 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3500","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3510 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3510","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3510 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3510","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3520 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3520","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3520 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3520","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3530 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3530","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3530 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3530","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3540 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3540","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3540 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3540","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3550 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3550","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3550 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3550","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3560 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3560","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3560 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3560","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3570 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3570","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3570 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3570","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3580 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3580","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3580 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3580","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3590 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3590","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3590 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3590","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3600 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3600","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3600 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3600","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3610 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3610","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3610 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3610","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3620 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3620","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3620 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3620","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3630 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3630","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3630 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3630","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3640 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3640","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3640 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3640","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3650 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3650","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3650 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3650","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3660 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3660","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3660 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3660","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3670 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3670","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3670 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3670","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3680 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3680","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3680 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3680","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3690 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3690","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3690 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3690","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3700 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3700","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3700 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3700","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3710 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3710","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3710 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3710","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3720 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3720","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3720 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3720","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3730 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3730","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3730 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3730","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3740 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3740","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3740 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3740","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3750 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3750","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3750 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3750","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3760 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3760","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3760 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3760","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3770 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3770","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3770 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3770","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3780 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3780","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3780 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3780","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3790 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3790","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3790 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3790","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3800 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3800","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3800 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3800","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3810 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3810","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3810 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3810","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3820 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3820","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3820 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3820","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3830 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3830","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3830 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3830","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3840 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3840","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3840 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3840","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3850 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3850","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3850 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3850","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3860 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3860","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3860 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3860","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3870 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3870","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3870 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3870","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3880 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3880","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3880 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3880","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3890 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3890","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3890 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3890","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3900 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3900","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3900 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3900","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3910 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3910","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3910 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3910","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3920 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3920","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3920 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3920","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3930 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3930","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3930 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3930","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3940 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3940","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3940 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3940","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3950 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3950","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3950 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3950","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3960 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3960","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3960 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3960","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3970 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3970","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3970 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3970","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3980 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3980","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3980 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3980","color":"gray"}]
execute if score #mKuning_points survisland.data matches 3990 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"3990","color":"gray"}]
execute if score #mMayra_points survisland.data matches 3990 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"3990","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4000 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4000","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4000 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4000","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4010 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4010","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4010 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4010","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4020 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4020","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4020 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4020","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4030 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4030","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4030 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4030","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4040 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4040","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4040 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4040","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4050 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4050","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4050 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4050","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4060 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4060","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4060 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4060","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4070 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4070","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4070 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4070","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4080 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4080","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4080 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4080","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4090 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4090","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4090 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4090","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4100 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4100","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4100 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4100","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4110 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4110","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4110 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4110","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4120 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4120","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4120 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4120","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4130 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4130","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4130 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4130","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4140 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4140","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4140 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4140","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4150 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4150","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4150 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4150","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4160 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4160","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4160 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4160","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4170 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4170","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4170 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4170","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4180 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4180","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4180 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4180","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4190 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4190","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4190 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4190","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4200 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4200","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4200 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4200","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4210 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4210","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4210 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4210","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4220 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4220","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4220 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4220","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4230 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4230","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4230 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4230","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4240 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4240","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4240 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4240","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4250 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4250","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4250 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4250","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4260 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4260","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4260 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4260","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4270 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4270","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4270 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4270","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4280 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4280","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4280 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4280","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4290 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4290","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4290 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4290","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4300 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4300","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4300 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4300","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4310 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4310","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4310 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4310","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4320 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4320","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4320 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4320","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4330 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4330","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4330 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4330","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4340 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4340","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4340 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4340","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4350 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4350","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4350 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4350","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4360 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4360","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4360 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4360","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4370 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4370","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4370 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4370","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4380 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4380","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4380 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4380","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4390 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4390","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4390 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4390","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4400 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4400","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4400 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4400","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4410 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4410","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4410 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4410","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4420 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4420","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4420 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4420","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4430 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4430","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4430 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4430","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4440 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4440","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4440 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4440","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4450 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4450","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4450 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4450","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4460 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4460","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4460 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4460","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4470 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4470","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4470 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4470","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4480 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4480","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4480 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4480","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4490 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4490","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4490 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4490","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4500 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4500","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4500 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4500","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4510 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4510","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4510 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4510","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4520 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4520","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4520 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4520","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4530 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4530","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4530 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4530","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4540 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4540","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4540 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4540","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4550 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4550","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4550 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4550","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4560 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4560","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4560 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4560","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4570 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4570","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4570 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4570","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4580 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4580","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4580 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4580","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4590 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4590","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4590 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4590","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4600 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4600","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4600 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4600","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4610 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4610","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4610 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4610","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4620 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4620","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4620 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4620","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4630 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4630","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4630 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4630","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4640 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4640","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4640 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4640","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4650 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4650","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4650 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4650","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4660 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4660","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4660 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4660","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4670 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4670","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4670 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4670","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4680 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4680","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4680 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4680","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4690 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4690","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4690 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4690","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4700 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4700","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4700 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4700","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4710 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4710","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4710 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4710","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4720 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4720","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4720 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4720","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4730 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4730","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4730 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4730","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4740 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4740","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4740 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4740","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4750 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4750","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4750 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4750","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4760 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4760","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4760 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4760","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4770 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4770","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4770 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4770","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4780 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4780","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4780 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4780","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4790 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4790","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4790 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4790","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4800 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4800","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4800 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4800","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4810 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4810","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4810 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4810","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4820 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4820","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4820 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4820","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4830 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4830","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4830 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4830","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4840 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4840","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4840 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4840","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4850 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4850","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4850 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4850","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4860 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4860","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4860 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4860","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4870 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4870","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4870 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4870","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4880 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4880","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4880 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4880","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4890 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4890","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4890 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4890","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4900 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4900","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4900 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4900","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4910 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4910","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4910 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4910","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4920 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4920","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4920 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4920","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4930 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4930","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4930 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4930","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4940 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4940","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4940 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4940","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4950 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4950","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4950 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4950","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4960 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4960","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4960 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4960","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4970 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4970","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4970 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4970","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4980 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4980","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4980 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4980","color":"gray"}]
execute if score #mKuning_points survisland.data matches 4990 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"4990","color":"gray"}]
execute if score #mMayra_points survisland.data matches 4990 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"4990","color":"gray"}]
execute if score #mKuning_points survisland.data matches 5000 run team modify survisland.temp.sidebar.4 suffix [{"text":"s : ","color":"yellow"},{"text":"5000","color":"gray"}]
execute if score #mMayra_points survisland.data matches 5000 run team modify survisland.temp.sidebar.1 suffix [{"text":" : ","color":"red"},{"text":"5000","color":"gray"}]

