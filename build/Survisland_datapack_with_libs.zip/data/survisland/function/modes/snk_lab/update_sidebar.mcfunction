
#> survisland:modes/snk_lab/update_sidebar
#
# @within	survisland:modes/snk_lab/tick
#

#i = 0
#while i <= 100:
#    print('execute if score #mAkijan_percentage survisland.data matches '+str(i)+' run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"'+str(i)+'","color":"yellow"},{"text":"%","color":"gray"}]')
#    print('execute if score #mHainy_percentage survisland.data matches '+str(i)+' run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"'+str(i)+'","color":"yellow"},{"text":"%","color":"gray"}]')
#    i += 1

scoreboard players set #mAkijan_percentage survisland.data 0
scoreboard players set #mHainy_percentage survisland.data 0

execute as @a[gamemode=adventure] at @s if entity @s[y=0,dy=71] run function survisland:modes/snk_lab/percentage_update

execute if score #mAkijan_percentage survisland.data matches 0 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"0","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 0 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"0","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 1 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"1","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 1 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"1","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 2 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"2","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 2 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"2","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 3 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"3","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 3 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"3","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 4 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"4","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 4 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"4","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 5 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"5","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 5 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"5","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 6 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"6","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 6 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"6","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 7 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"7","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 7 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"7","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 8 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"8","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 8 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"8","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 9 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"9","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 9 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"9","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 10 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"10","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 10 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"10","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 11 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"11","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 11 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"11","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 12 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"12","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 12 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"12","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 13 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"13","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 13 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"13","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 14 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"14","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 14 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"14","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 15 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"15","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 15 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"15","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 16 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"16","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 16 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"16","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 17 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"17","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 17 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"17","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 18 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"18","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 18 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"18","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 19 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"19","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 19 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"19","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 20 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"20","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 20 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"20","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 21 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"21","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 21 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"21","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 22 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"22","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 22 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"22","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 23 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"23","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 23 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"23","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 24 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"24","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 24 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"24","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 25 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"25","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 25 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"25","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 26 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"26","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 26 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"26","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 27 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"27","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 27 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"27","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 28 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"28","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 28 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"28","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 29 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"29","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 29 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"29","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 30 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"30","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 30 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"30","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 31 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"31","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 31 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"31","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 32 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"32","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 32 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"32","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 33 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"33","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 33 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"33","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 34 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"34","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 34 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"34","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 35 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"35","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 35 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"35","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 36 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"36","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 36 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"36","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 37 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"37","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 37 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"37","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 38 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"38","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 38 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"38","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 39 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"39","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 39 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"39","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 40 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"40","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 40 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"40","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 41 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"41","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 41 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"41","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 42 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"42","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 42 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"42","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 43 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"43","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 43 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"43","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 44 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"44","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 44 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"44","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 45 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"45","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 45 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"45","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 46 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"46","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 46 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"46","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 47 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"47","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 47 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"47","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 48 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"48","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 48 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"48","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 49 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"49","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 49 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"49","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 50 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"50","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 50 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"50","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 51 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"51","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 51 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"51","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 52 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"52","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 52 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"52","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 53 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"53","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 53 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"53","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 54 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"54","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 54 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"54","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 55 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"55","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 55 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"55","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 56 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"56","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 56 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"56","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 57 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"57","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 57 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"57","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 58 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"58","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 58 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"58","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 59 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"59","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 59 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"59","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 60 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"60","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 60 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"60","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 61 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"61","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 61 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"61","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 62 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"62","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 62 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"62","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 63 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"63","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 63 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"63","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 64 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"64","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 64 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"64","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 65 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"65","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 65 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"65","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 66 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"66","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 66 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"66","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 67 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"67","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 67 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"67","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 68 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"68","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 68 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"68","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 69 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"69","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 69 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"69","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 70 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"70","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 70 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"70","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 71 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"71","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 71 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"71","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 72 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"72","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 72 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"72","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 73 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"73","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 73 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"73","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 74 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"74","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 74 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"74","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 75 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"75","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 75 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"75","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 76 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"76","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 76 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"76","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 77 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"77","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 77 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"77","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 78 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"78","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 78 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"78","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 79 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"79","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 79 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"79","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 80 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"80","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 80 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"80","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 81 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"81","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 81 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"81","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 82 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"82","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 82 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"82","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 83 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"83","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 83 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"83","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 84 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"84","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 84 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"84","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 85 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"85","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 85 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"85","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 86 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"86","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 86 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"86","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 87 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"87","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 87 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"87","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 88 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"88","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 88 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"88","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 89 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"89","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 89 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"89","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 90 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"90","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 90 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"90","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 91 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"91","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 91 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"91","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 92 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"92","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 92 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"92","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 93 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"93","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 93 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"93","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 94 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"94","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 94 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"94","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 95 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"95","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 95 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"95","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 96 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"96","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 96 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"96","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 97 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"97","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 97 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"97","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 98 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"98","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 98 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"98","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 99 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"99","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 99 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"99","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mAkijan_percentage survisland.data matches 100 run team modify survisland.temp.sidebar.2 suffix [{"text":"kijan : ","color":"dark_aqua"},{"text":"100","color":"yellow"},{"text":"%","color":"gray"}]
execute if score #mHainy_percentage survisland.data matches 100 run team modify survisland.temp.sidebar.1 suffix [{"text":"ainy : ","color":"green"},{"text":"100","color":"yellow"},{"text":"%","color":"gray"}]

