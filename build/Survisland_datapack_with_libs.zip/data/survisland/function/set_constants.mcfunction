
#> survisland:set_constants
#
# @within	survisland:v2.4.2/load/confirm_load
#

#min=-100
#max=100
#while min <= max:
#    print('scoreboard players set #'+str(min)+' survisland.data '+str(min))
#    min += 1

scoreboard players set #negative_max survisland.data -2147483648
scoreboard players set #-2147483648 survisland.data -2147483648
scoreboard players set #-1000000000 survisland.data -1000000000
scoreboard players set #-100000000 survisland.data -100000000
scoreboard players set #-10000000 survisland.data -10000000
scoreboard players set #-1000000 survisland.data -1000000
scoreboard players set #-100000 survisland.data -100000
scoreboard players set #-10000 survisland.data -10000
scoreboard players set #-1000 survisland.data -1000
scoreboard players set #-100 survisland.data -100
scoreboard players set #-99 survisland.data -99
scoreboard players set #-98 survisland.data -98
scoreboard players set #-97 survisland.data -97
scoreboard players set #-96 survisland.data -96
scoreboard players set #-95 survisland.data -95
scoreboard players set #-94 survisland.data -94
scoreboard players set #-93 survisland.data -93
scoreboard players set #-92 survisland.data -92
scoreboard players set #-91 survisland.data -91
scoreboard players set #-90 survisland.data -90
scoreboard players set #-89 survisland.data -89
scoreboard players set #-88 survisland.data -88
scoreboard players set #-87 survisland.data -87
scoreboard players set #-86 survisland.data -86
scoreboard players set #-85 survisland.data -85
scoreboard players set #-84 survisland.data -84
scoreboard players set #-83 survisland.data -83
scoreboard players set #-82 survisland.data -82
scoreboard players set #-81 survisland.data -81
scoreboard players set #-80 survisland.data -80
scoreboard players set #-79 survisland.data -79
scoreboard players set #-78 survisland.data -78
scoreboard players set #-77 survisland.data -77
scoreboard players set #-76 survisland.data -76
scoreboard players set #-75 survisland.data -75
scoreboard players set #-74 survisland.data -74
scoreboard players set #-73 survisland.data -73
scoreboard players set #-72 survisland.data -72
scoreboard players set #-71 survisland.data -71
scoreboard players set #-70 survisland.data -70
scoreboard players set #-69 survisland.data -69
scoreboard players set #-68 survisland.data -68
scoreboard players set #-67 survisland.data -67
scoreboard players set #-66 survisland.data -66
scoreboard players set #-65 survisland.data -65
scoreboard players set #-64 survisland.data -64
scoreboard players set #-63 survisland.data -63
scoreboard players set #-62 survisland.data -62
scoreboard players set #-61 survisland.data -61
scoreboard players set #-60 survisland.data -60
scoreboard players set #-59 survisland.data -59
scoreboard players set #-58 survisland.data -58
scoreboard players set #-57 survisland.data -57
scoreboard players set #-56 survisland.data -56
scoreboard players set #-55 survisland.data -55
scoreboard players set #-54 survisland.data -54
scoreboard players set #-53 survisland.data -53
scoreboard players set #-52 survisland.data -52
scoreboard players set #-51 survisland.data -51
scoreboard players set #-50 survisland.data -50
scoreboard players set #-49 survisland.data -49
scoreboard players set #-48 survisland.data -48
scoreboard players set #-47 survisland.data -47
scoreboard players set #-46 survisland.data -46
scoreboard players set #-45 survisland.data -45
scoreboard players set #-44 survisland.data -44
scoreboard players set #-43 survisland.data -43
scoreboard players set #-42 survisland.data -42
scoreboard players set #-41 survisland.data -41
scoreboard players set #-40 survisland.data -40
scoreboard players set #-39 survisland.data -39
scoreboard players set #-38 survisland.data -38
scoreboard players set #-37 survisland.data -37
scoreboard players set #-36 survisland.data -36
scoreboard players set #-35 survisland.data -35
scoreboard players set #-34 survisland.data -34
scoreboard players set #-33 survisland.data -33
scoreboard players set #-32 survisland.data -32
scoreboard players set #-31 survisland.data -31
scoreboard players set #-30 survisland.data -30
scoreboard players set #-29 survisland.data -29
scoreboard players set #-28 survisland.data -28
scoreboard players set #-27 survisland.data -27
scoreboard players set #-26 survisland.data -26
scoreboard players set #-25 survisland.data -25
scoreboard players set #-24 survisland.data -24
scoreboard players set #-23 survisland.data -23
scoreboard players set #-22 survisland.data -22
scoreboard players set #-21 survisland.data -21
scoreboard players set #-20 survisland.data -20
scoreboard players set #-19 survisland.data -19
scoreboard players set #-18 survisland.data -18
scoreboard players set #-17 survisland.data -17
scoreboard players set #-16 survisland.data -16
scoreboard players set #-15 survisland.data -15
scoreboard players set #-14 survisland.data -14
scoreboard players set #-13 survisland.data -13
scoreboard players set #-12 survisland.data -12
scoreboard players set #-11 survisland.data -11
scoreboard players set #-10 survisland.data -10
scoreboard players set #-9 survisland.data -9
scoreboard players set #-8 survisland.data -8
scoreboard players set #-7 survisland.data -7
scoreboard players set #-6 survisland.data -6
scoreboard players set #-5 survisland.data -5
scoreboard players set #-4 survisland.data -4
scoreboard players set #-3 survisland.data -3
scoreboard players set #-2 survisland.data -2
scoreboard players set #-1 survisland.data -1
scoreboard players set #0 survisland.data 0
scoreboard players set #1 survisland.data 1
scoreboard players set #2 survisland.data 2
scoreboard players set #3 survisland.data 3
scoreboard players set #4 survisland.data 4
scoreboard players set #5 survisland.data 5
scoreboard players set #6 survisland.data 6
scoreboard players set #7 survisland.data 7
scoreboard players set #8 survisland.data 8
scoreboard players set #9 survisland.data 9
scoreboard players set #10 survisland.data 10
scoreboard players set #11 survisland.data 11
scoreboard players set #12 survisland.data 12
scoreboard players set #13 survisland.data 13
scoreboard players set #14 survisland.data 14
scoreboard players set #15 survisland.data 15
scoreboard players set #16 survisland.data 16
scoreboard players set #17 survisland.data 17
scoreboard players set #18 survisland.data 18
scoreboard players set #19 survisland.data 19
scoreboard players set #20 survisland.data 20
scoreboard players set #21 survisland.data 21
scoreboard players set #22 survisland.data 22
scoreboard players set #23 survisland.data 23
scoreboard players set #24 survisland.data 24
scoreboard players set #25 survisland.data 25
scoreboard players set #26 survisland.data 26
scoreboard players set #27 survisland.data 27
scoreboard players set #28 survisland.data 28
scoreboard players set #29 survisland.data 29
scoreboard players set #30 survisland.data 30
scoreboard players set #31 survisland.data 31
scoreboard players set #32 survisland.data 32
scoreboard players set #33 survisland.data 33
scoreboard players set #34 survisland.data 34
scoreboard players set #35 survisland.data 35
scoreboard players set #36 survisland.data 36
scoreboard players set #37 survisland.data 37
scoreboard players set #38 survisland.data 38
scoreboard players set #39 survisland.data 39
scoreboard players set #40 survisland.data 40
scoreboard players set #41 survisland.data 41
scoreboard players set #42 survisland.data 42
scoreboard players set #43 survisland.data 43
scoreboard players set #44 survisland.data 44
scoreboard players set #45 survisland.data 45
scoreboard players set #46 survisland.data 46
scoreboard players set #47 survisland.data 47
scoreboard players set #48 survisland.data 48
scoreboard players set #49 survisland.data 49
scoreboard players set #50 survisland.data 50
scoreboard players set #51 survisland.data 51
scoreboard players set #52 survisland.data 52
scoreboard players set #53 survisland.data 53
scoreboard players set #54 survisland.data 54
scoreboard players set #55 survisland.data 55
scoreboard players set #56 survisland.data 56
scoreboard players set #57 survisland.data 57
scoreboard players set #58 survisland.data 58
scoreboard players set #59 survisland.data 59
scoreboard players set #60 survisland.data 60
scoreboard players set #61 survisland.data 61
scoreboard players set #62 survisland.data 62
scoreboard players set #63 survisland.data 63
scoreboard players set #64 survisland.data 64
scoreboard players set #65 survisland.data 65
scoreboard players set #66 survisland.data 66
scoreboard players set #67 survisland.data 67
scoreboard players set #68 survisland.data 68
scoreboard players set #69 survisland.data 69
scoreboard players set #70 survisland.data 70
scoreboard players set #71 survisland.data 71
scoreboard players set #72 survisland.data 72
scoreboard players set #73 survisland.data 73
scoreboard players set #74 survisland.data 74
scoreboard players set #75 survisland.data 75
scoreboard players set #76 survisland.data 76
scoreboard players set #77 survisland.data 77
scoreboard players set #78 survisland.data 78
scoreboard players set #79 survisland.data 79
scoreboard players set #80 survisland.data 80
scoreboard players set #81 survisland.data 81
scoreboard players set #82 survisland.data 82
scoreboard players set #83 survisland.data 83
scoreboard players set #84 survisland.data 84
scoreboard players set #85 survisland.data 85
scoreboard players set #86 survisland.data 86
scoreboard players set #87 survisland.data 87
scoreboard players set #88 survisland.data 88
scoreboard players set #89 survisland.data 89
scoreboard players set #90 survisland.data 90
scoreboard players set #91 survisland.data 91
scoreboard players set #92 survisland.data 92
scoreboard players set #93 survisland.data 93
scoreboard players set #94 survisland.data 94
scoreboard players set #95 survisland.data 95
scoreboard players set #96 survisland.data 96
scoreboard players set #97 survisland.data 97
scoreboard players set #98 survisland.data 98
scoreboard players set #99 survisland.data 99
scoreboard players set #100 survisland.data 100
scoreboard players set #1000 survisland.data 1000
scoreboard players set #6200 survisland.data 6200
scoreboard players set #7800 survisland.data 7800
scoreboard players set #10000 survisland.data 10000
scoreboard players set #100000 survisland.data 100000
scoreboard players set #1000000 survisland.data 1000000
scoreboard players set #10000000 survisland.data 10000000
scoreboard players set #100000000 survisland.data 100000000
scoreboard players set #1000000000 survisland.data 1000000000
scoreboard players set #2147483647 survisland.data 2147483647
scoreboard players set #positive_max survisland.data 2147483647

