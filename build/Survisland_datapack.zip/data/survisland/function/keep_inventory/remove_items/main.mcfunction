
#> survisland:keep_inventory/remove_items/main
#
# @executed	as @a[scores={survisland.deathCount=1..}] & at @s
#
# @within	survisland:keep_inventory/player_died
#
# @input storage survisland:main Inventory
# 
# @output storage survisland:main newInventory
# 
# Remove items from storage survisland:main Inventory that are in the 0 1 0 chest
# using the following algorithm:
#  create a new empty inventory
#  for every items in the inventory
#      if the item in the chest is the same as the item in the inventory
#           don't add the item to the new inventory
#      else
#           add the item to the new inventory
#

# Copy all chest items to storage
data modify storage survisland:main AllChests set value []
execute positioned 0 1 0 run function survisland:keep_inventory/get_chest_items

# Loop through all items in the inventory
data modify storage survisland:main newInventory set value []
execute if data storage survisland:main Inventory[0] run function survisland:keep_inventory/remove_items/loop_inventory

# Remove every items of player inventory that is in the new inventory
data modify storage survisland:main Inventory set from storage survisland:main newInventory
execute if data storage survisland:main Inventory[0] run function survisland:keep_inventory/remove_items/loop_player_inventory

