
#> survisland:v2.6.0/load/resolve
#
# @within	#survisland:resolve
#

# If correct version, load the datapack
execute if score #survisland.major load.status matches 2 if score #survisland.minor load.status matches 6 if score #survisland.patch load.status matches 0 run function survisland:v2.6.0/load/main

