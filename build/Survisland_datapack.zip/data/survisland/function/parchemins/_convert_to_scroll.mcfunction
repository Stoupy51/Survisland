
#> survisland:parchemins/_convert_to_scroll
#
# @within	survisland:parchemins/_convert_votes
#			survisland:parchemins/macro_convert_votes {text_color:"$(text_color)", dyed_color:$(dyed_color)}
#
# @args		text_color (string)
#			dyed_color (list)
#
# @executed			default context
# 
# @input			storage survisland:main Item
# @output			storage survisland:main Item
# 
# @description		Convertit un vote (livre) en parchemin
#

# Setblock sign with the author and the page content
setblock ~ ~-2 ~ air
setblock ~ ~-2 ~ oak_sign
data modify block ~ ~-2 ~ front_text.messages[0] set value [{"text":"Auteur : ","color":"gold","italic":false},{"nbt":"Item.components.\"minecraft:written_book_content\".author","storage":"survisland:main","interpret":false,"color":"yellow"}]
$data modify block ~ ~-2 ~ front_text.messages[1] set value [{"nbt":"Item.components.\"minecraft:written_book_content\".pages[0].raw","storage":"survisland:main","interpret":true,"color":"$(text_color)","italic":false}]

# Copy the author in the lore and the page content in the name
data modify storage survisland:main Item.components."minecraft:lore" set value []
data modify storage survisland:main Item.components."minecraft:lore" append from block ~ ~-2 ~ front_text.messages[0]
data modify storage survisland:main Item.components."minecraft:custom_name" set from block ~ ~-2 ~ front_text.messages[1]

# Copy tint color
$data modify storage survisland:main Item.components."minecraft:dyed_color" set value $(dyed_color)

# Remove unnecessary data
data remove storage survisland:main Item.components."minecraft:written_book_content"

# Replace the book by a scroll
data modify storage survisland:main Item.id set value "minecraft:warped_fungus_on_a_stick"
data modify storage survisland:main Item.components."minecraft:item_model" set value "survisland:parchemin"

