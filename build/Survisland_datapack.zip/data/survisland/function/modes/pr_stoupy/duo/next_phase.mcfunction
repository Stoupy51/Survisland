
#> survisland:modes/pr_stoupy/duo/next_phase
#
# @within	(public)
#

# Every group at once, use the here/ version to handle a single one
execute as @e[type=mannequin,tag=survisland.pr_stoupy_duo.body] at @s run function survisland:modes/pr_stoupy/duo/body/next_phase

