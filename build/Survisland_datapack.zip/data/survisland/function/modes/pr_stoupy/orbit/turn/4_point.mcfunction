
#> survisland:modes/pr_stoupy/orbit/turn/4_point
#
# @executed	at @e[type=minecraft:marker,tag=survisland.pr_orbit.hole,predicate=survisland:modes/pr_stoupy/orbit/same_arena,limit=1]
#
# @within	survisland:modes/pr_stoupy/orbit/turn/4 with storage survisland:pr_orbit turn
#
# @args		step (unknown)
#

$function survisland:modes/pr_stoupy/orbit/move with storage survisland:pr_orbit paths[4][$(step)]

