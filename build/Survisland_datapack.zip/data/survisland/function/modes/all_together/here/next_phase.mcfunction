
#> survisland:modes/all_together/here/next_phase
#
# @within	(public)
#

# Only the group whose mannequin is the nearest one
execute as @n[type=mannequin,tag=survisland.all_together.body,distance=..3] at @s run function survisland:modes/all_together/body/next_phase

