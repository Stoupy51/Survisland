
#> survisland:modes/all_together/body/release_player
#
# @executed	as @a[tag=survisland.all_together,predicate=survisland:modes/all_together/same_group,distance=..50]
#
# @within	survisland:modes/all_together/body/stop [ as @a[tag=survisland.all_together,predicate=survisland:modes/all_together/same_group,distance=..50] ]
#			survisland:modes/all_together/stop [ as @a[tag=survisland.all_together] ]
#

# Give this player its own body back
execute if predicate survisland:riding run ride @s dismount
effect clear @s minecraft:invisibility
item replace entity @s armor.body with minecraft:air
attribute @s minecraft:scale base reset
attribute @s minecraft:gravity base reset
attribute @s minecraft:fall_damage_multiplier base reset
attribute @s minecraft:camera_distance base reset
attribute @s minecraft:entity_interaction_range base reset
attribute @s minecraft:block_interaction_range base reset
attribute @s minecraft:block_break_speed base reset

function survisland:modes/all_together/body/clear_player

