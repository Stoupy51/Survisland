
#> survisland:modes/shiren_trials/start
#
# @within	(public)
#

# Schedules
schedule function survisland:modes/shiren_trials/tick 1t replace
schedule function survisland:modes/skateboard/tick 1t replace

# Scoreboards
scoreboard objectives add survisland.temp.race_start dummy

